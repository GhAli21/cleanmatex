/**
 * GET /api/v1/orders/[id]
 * Fetch a single order by ID for detail/edit views.
 * Used by the edit order page; enforces tenant isolation via session.
 */

import { NextResponse } from 'next/server';
import { getTenantIdFromSession } from '@/lib/db/tenant-context';
import { getOrderById } from '@/lib/db/orders';
import { prisma } from '@/lib/db/prisma';
import { OrderPieceService } from '@/lib/services/order-piece-service';
import { readCanonicalOrderFinancialSnapshot } from '@/lib/utils/order-financial-snapshot';
import type { OrderItem } from '@/types/order';

function toNumber(value: unknown): number | null {
  if (value === undefined || value === null) return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

/**
 *
 * @param _request
 * @param root0
 * @param root0.params
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const tenantId = await getTenantIdFromSession();

    if (!tenantId) {
      return NextResponse.json(
        { success: false, error: 'Tenant ID required' },
        { status: 401 }
      );
    }

    const order = await getOrderById(tenantId, id);

    if (!order) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      );
    }

    // Load pieces for all order items (for edit screen) - includes service_prefs and conditions
    const itemIds = (order.items ?? []).map((i: { id: string }) => i.id);
    let piecesByItemId: Record<string, Array<{
      id: string;
      piece_seq: number;
      color?: string | null;
      brand?: string | null;
      has_stain?: boolean;
      has_damage?: boolean;
      notes?: string | null;
      rack_location?: string | null;
      metadata?: Record<string, unknown>;
      packing_pref_code?: string | null;
      service_prefs?: Array<{ preference_code: string; source?: string; extra_price: number }>;
      conditions?: string[];
    }>> = {};

    if (itemIds.length > 0) {
      const piecesResult = await OrderPieceService.getPiecesByOrder(tenantId, id);
      const piecesList = piecesResult.success && piecesResult.pieces ? piecesResult.pieces : [];
      for (const p of piecesList) {
        const key = p.order_item_id;
        if (!piecesByItemId[key]) piecesByItemId[key] = [];
        piecesByItemId[key].push({
          id: p.id,
          piece_seq: p.piece_seq,
          color: p.color ?? undefined,
          brand: p.brand ?? undefined,
          has_stain: p.has_stain ?? false,
          has_damage: p.has_damage ?? false,
          notes: p.notes ?? undefined,
          rack_location: p.rack_location ?? undefined,
          metadata: p.metadata ?? undefined,
          packing_pref_code: p.packing_pref_code ?? undefined,
          service_prefs: p.service_prefs,
          conditions: p.conditions,
        });
      }
    }

    // Option B: Fallback — resolve product names from catalog for items with null product_name
    const itemsMissingName = (order.items ?? []).filter(
      (item: OrderItem) => !item.product_name && item.product_id
    );
    const productNameMap: Record<string, { product_name: string | null; product_name2: string | null }> = {};
    if (itemsMissingName.length > 0) {
      const missingProductIds = [
        ...new Set(itemsMissingName.map((i: OrderItem) => i.product_id as string)),
      ];
      const catalogProducts = await prisma.org_product_data_mst.findMany({
        where: { tenant_org_id: tenantId, id: { in: missingProductIds } },
        select: { id: true, product_name: true, product_name2: true },
      });
      for (const p of catalogProducts) {
        productNameMap[p.id] = { product_name: p.product_name ?? null, product_name2: p.product_name2 ?? null };
      }
    }

    const customer = order.customer as { name?: string; phone?: string; email?: string; type?: string } | undefined;
    const customerName = customer?.name ?? null;
    const customerMobile = customer?.phone ?? null;
    const customerEmail = customer?.email ?? null;
    const customerType =
      (order.customer as { type?: string } | undefined)?.type ?? (customer as { type?: string } | undefined)?.type ?? null;

    const financialSnapshot = readCanonicalOrderFinancialSnapshot(
      order as unknown as Record<string, unknown>,
    );

    const serializedOrder = {
      ...order,
      customer_name: customerName,
      customer_mobile: customerMobile,
      customer_email: customerEmail,
      customer_type: customerType,
      customer_notes: order.customer_notes ?? null,
      internal_notes: order.internal_notes ?? null,
      payment_notes: order.payment_notes ?? null,
      notes: order.internal_notes ?? order.customer_notes ?? '',
      is_express: order.priority === 'express',
      ready_by_at: order.ready_by ?? order.ready_by_at_new ?? null,
      subtotal: financialSnapshot.subtotalAmount,
      discount: financialSnapshot.totalDiscountAmount,
      tax: financialSnapshot.totalTaxAmount,
      total: financialSnapshot.totalAmount,
      paid_amount: financialSnapshot.totalPaidAmount,
      bag_count: toNumber(order.bag_count) ?? null,
      priority_multiplier: toNumber(order.priority_multiplier) ?? null,
      items: (order.items ?? []).map((item: OrderItem) => {
        const itemPieces = (item.id && piecesByItemId[item.id]) || [];
        const catalog = (!item.product_name && item.product_id)
          ? productNameMap[item.product_id]
          : undefined;
        return {
          ...item,
          product_name: (item.product_name as string | null) ?? catalog?.product_name ?? null,
          product_name2: (item.product_name2 as string | null) ?? catalog?.product_name2 ?? null,
          price_per_unit: toNumber(item.price_per_unit) ?? 0,
          total_price: toNumber(item.total_price) ?? 0,
          quantity: toNumber(item.quantity) ?? 1,
          quantity_ready: toNumber(item.quantity_ready) ?? 0,
          price_override: toNumber(item.price_override) ?? null,
          default_sell_price: toNumber(item.default_sell_price) ?? null,
          default_express_sell_price: toNumber(item.default_express_sell_price) ?? null,
          pieces: itemPieces.map((p) => ({
            id: p.id,
            piece_seq: p.piece_seq,
            color: p.color ?? undefined,
            brand: p.brand ?? undefined,
            has_stain: p.has_stain ?? false,
            has_damage: p.has_damage ?? false,
            notes: p.notes ?? undefined,
            rack_location: p.rack_location ?? undefined,
            metadata: (p.metadata as Record<string, unknown>) ?? undefined,
            packing_pref_code: p.packing_pref_code ?? undefined,
            service_prefs: p.service_prefs,
            conditions: p.conditions,
          })),
        };
      }),
    };

    return NextResponse.json({
      success: true,
      data: serializedOrder,
    });
  } catch (error) {
    console.error('GET /api/v1/orders/[id] error:', error);
    const message = error instanceof Error ? error.message : 'Failed to fetch order';
    return NextResponse.json(
      { success: false, error: message },
      { status: 500 }
    );
  }
}
