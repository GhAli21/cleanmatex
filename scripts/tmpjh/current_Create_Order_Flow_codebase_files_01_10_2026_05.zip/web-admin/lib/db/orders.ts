/* eslint-disable jsdoc/require-param */
/**
 * Order Data Access Layer
 *
 * Database operations for orders using Prisma.
 * All queries automatically filter by tenant_org_id via Prisma middleware.
 */

import { prisma } from '@/lib/db/prisma';
import type {
  Order,
  OrderItem,
  OrderWithDetails,
  OrderListItem,
  OrderListResponse,
  OrderFilters,
  CreateOrderInput,
  AddOrderItemsInput,
  CompletePreparationInput,
} from '@/types/order';
import { generateOrderNumber } from '@/lib/utils/order-number-generator';

/**
 * Localized profile label attached to an immutable order workflow snapshot.
 *
 * The profile catalog remains global, while the owning order predicate keeps
 * this read within the authenticated tenant boundary.
 */
type OrderWorkflowProfileLabelRow = {
  workflow_profile_name: string | null;
  workflow_profile_name2: string | null;
};
import { generateQRCode, generateBarcode } from '@/lib/utils/barcode-generator';
import { calculateReadyBy, DEFAULT_BUSINESS_HOURS } from '@/lib/utils/ready-by-calculator';
import { ORDER_DEFAULTS } from '@/lib/constants/order-defaults';
import { roundMoneyAmount } from '@/lib/money/format-money';
import { logger } from '@/lib/utils/logger';
import { calculateItemPrice, calculateOrderTotal } from '@/lib/utils/pricing-calculator';
import { OrderPieceService } from '@/lib/services/order-piece-service';
import { recalculateOrderFinancialSnapshot } from '@/lib/services/order-financial-write.service';
import { taxService } from '@/lib/services/tax.service';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function withCanonicalOrderTotalAliases<T extends Record<string, unknown>>(order: T) {
  return {
    ...order,
    subtotal: Number(order.subtotal_amount ?? 0),
    discount: Number(order.total_discount_amount ?? 0),
    tax: Number(order.total_tax_amount ?? 0),
    total: Number(order.total_amount ?? 0),
    paid_amount: Number(order.total_paid_amount ?? 0),
  };
}

// ==================================================================
// CREATE OPERATIONS
// ==================================================================

/**
 * Create a new Quick Drop order
 */
export async function createOrder(
  tenantOrgId: string,
  input: CreateOrderInput
): Promise<Order> {
  // Generate unique order number
  const orderNumber = await generateOrderNumber(tenantOrgId);

  // Generate QR code and barcode
  const qrCode = await generateQRCode({
    orderNumber,
    tenantOrgId,
    customerId: input.customerId,
  });

  const barcode = await generateBarcode(orderNumber);

  // Get priority multiplier
  const priorityMultiplier = {
    normal: 1.0,
    urgent: 0.7,
    express: 0.5,
  }[input.priority];

  // Create order
  const order = await prisma.org_orders_mst.create({
    data: {
      tenant_org_id: tenantOrgId,
      customer_id: input.customerId,
      branch_id: input.branchId,
      order_no: orderNumber,
      order_type_id: input.orderType,
      service_category_code: input.serviceCategory,
      bag_count: input.bagCount,
      priority: input.priority,
      priority_multiplier: priorityMultiplier,
      preparation_status: 'pending',
      status: 'intake',
      customer_notes: input.customerNotes,
      internal_notes: input.internalNotes,
      photo_urls: input.photoUrls || [],
      qr_code: qrCode,
      barcode: barcode,
      received_at: new Date(),
      order_source_code: 'web_admin',
      physical_intake_status: 'received',
      total_items: 0,
      subtotal_amount: 0,
      items_base_amount: 0,
      total_discount_amount: 0,
      total_tax_amount: 0,
      total_amount: 0,
      total_paid_amount: 0,
      outstanding_amount: 0,
      payment_status: 'pending',
      created_by: input.createdBy ?? undefined,
      rec_status: 1,
    },
  });

  return withCanonicalOrderTotalAliases(order as unknown as Record<string, unknown>) as unknown as Order;
}

/**
 * Add items to an order
 */
export async function addOrderItems(
  tenantOrgId: string,
  orderId: string,
  input: AddOrderItemsInput
): Promise<{ items: OrderItem[]; order: Order }> {
  // Get products for pricing
  const productIds = input.items.map((item) => item.productId);
  const products = await prisma.org_product_data_mst.findMany({
    where: {
      tenant_org_id: tenantOrgId,
      id: { in: productIds },
    },
  });

  // Fetch order to get customer_id for pricing and order_no for barcode
  const orderForBarcode = await prisma.org_orders_mst.findUnique({
    where: { id: orderId, tenant_org_id: tenantOrgId },
    select: { order_no: true, customer_id: true },
  });

  // Create product map for easy lookup
  const productMap = new Map(products.map((p) => [p.id, p]));

  // Import PricingService
  const { pricingService } = await import('@/lib/services/pricing.service');

  // Current user (override audit) + tenant money decimals for tax rounding
  let currentUserId: string | undefined;
  let tenantMoneyDecimals: number = ORDER_DEFAULTS.PRICE.DECIMAL_PLACES;
  try {
    const { createClient } = await import('@/lib/supabase/server');
    const { createTenantSettingsService } = await import('@/lib/services/tenant-settings.service');
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    currentUserId = user?.id;
    const cfg = await createTenantSettingsService(supabase).getCurrencyConfig(tenantOrgId);
    tenantMoneyDecimals = cfg.decimalPlaces;
  } catch (error) {
    console.warn('[addOrderItems] Could not resolve auth or currency config:', error);
  }

  // Check permission for price override (if any item has override)
  //
  // B27: this block used to fail OPEN in two places — (1) if `currentUserId`
  // couldn't be resolved (e.g. a transient auth/session error a few lines up),
  // the whole check was skipped via `hasPriceOverride && currentUserId`, so an
  // override proceeded with no identifiable actor at all; (2) any error from
  // hasPermissionServer() other than the literal string "Permission denied"
  // was logged and swallowed, letting the override through anyway. Both are
  // fixed to fail CLOSED — pricing:override was also unseeded in the DB until
  // this same package (0410), so today's real-world behavior was effectively
  // unenforced regardless of which bug fired first.
  const hasPriceOverride = input.items.some((item) => item.priceOverride !== undefined);
  if (hasPriceOverride) {
    if (!currentUserId) {
      throw new Error('Permission denied: pricing:override requires an authenticated user');
    }
    const { hasPermissionServer } = await import('@/lib/services/permission-service-server');
    const canOverride = await hasPermissionServer('pricing:override', {
      userId: currentUserId,
      tenantId: tenantOrgId,
    });
    if (!canOverride) {
      throw new Error('Permission denied: pricing:override required for price overrides');
    }
  }

  // Calculate pricing for each item using PricingService
  const itemsWithPricing = await Promise.all(
    input.items.map(async (item) => {
      const product = productMap.get(item.productId);
      if (!product) {
        throw new Error(`Product not found: ${item.productId}`);
      }

      // Get price from pricing service (uses price lists, tax service, etc.)
      const priceResult = await pricingService.getPriceForOrderItem({
        tenantId: tenantOrgId,
        productId: item.productId,
        quantity: item.quantity,
        isExpress: Boolean(input.isExpressService),
        customerId: orderForBarcode?.customer_id || undefined,
      });

      // Apply price override if provided
      let finalPrice = priceResult.finalPrice;
      let finalTotal = priceResult.total;
      let overrideApplied = false;

      if (item.priceOverride !== undefined && item.priceOverride !== null) {
        // Use override price
        finalPrice = item.priceOverride;
        // Recalculate tax on override price
        const taxAmount = priceResult.isTaxExempt
          ? 0
          : taxService.calculateTax(
              finalPrice * item.quantity,
              priceResult.taxRate,
              tenantMoneyDecimals,
            );
        finalTotal = finalPrice * item.quantity + taxAmount;
        overrideApplied = true;
      }

      // Convert PriceResult to pricing format expected by existing code
      // Use pricing calculator for consistency with existing structure
      const expressMultiplier = Number(product.multiplier_express || 1.5);
      const pricing = calculateItemPrice({
        basePrice: finalPrice, // Use final price (override or calculated)
        quantity: item.quantity,
        isExpress: Boolean(input.isExpressService),
        expressMultiplier: 1, // Already applied in priceResult
        taxRate: priceResult.taxRate,
        discountPercent: 0, // Already applied in priceResult
        decimalPlaces: tenantMoneyDecimals,
      });

      // Override with actual values
      pricing.unitPrice = finalPrice;
      pricing.tax = priceResult.isTaxExempt
        ? 0
        : taxService.calculateTax(
            finalPrice * item.quantity,
            priceResult.taxRate,
            tenantMoneyDecimals,
          );
      pricing.total = finalTotal;

      return {
        ...item,
        product,
        pricing,
        priceResult, // Store full price result for future use
        overrideApplied,
      };
    })
  );

  // Create items in database
  const createdItems = await prisma.$transaction(async (tx) => {
    const items = [];
    for (const item of itemsWithPricing) {
      // Create first to get generated order_item_srno via trigger; then update barcode
      const created = await tx.org_order_items_dtl.create({
        data: {
          order_id: orderId,
          tenant_org_id: tenantOrgId,
          product_id: item.productId,
          product_name: item.product.product_name,
          product_name2: item.product.product_name2,
          service_category_code: item.serviceCategoryCode,
          quantity: item.quantity,
          price_per_unit: item.pricing.unitPrice,
          total_price: item.pricing.total,
          color: item.color,
          brand: item.brand,
          has_stain: item.hasStain,
          stain_notes: item.stainNotes,
          has_damage: item.hasDamage,
          damage_notes: item.damageNotes,
          notes: item.notes,
          status: 'pending',
          // Price override fields
          price_override: item.overrideApplied ? item.priceOverride : null,
          override_reason: item.overrideApplied ? item.overrideReason : null,
          override_by: item.overrideApplied && currentUserId ? currentUserId : null,
        },
      });

      // Compute an item code for barcode (ORD + SRNO)
      const srno = (created as any).order_item_srno as string | null;
      const orderNo = orderForBarcode?.order_no || '';
      const barcodeValue = srno ? `${orderNo}-${srno}` : orderNo;
      const itemBarcode = await generateBarcode(barcodeValue);

      const updated = await tx.org_order_items_dtl.update({
        where: { id: (created as any).id, tenant_org_id: tenantOrgId } as any,
        data: { barcode: itemBarcode },
      });
      items.push(updated);
    }
    return items;
  });

  // Always create pieces for each order item
  if (createdItems.length > 0) {
    // Create pieces for each item
    const piecesErrors: Array<{ itemId: string; error: string }> = [];

    for (let i = 0; i < createdItems.length; i++) {
      const createdItem = createdItems[i];
      const itemData = itemsWithPricing[i];

      if (createdItem && itemData.quantity > 0) {
        const piecesResult = await OrderPieceService.createPiecesForItem(
          tenantOrgId,
          orderId,
          (createdItem as any).id,
          itemData.quantity,
          {
            serviceCategoryCode: itemData.serviceCategoryCode,
            productId: itemData.productId,
            pricePerUnit: itemData.pricing.unitPrice,
            totalPrice: itemData.pricing.total,
            color: itemData.color,
            brand: itemData.brand,
            hasStain: itemData.hasStain,
            hasDamage: itemData.hasDamage,
            notes: itemData.notes,
            metadata: {},
          }
        );

        // If pieces creation failed, collect the error
        if (!piecesResult.success) {
          piecesErrors.push({
            itemId: (createdItem as any).id,
            error: piecesResult.error || 'Failed to create pieces',
          });
        }
      }
    }

    // If any pieces creation failed, throw error to prevent partial state
    if (piecesErrors.length > 0) {
      // Delete the items that were just created since pieces failed
      const itemIds = createdItems.map(item => (item as any).id);
      await prisma.org_order_items_dtl.deleteMany({
        where: {
          id: { in: itemIds },
          tenant_org_id: tenantOrgId,
        } as any,
      });

      throw new Error(
        `Failed to create pieces for order items: ${piecesErrors.map(e => e.error).join('; ')}`
      );
    }
  }

  // Calculate order totals
  const allItems = itemsWithPricing.map((item) => item.pricing);
  const orderTotals = calculateOrderTotal({
    items: allItems,
    decimalPlaces: tenantMoneyDecimals,
  });

  // Update order with totals and item count
  const updatedOrder = await prisma.org_orders_mst.update({
    where: {
      id: orderId,
      tenant_org_id: tenantOrgId,
    },
    data: {
      total_items: { increment: input.items.reduce((sum, item) => sum + item.quantity, 0) },
      subtotal_amount: orderTotals.subtotalAfterDiscount,
      items_base_amount: orderTotals.subtotalAfterDiscount,
      total_tax_amount: orderTotals.tax,
      total_amount: orderTotals.total,
      updated_at: new Date(),
      ...(currentUserId && { updated_by: currentUserId }),
    },
  });

  await recalculateOrderFinancialSnapshot(tenantOrgId, orderId);

  return {
    items: createdItems as unknown as OrderItem[],
    order: withCanonicalOrderTotalAliases(updatedOrder as unknown as Record<string, unknown>) as unknown as Order,
  };
}

/**
 * Complete order preparation
 */
export async function completePreparation(
  tenantOrgId: string,
  orderId: string,
  userId: string,
  input: CompletePreparationInput
): Promise<Order> {
  // Get order with service category info
  const order = await prisma.org_orders_mst.findUnique({
    where: {
      id: orderId,
      tenant_org_id: tenantOrgId,
    },
  });

  if (!order) {
    throw new Error('Order not found');
  }

  // Calculate Ready-By date if not overridden
  let readyBy = input.readyByOverride;

  if (!readyBy) {
    // Get service category turnaround time
    const serviceCategory = await prisma.sys_service_category_cd.findUnique({
      where: { service_category_code: order.service_category_code || '' },
    });

    const turnaroundHours = Number(serviceCategory?.turnaround_hh || 48);

    // Use current date if received_at is null (shouldn't happen but handle gracefully)
    const receivedAt = order.received_at || new Date();

    const readyByCalc = calculateReadyBy({
      receivedAt,
      turnaroundHours,
      priority: order.priority as 'normal' | 'urgent' | 'express',
      businessHours: DEFAULT_BUSINESS_HOURS,
    });

    readyBy = readyByCalc.readyBy;
  }

  // Update order
  const updatedOrder = await prisma.org_orders_mst.update({
    where: {
      id: orderId,
      tenant_org_id: tenantOrgId,
    },
    data: {
      preparation_status: 'completed',
      prepared_at: new Date(),
      prepared_by: userId,
      ready_by: readyBy,
      ready_by_override: input.readyByOverride || null,
      status: 'processing',
      internal_notes: input.internalNotes || order.internal_notes,
      updated_at: new Date(),
      updated_by: userId,
    },
  });

  return updatedOrder as unknown as Order;
}

// ==================================================================
// READ OPERATIONS
// ==================================================================

/**
 * Get order by ID with full details
 */
export async function getOrderById(
  tenantOrgId: string,
  orderId: string
): Promise<OrderWithDetails | null> {
  const order = await prisma.org_orders_mst.findUnique({
    where: {
      id: orderId,
      tenant_org_id: tenantOrgId,
    },
    include: {
      org_customers_mst: {
        select: {
          id: true,
          name: true,
          name2: true,
          phone: true,
          email: true,
          type: true,
          preferences: true,
          sys_customers_mst: {
            select: {
              id: true,
              name: true,
              name2: true,
              phone: true,
              email: true,
              preferences: true,
            },
          },
        },
      },
      org_order_items_dtl: {
        orderBy: { created_at: 'asc' },
      },
      org_branches_mst: {
        select: {
          id: true,
          branch_name: true,
        },
      },
      sys_order_sources_cd: {
        select: {
          order_source_code: true,
          name: true,
          name2: true,
          requires_remote_intake_confirm: true,
        },
      },
    },
  });

  if (!order) {
    return null;
  }

  const workflowProfileLabel = await prisma.$queryRaw<OrderWorkflowProfileLabelRow[]>`
    SELECT
      profile_row.name AS workflow_profile_name,
      profile_row.name2 AS workflow_profile_name2
    FROM public.org_orders_mst AS order_row
    LEFT JOIN public.sys_wf_profiles_cd AS profile_row
      ON profile_row.profile_id = order_row.wf_profile_id
    WHERE order_row.id = ${orderId}::uuid
      AND order_row.tenant_org_id = ${tenantOrgId}::uuid
    LIMIT 1
  `;

  // Get customer data from org_customers_mst, fallback to sys_customers_mst if available
  const customerData = order.org_customers_mst?.sys_customers_mst || order.org_customers_mst;

  return {
    ...order,
    // state_version is BIGINT in the DB (workflow-engine optimistic concurrency token);
    // Prisma returns it as a native bigint, which JSON.stringify cannot serialize.
    state_version: typeof order.state_version === 'bigint' ? Number(order.state_version) : order.state_version,
    customer: customerData,
    items: order.org_order_items_dtl,
    branch: order.org_branches_mst,
    order_source: order.sys_order_sources_cd,
    // A pinned profile may be retired after ordering; retain its label for operational traceability.
    workflow_profile_name: workflowProfileLabel[0]?.workflow_profile_name ?? null,
    workflow_profile_name2: workflowProfileLabel[0]?.workflow_profile_name2 ?? null,
  } as unknown as OrderWithDetails;
}

/**
 * Resolve an order from either its UUID or its human-readable order number.
 *
 * We prefer UUID when it matches and exists, then fall back to an exact
 * case-insensitive order number lookup within the same tenant.
 */
export async function getOrderByReference(
  tenantOrgId: string,
  orderReference: string,
): Promise<OrderWithDetails | null> {
  const normalizedReference = orderReference.trim();
  if (!normalizedReference) {
    return null;
  }

  if (UUID_REGEX.test(normalizedReference)) {
    const orderById = await getOrderById(tenantOrgId, normalizedReference);
    if (orderById) {
      return orderById;
    }
  }

  const orderRow = await prisma.org_orders_mst.findFirst({
    where: {
      tenant_org_id: tenantOrgId,
      order_no: {
        equals: normalizedReference,
        mode: 'insensitive',
      },
    },
    select: {
      id: true,
    },
  });

  if (!orderRow?.id) {
    return null;
  }

  return getOrderById(tenantOrgId, orderRow.id);
}

/**
 * List orders with filters and pagination
 */
export async function listOrders(
  tenantOrgId: string,
  filters: OrderFilters
): Promise<OrderListResponse> {
  // Validate tenantOrgId is a valid UUID
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(tenantOrgId)) {
    throw new Error(`Invalid tenant ID format: ${tenantOrgId}. Expected UUID format.`);
  }
  const {
    status,
    preparationStatus,
    priority,
    isRetail,
    customerId,
    branchId,
    fromDate,
    toDate,
    search,
    page = 1,
    limit = 20,
    sortBy = 'received_at',
    sortOrder = 'desc',
    orderSourceCode,
    physicalIntakeStatus,
  } = filters;

  // Build where clause
  const where: any = {
    tenant_org_id: tenantOrgId,
  };

  if (status) {
    where.status = Array.isArray(status) ? { in: status } : status;
  }

  if (preparationStatus) {
    where.preparation_status = Array.isArray(preparationStatus)
      ? { in: preparationStatus }
      : preparationStatus;
  }

  if (priority) {
    where.priority = Array.isArray(priority) ? { in: priority } : priority;
  }

  if (isRetail === 'true') {
    where.is_retail = true;
  } else if (isRetail === 'false') {
    where.is_retail = false;
  }

  if (customerId) {
    where.customer_id = customerId;
  }

  if (branchId) {
    where.branch_id = branchId;
  }

  if (fromDate) {
    where.received_at = { ...where.received_at, gte: fromDate };
  }

  if (toDate) {
    where.received_at = { ...where.received_at, lte: toDate };
  }

  if (orderSourceCode) {
    const codes = orderSourceCode
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (codes.length > 1) {
      where.order_source_code = { in: codes };
    } else if (codes.length === 1) {
      where.order_source_code = codes[0];
    }
  }

  if (physicalIntakeStatus) {
    const statuses = physicalIntakeStatus
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (statuses.length > 1) {
      where.physical_intake_status = { in: statuses };
    } else if (statuses.length === 1) {
      where.physical_intake_status = statuses[0];
    }
  }

  if (search) {
    where.OR = [
      { order_no: { contains: search, mode: 'insensitive' } },
      {
        org_customers_mst: {
          OR: [
            { name: { contains: search, mode: 'insensitive' } },
            { phone: { contains: search } },
            {
              sys_customers_mst: {
                OR: [
                  { name: { contains: search, mode: 'insensitive' } },
                  { phone: { contains: search } },
                ],
              }
            },
          ],
        },
      },
    ];
  }

  // Get total count
  const total = await prisma.org_orders_mst.count({ where });

  // Get orders
  const orders = await prisma.org_orders_mst.findMany({
    where,
    include: {
      org_customers_mst: {
        select: {
          id: true,
          name: true,
          name2: true,
          phone: true,
          email: true,
          sys_customers_mst: {
            select: {
              id: true,
              name: true,
              name2: true,
              phone: true,
              email: true,
            },
          },
        },
      },
      org_branches_mst: {
        select: {
          branch_name: true,
        },
      },
      sys_order_sources_cd: {
        select: {
          order_source_code: true,
          name: true,
          name2: true,
          requires_remote_intake_confirm: true,
        },
      },
      org_order_items_dtl: {
        select: {
          id: true,
        },
      },
    },
    orderBy:
      sortBy === 'received_at'
        ? [{ received_at: { sort: sortOrder, nulls: 'last' } }, { created_at: sortOrder }]
        : { [sortBy]: sortOrder },
    skip: (page - 1) * limit,
    take: limit,
  });

  // Get piece counts for all orders in batch
  const orderIds = orders.map(o => o.id);
  const itemIds = orders.flatMap(o => o.org_order_items_dtl.map(item => item.id));

  const pieceCounts = itemIds.length > 0 ? await prisma.org_order_item_pieces_dtl.groupBy({
    by: ['order_id'],
    where: {
      order_id: { in: orderIds },
      tenant_org_id: tenantOrgId,
    },
    _count: {
      id: true,
    },
  }) : [];

  const pieceCountMap = new Map(
    pieceCounts.map(pc => [pc.order_id, pc._count.id])
  );

  const orderList: OrderListItem[] = orders.map((order) => {
    // The order snapshot preserves who the counter served at the time of sale;
    // master records only fill legacy orders whose snapshot was never written.
    const customerData = order.org_customers_mst?.sys_customers_mst || order.org_customers_mst;

    // Ensure customer data is properly formatted (defensive check)
    const customerId = customerData?.id || order.org_customers_mst?.id || '';
    const customerName =
      order.customer_name?.trim()
      || order.org_customers_mst?.name?.trim()
      || order.org_customers_mst?.sys_customers_mst?.name?.trim()
      || '';
    const customerPhone = customerData?.phone || order.org_customers_mst?.phone || '';

    // Ensure all values are strings, not objects
    const safeCustomer = {
      id: typeof customerId === 'string' ? customerId : String(customerId || ''),
      name: typeof customerName === 'string' ? customerName : String(customerName || ''),
      phone: typeof customerPhone === 'string' ? customerPhone : String(customerPhone || ''),
    };

    return {
      id: order.id,
      order_no: order.order_no,
      customer: safeCustomer,
      status: order.status as any,
      preparation_status: order.preparation_status as any,
      priority: order.priority as any,
      is_retail: (order as { is_retail?: boolean }).is_retail ?? false,
      total_items: order.total_items ?? 0,
      total_pieces: pieceCountMap.get(order.id) ?? null,
      total: Number(order.total_amount ?? 0),
      received_at: order.received_at ?? null,
      ready_by: order.ready_by,
      branch_name: order.org_branches_mst?.branch_name ?? undefined,
      order_source_code: order.order_source_code ?? undefined,
      physical_intake_status: order.physical_intake_status ?? null,
      physical_intake_at: order.physical_intake_at ?? null,
      order_source: order.sys_order_sources_cd
        ? {
            order_source_code: order.sys_order_sources_cd.order_source_code,
            name: order.sys_order_sources_cd.name,
            name2: order.sys_order_sources_cd.name2,
            requires_remote_intake_confirm:
              order.sys_order_sources_cd.requires_remote_intake_confirm,
          }
        : null,
    };
  });

  return {
    orders: orderList,
    pagination: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    },
  };
}

/**
 * Get order for preparation (with product catalog)
 */
export async function getOrderForPreparation(
  tenantOrgId: string,
  orderId: string
) {
  // Get order with details
  const order = await getOrderById(tenantOrgId, orderId);

  if (!order) {
    throw new Error('Order not found');
  }

  // Get product catalog for the service category
  const products = await prisma.org_product_data_mst.findMany({
    where: {
      tenant_org_id: tenantOrgId,
      service_category_code: order.service_category_code,
      is_active: true,
    },
    orderBy: { product_order: 'asc' },
  });

  return {
    order,
    productCatalog: products.map((p) => ({
      id: p.id,
      code: p.product_code,
      name: p.product_name || '',
      name2: p.product_name2 || '',
      price: Number(p.default_sell_price || 0),
      expressPrice: Number(p.default_express_sell_price || 0),
      serviceCategory: p.service_category_code || '',
      unit: p.product_unit || 'piece',
      isActive: p.is_active,
    })),
  };
}

// ==================================================================
// UPDATE OPERATIONS
// ==================================================================

/**
 * Update order status
 */
export async function updateOrderStatus(
  tenantOrgId: string,
  orderId: string,
  status: string,
  notes?: string,
  userId?: string
): Promise<Order> {
  const updatedOrder = await prisma.org_orders_mst.update({
    where: {
      id: orderId,
      tenant_org_id: tenantOrgId,
    },
    data: {
      status,
      internal_notes: notes,
      updated_at: new Date(),
      ...(userId && { updated_by: userId }),
    },
  });

  return updatedOrder as unknown as Order;
}

/**
 * Delete order item
 */
export async function deleteOrderItem(
  tenantOrgId: string,
  orderId: string,
  itemId: string
): Promise<void> {
  await prisma.org_order_items_dtl.delete({
    where: {
      id: itemId,
      order_id: orderId,
      tenant_org_id: tenantOrgId,
    },
  });

  // Recalculate order totals
  await recalculateOrderTotals(tenantOrgId, orderId);
}

/**
 * Recalculate order totals after item add/delete.
 *
 * Order master financial fields (org_orders_mst) now persist through the
 * canonical snapshot columns. This helper only updates item-derived numeric
 * inputs before the shared financial snapshot recalculator recomputes the
 * authoritative header values.
 *
 * Item total_price in DB is line total (subtotal + tax per item), so sum(total_price) = order
 * total from items. We derive subtotal and tax from that using order vat_rate (no double tax).
 */
async function recalculateOrderTotals(
  tenantOrgId: string,
  orderId: string,
  userId?: string
): Promise<void> {
  let decimalPlaces: number = ORDER_DEFAULTS.PRICE.DECIMAL_PLACES;
  try {
    const { createClient } = await import('@/lib/supabase/server');
    const { createTenantSettingsService } = await import('@/lib/services/tenant-settings.service');
    const supabase = await createClient();
    const cfg = await createTenantSettingsService(supabase).getCurrencyConfig(tenantOrgId);
    decimalPlaces = cfg.decimalPlaces;
  } catch (err) {
    console.warn('[recalculateOrderTotals] Could not load currency config, using defaults:', err);
  }
  const roundMoney = (n: number) => roundMoneyAmount(n, decimalPlaces);

  const items = await prisma.org_order_items_dtl.findMany({
    where: {
      order_id: orderId,
      tenant_org_id: tenantOrgId,
    },
  });

  const totalItems = items.reduce((sum, item) => sum + (item.quantity ?? 0), 0);

  if (items.length === 0) {
    await prisma.org_orders_mst.update({
      where: { id: orderId, tenant_org_id: tenantOrgId },
      data: {
        subtotal_amount: 0,
        items_base_amount: 0,
        total_tax_amount: 0,
        total_amount: 0,
        total_items: 0,
        updated_at: new Date(),
        ...(userId && { updated_by: userId }),
      },
    });
    await recalculateOrderFinancialSnapshot(tenantOrgId, orderId);
    return;
  }

  // total_price per item is line total (incl. tax) from pricing-calculator; sum = order total
  const total = roundMoney(items.reduce((sum, item) => sum + Number(item.total_price), 0));

  const order = await prisma.org_orders_mst.findUnique({
    where: { id: orderId, tenant_org_id: tenantOrgId },
    select: { vat_rate: true },
  });
  // B15: tax fallbacks are forbidden. Resolution order: the stamped header
  // rate → the effective rate from the order's recorded tax lines in
  // org_order_taxes_dtl (Σtax ÷ Σtaxable is scale-invariant, so the pre-edit
  // lines still yield the correct rate) → fail loudly. Tax-exempt is an
  // explicit 0, never null.
  let vatRate = order?.vat_rate != null ? Number(order.vat_rate) : null;
  if (vatRate == null) {
    const taxAgg = await prisma.org_order_taxes_dtl.aggregate({
      where: { tenant_org_id: tenantOrgId, order_id: orderId, rec_status: 1 },
      _sum: { tax_amount: true, taxable_amount: true },
    });
    const taxable = Number(taxAgg._sum.taxable_amount ?? 0);
    if (taxable > 0) {
      vatRate = Number(taxAgg._sum.tax_amount ?? 0) / taxable;
    }
  }
  if (vatRate == null) {
    // Owner policy (2026-07-18): no header stamp AND no tax lines means the
    // tenant does not use tax — treat the order as zero-rated. Never an
    // error, and never an assumed positive rate. Logged for observability.
    logger.warn('recalculateOrderTotals: no vat_rate stamp and no tax lines — treating order as zero-rated', {
      tenantOrgId,
      orderId,
    });
    vatRate = 0;
  }

  const subtotal = roundMoney(total / (1 + vatRate));
  const tax = roundMoney(total - subtotal);

  // Only update item-derived canonical totals here; the shared financial
  // snapshot recalculator will recompute the rest of the header consistently.
  await prisma.org_orders_mst.update({
    where: { id: orderId, tenant_org_id: tenantOrgId },
    data: {
      subtotal_amount: subtotal,
      items_base_amount: subtotal,
      total_tax_amount: tax,
      total_amount: total,
      vat_rate: vatRate,
      total_items: totalItems,
      updated_at: new Date(),
      ...(userId && { updated_by: userId }),
    },
  });

  await recalculateOrderFinancialSnapshot(tenantOrgId, orderId);
}

// ==================================================================
// STATISTICS
// ==================================================================

/**
 * Get order statistics for dashboard
 */
export async function getOrderStats(tenantOrgId: string) {
  // Validate tenantOrgId is a valid UUID
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(tenantOrgId)) {
    throw new Error(`Invalid tenant ID format: ${tenantOrgId}. Expected UUID format.`);
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [
    total,
    pendingPreparation,
    inPreparation,
    processing,
    ready,
    outForDelivery,
    deliveredToday,
    overdue,
  ] = await Promise.all([
    prisma.org_orders_mst.count({ where: { tenant_org_id: tenantOrgId } }),
    prisma.org_orders_mst.count({
      where: { tenant_org_id: tenantOrgId, preparation_status: 'pending' },
    }),
    prisma.org_orders_mst.count({
      where: { tenant_org_id: tenantOrgId, preparation_status: 'in_progress' },
    }),
    prisma.org_orders_mst.count({
      where: { tenant_org_id: tenantOrgId, status: 'processing' },
    }),
    prisma.org_orders_mst.count({
      where: { tenant_org_id: tenantOrgId, status: 'ready' },
    }),
    prisma.org_orders_mst.count({
      where: { tenant_org_id: tenantOrgId, status: 'out_for_delivery' },
    }),
    prisma.org_orders_mst.count({
      where: {
        tenant_org_id: tenantOrgId,
        status: 'delivered',
        delivered_at: { gte: today },
      },
    }),
    prisma.org_orders_mst.count({
      where: {
        tenant_org_id: tenantOrgId,
        ready_by: { lt: new Date() },
        status: { notIn: ['delivered', 'closed', 'cancelled'] },
      },
    }),
  ]);

  return {
    total,
    pending_preparation: pendingPreparation,
    in_preparation: inPreparation,
    processing,
    ready,
    out_for_delivery: outForDelivery,
    delivered_today: deliveredToday,
    overdue,
  };
}
