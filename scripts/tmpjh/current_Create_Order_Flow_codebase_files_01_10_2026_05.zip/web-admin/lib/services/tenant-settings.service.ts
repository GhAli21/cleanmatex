/* eslint-disable jsdoc/require-jsdoc, jsdoc/require-param */
/**
 * Tenant Settings Service
 *
 * Fetches tenant-specific settings using fn_stng_resolve_all_settings (7-layer resolution).
 * Single RPC call retrieves all settings with proper hierarchy: SYSTEM_DEFAULT → SYSTEM_PROFILE
 * → TENANT_OVERRIDE → BRANCH_OVERRIDE → USER_OVERRIDE.
 *
 * Use the default `tenantSettingsService` in client components/hooks.
 * In server actions/API routes, use `createTenantSettingsService(await createServerSupabaseClient())`
 * for proper auth context.
 */

import { createClient } from '@/lib/supabase/client';
import { TenantCurrencyProfileService } from '@/lib/services/fx/tenant-currency-profile.service';
import type { SupabaseClient } from '@supabase/supabase-js';

/**
 * Setting codes from sys_tenant_settings_cd (source of truth).
 * Must match catalog entries; see F:/jhapp/cleanmatex/supabase/migrations/
 *
 * Money (L2 cut-over, Tenant_Currency_FX plan 01): `TENANT_CURRENCY` and
 * `TENANT_DECIMAL_PLACES` are retired as the currency source of truth —
 * `getTenantCurrency`/`getTenantDecimalPlaces`/`getCurrencyConfig` below now
 * read `org_currency_cf` via `TenantCurrencyProfileService`. The two codes
 * stay listed here only until stage L4 soft-retires them in the settings
 * catalog itself; no other code path should read them for currency.
 */
export const SETTING_CODES = {
  TENANT_CURRENCY: 'TENANT_CURRENCY',
  TENANT_DECIMAL_PLACES: 'TENANT_DECIMAL_PLACES',
  TENANT_VAT_RATE: 'TENANT_VAT_RATE',
  DEFAULT_PHONE_COUNTRY_CODE: 'DEFAULT_PHONE_COUNTRY_CODE',
  USING_SPLIT_ORDER: 'USING_SPLIT_ORDER',
  USE_REJECT_TO_SOLVE: 'USE_REJECT_TO_SOLVE',
  USE_TRACK_BY_PIECE: 'USE_TRACK_BY_PIECE',
  REJECT_ROW_COLOR: 'REJECT_ROW_COLOR',
  AUTO_CLOSE_DAYS: 'AUTO_CLOSE_DAYS',
  PEAK_SEASON_START: 'PEAK_SEASON_START',
  TENANT_DEFAULT_GUEST_CUSTOMER_ID: 'TENANT_DEFAULT_GUEST_CUSTOMER_ID',
  SERVICE_PREF_PACKING_PER_PIECE_ENABLED: 'SERVICE_PREF_PACKING_PER_PIECE_ENABLED',
  SERVICE_PREF_ENFORCE_COMPATIBILITY: 'SERVICE_PREF_ENFORCE_COMPATIBILITY',
  SERVICE_PREF_PROCESSING_CONFIRMATION: 'SERVICE_PREF_PROCESSING_CONFIRMATION',
  SERVICE_PREF_AUTO_APPLY_CUSTOMER_PREFS: 'SERVICE_PREF_AUTO_APPLY_CUSTOMER_PREFS',
  B2B_CREDIT_LIMIT_MODE: 'B2B_CREDIT_LIMIT_MODE',
  B2B_DUNNING_LEVELS: 'B2B_DUNNING_LEVELS',
  ERP_LITE_ENABLED: 'ERP_LITE_ENABLED',
  ERP_LITE_FISCAL_YEAR_START: 'ERP_LITE_FISCAL_YEAR_START',
  ERP_LITE_FIRST_PERIOD_START: 'ERP_LITE_FIRST_PERIOD_START',
  ERP_LITE_PERIOD_CLOSE_ENABLED: 'ERP_LITE_PERIOD_CLOSE_ENABLED',
} as const;

/** Resolved settings map: setting code → parsed value (string, number, boolean) */
export type ResolvedSettingsMap = Record<string, string | number | boolean | null>;

export interface TenantProcessingSettings {
  splitOrderEnabled: boolean;
  rejectEnabled: boolean;
  trackByPiece: boolean;
  rejectColor: string;
  /** Per-piece packing preference (Enterprise, SERVICE_PREF_PACKING_PER_PIECE_ENABLED) */
  packingPerPieceEnabled: boolean;
  /** Block incompatible prefs (true) or warn only (false). SERVICE_PREF_ENFORCE_COMPATIBILITY */
  enforcePrefCompatibility: boolean;
  /** Require processing confirmation per piece (Enterprise). SERVICE_PREF_PROCESSING_CONFIRMATION */
  processingConfirmationEnabled: boolean;
}

export interface CurrencyConfig {
  currencyCode: string;
  decimalPlaces: number;
}

export class TenantSettingsService {
  private supabase: SupabaseClient;
  private currencyProfile: TenantCurrencyProfileService;

  constructor(supabase?: SupabaseClient) {
    this.supabase = supabase ?? createClient();
    this.currencyProfile = new TenantCurrencyProfileService(this.supabase);
  }

  /**
   * Get all resolved settings for tenant/branch/user in a single RPC call.
   * Uses fn_stng_resolve_all_settings (7-layer resolution).
   */
  async getAllResolvedSettings(
    tenantId: string,
    branchId?: string | null,
    userId?: string | null
  ): Promise<ResolvedSettingsMap> {
    try {
      const { data, error } = await this.supabase.rpc('fn_stng_resolve_all_settings', {
        p_tenant_id: tenantId,
        p_branch_id: branchId ?? null,
        p_user_id: userId ?? null,
      });

      if (error) {
        console.error('[TenantSettingsService] fn_stng_resolve_all_settings error:', error);
        return {};
      }

      const map: ResolvedSettingsMap = {};
      for (const row of data ?? []) {
        const code = row.stng_code as string;
        const jsonb = row.stng_value_jsonb;
        map[code] = parseJsonbValue(jsonb);
      }
      return map;
    } catch (err) {
      console.error('[TenantSettingsService] getAllResolvedSettings failed:', err);
      return {};
    }
  }

  /**
   * Check if a specific setting is allowed/enabled for the tenant.
   */
  async checkIfSettingAllowed(
    tenantId: string,
    settingCode: string,
    branchId?: string | null,
    userId?: string | null
  ): Promise<boolean> {
    const map = await this.getAllResolvedSettings(tenantId, branchId, userId);
    const v = map[settingCode];
    if (v === undefined || v === null) return false;
    if (typeof v === 'boolean') return v;
    if (typeof v === 'string') return v.toLowerCase() === 'true' || v === '1';
    if (typeof v === 'number') return v !== 0;
    return Boolean(v);
  }

  /**
   * Get the value of a specific setting for the tenant.
   */
  async getSettingValue(
    tenantId: string,
    settingCode: string,
    branchId?: string | null,
    userId?: string | null
  ): Promise<string | number | boolean | null> {
    const map = await this.getAllResolvedSettings(tenantId, branchId, userId);
    return map[settingCode] ?? null;
  }

  /**
   * Get raw JSONB value for a setting (e.g. B2B_DUNNING_LEVELS array).
   * Returns the value as-is from fn_stng_resolve_all_settings.
   */
  async getSettingValueJson(
    tenantId: string,
    settingCode: string,
    branchId?: string | null,
    userId?: string | null
  ): Promise<unknown> {
    try {
      const { data } = await this.supabase.rpc('fn_stng_resolve_all_settings', {
        p_tenant_id: tenantId,
        p_branch_id: branchId ?? null,
        p_user_id: userId ?? null,
      });
      const row = (data ?? []).find(
        (r: { stng_code?: string; setting_code?: string }) =>
          (r.stng_code ?? r.setting_code) === settingCode
      );
      const jsonb = row?.stng_value_jsonb;
      if (jsonb !== undefined && jsonb !== null && typeof jsonb === 'object' && 'value' in jsonb) {
        return (jsonb as { value: unknown }).value;
      }
      return jsonb ?? null;
    } catch {
      return null;
    }
  }

  /**
   * Get all processing-related settings for the tenant.
   */
  async getProcessingSettings(
    tenantId: string,
    branchId?: string | null,
    userId?: string | null
  ): Promise<TenantProcessingSettings> {
    const map = await this.getAllResolvedSettings(tenantId, branchId, userId);
    return {
      splitOrderEnabled: toBoolean(map[SETTING_CODES.USING_SPLIT_ORDER], false),
      rejectEnabled: toBoolean(map[SETTING_CODES.USE_REJECT_TO_SOLVE], false),
      trackByPiece: toBoolean(map[SETTING_CODES.USE_TRACK_BY_PIECE], false),
      rejectColor: toString(map[SETTING_CODES.REJECT_ROW_COLOR], '#10B981'),
      packingPerPieceEnabled: toBoolean(map[SETTING_CODES.SERVICE_PREF_PACKING_PER_PIECE_ENABLED], false),
      enforcePrefCompatibility: toBoolean(map[SETTING_CODES.SERVICE_PREF_ENFORCE_COMPATIBILITY], false),
      processingConfirmationEnabled: toBoolean(map[SETTING_CODES.SERVICE_PREF_PROCESSING_CONFIRMATION], false),
    };
  }

  /**
   * Get multiple boolean settings at once.
   */
  async getMultipleSettings(
    tenantId: string,
    settingCodes: string[],
    branchId?: string | null,
    userId?: string | null
  ): Promise<Record<string, boolean>> {
    const map = await this.getAllResolvedSettings(tenantId, branchId, userId);
    return settingCodes.reduce(
      (acc, code) => {
        acc[code] = toBoolean(map[code], false);
        return acc;
      },
      {} as Record<string, boolean>
    );
  }

  /**
   * Get tenant's configured (base/functional) currency code.
   *
   * L2 cut-over (Tenant_Currency_FX plan 01): reads `org_currency_cf` via
   * `TenantCurrencyProfileService`, not the retired `TENANT_CURRENCY` setting.
   * Currency has no branch/user override (`org_currency_cf` is tenant-only),
   * matching the scope the old setting already had.
   */
  async getTenantCurrency(
    tenantId: string,
    _branchId?: string | null,
    _userId?: string | null
  ): Promise<string> {
    const { base } = await this.currencyProfile.getProfile(tenantId);
    return base.currencyCode;
  }

  /**
   * Get tenant's configured decimal places for currency (`sys_currency_cd.minor_unit`, C8).
   */
  async getTenantDecimalPlaces(
    tenantId: string,
    _branchId?: string | null,
    _userId?: string | null
  ): Promise<number> {
    const { base } = await this.currencyProfile.getProfile(tenantId);
    return base.decimalPlaces;
  }

  /**
   * Get tenant's default phone country code (e.g. '+968', '+966').
   */
  async getDefaultPhoneCountryCode(
    tenantId: string,
    branchId?: string | null,
    _userId?: string | null
  ): Promise<string> {
    const map = await this.getAllResolvedSettings(tenantId, branchId ?? undefined);
    const v = map[SETTING_CODES.DEFAULT_PHONE_COUNTRY_CODE];
    const code = (typeof v === 'string' ? v : String(v ?? '')).trim();
    return code && code.startsWith('+') ? code : '+968';
  }

  /**
   * Get currency configuration (code + decimal places) in one call.
   */
  async getCurrencyConfig(
    tenantId: string,
    _branchId?: string | null,
    _userId?: string | null
  ): Promise<CurrencyConfig> {
    const { base } = await this.currencyProfile.getProfile(tenantId);
    return { currencyCode: base.currencyCode, decimalPlaces: base.decimalPlaces };
  }
}

/** Parse JSONB value from fn_stng_resolve_all_settings (string, number, boolean, or null) */
function parseJsonbValue(jsonb: unknown): string | number | boolean | null {
  if (jsonb === null || jsonb === undefined) return null;
  if (typeof jsonb === 'string' || typeof jsonb === 'number' || typeof jsonb === 'boolean') {
    return jsonb;
  }
  if (typeof jsonb === 'object' && jsonb !== null && 'value' in jsonb) {
    return (jsonb as { value: unknown }).value as string | number | boolean | null;
  }
  return String(jsonb);
}

function toBoolean(v: unknown, fallback: boolean): boolean {
  if (v === undefined || v === null) return fallback;
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') return v.toLowerCase() === 'true' || v === '1';
  if (typeof v === 'number') return v !== 0;
  return Boolean(v);
}

function toString(v: unknown, fallback: string): string {
  if (v === undefined || v === null) return fallback;
  const s = String(v).trim();
  return s || fallback;
}

/** Default instance for client-side usage (uses browser client) */
export const tenantSettingsService = new TenantSettingsService();

/**
 * Create a service instance with a specific Supabase client.
 * Use in server actions/API routes: createTenantSettingsService(await createServerSupabaseClient())
 */
export function createTenantSettingsService(supabase: SupabaseClient): TenantSettingsService {
  return new TenantSettingsService(supabase);
}
