/* eslint-disable jsdoc/require-jsdoc, jsdoc/require-param */
/**
 * Order Item Preference Service
 * CRUD for order item service prefs, packing pref, and service_pref_charge recalculation.
 */

import type { SupabaseClient } from '@supabase/supabase-js';
import type { OrderItemServicePref, PreferenceSource } from '@/lib/types/service-preferences';
import { PREFERENCE_SOURCES } from '@/lib/constants/service-preferences';
import { logger } from '@/lib/utils/logger';
import { fetchOrgPackingExtraPriceByCodesSupabase } from '@/lib/utils/org-packing-extra-price';
import type { AddServicePrefInput } from '@/lib/validations/service-preferences-schemas';

export type { AddServicePrefInput } from '@/lib/validations/service-preferences-schemas';

export class OrderItemPreferenceService {
  /**
   * Get service prefs for an order item
   */
  static async getItemServicePrefs(
    supabase: SupabaseClient,
    tenantId: string,
    orderItemId: string
  ): Promise<OrderItemServicePref[]> {
    const { data, error } = await supabase
      .from('org_order_preferences_dtl')
      .select('id, order_item_id, preference_code, preference_category, prefs_source, extra_price, branch_id')
      .eq('tenant_org_id', tenantId)
      .eq('order_item_id', orderItemId)
      .eq('prefs_level', 'ITEM')
      .eq('preference_sys_kind', 'service_prefs');

    if (error) {
      logger.error('Failed to get item service prefs', new Error(error.message), {
        tenantId,
        orderItemId,
        feature: 'order_item_preference',
      });
      return [];
    }

    return (data || []).map((r) => ({
      id: r.id,
      order_item_id: r.order_item_id,
      preference_code: r.preference_code,
      preference_category: r.preference_category,
      source: (r.prefs_source || PREFERENCE_SOURCES.MANUAL) as PreferenceSource,
      extra_price: Number(r.extra_price),
      branch_id: r.branch_id,
    }));
  }

  /**
   * Add service pref to order item and recalc service_pref_charge
   */
  static async addItemServicePref(
    supabase: SupabaseClient,
    tenantId: string,
    orderId: string,
    orderItemId: string,
    input: AddServicePrefInput,
    userId: string,
    userName: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: item } = await supabase
        .from('org_order_items_dtl')
        .select('id, tenant_org_id, order_id')
        .eq('id', orderItemId)
        .eq('order_id', orderId)
        .eq('tenant_org_id', tenantId)
        .single();

      if (!item) {
        return { success: false, error: 'Order item not found' };
      }

      const { data: maxNo } = await supabase
        .from('org_order_preferences_dtl')
        .select('prefs_no')
        .eq('tenant_org_id', tenantId)
        .eq('order_item_id', orderItemId)
        .eq('prefs_level', 'ITEM')
        .order('prefs_no', { ascending: false })
        .limit(1)
        .maybeSingle();

      const prefsNo = (maxNo?.prefs_no ?? 0) + 1;

      const { error: insertError } = await supabase
        .from('org_order_preferences_dtl')
        .insert({
          tenant_org_id: tenantId,
          order_id: orderId,
          prefs_no: prefsNo,
          prefs_level: 'ITEM',
          order_item_id: orderItemId,
          preference_code: input.preference_code,
          preference_content: input.preference_code,
          preference_sys_kind: 'service_prefs',
          prefs_source: input.source || PREFERENCE_SOURCES.MANUAL,
          extra_price: input.extra_price,
          branch_id: input.branch_id ?? null,
          created_by: userId,
        });

      if (insertError) {
        logger.error('Failed to add item service pref', new Error(insertError.message), {
          tenantId,
          orderItemId,
          feature: 'order_item_preference',
        });
        return { success: false, error: insertError.message };
      }

      await this.recalcItemServicePrefCharge(supabase, tenantId, orderItemId);
      return { success: true };
    } catch (err) {
      logger.error('OrderItemPreferenceService.addItemServicePref failed', err instanceof Error ? err : new Error(String(err)), {
        tenantId,
        orderItemId,
        feature: 'order_item_preference',
      });
      return { success: false, error: 'Failed to add service preference' };
    }
  }

  /**
   * Remove service pref from order item and recalc service_pref_charge
   */
  static async removeItemServicePref(
    supabase: SupabaseClient,
    tenantId: string,
    orderItemId: string,
    prefId: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('org_order_preferences_dtl')
        .delete()
        .eq('tenant_org_id', tenantId)
        .eq('order_item_id', orderItemId)
        .eq('prefs_level', 'ITEM')
        .eq('id', prefId);

      if (error) {
        logger.error('Failed to remove item service pref', new Error(error.message), {
          tenantId,
          orderItemId,
          feature: 'order_item_preference',
        });
        return { success: false, error: error.message };
      }

      await this.recalcItemServicePrefCharge(supabase, tenantId, orderItemId);
      return { success: true };
    } catch (err) {
      logger.error('OrderItemPreferenceService.removeItemServicePref failed', err instanceof Error ? err : new Error(String(err)), {
        tenantId,
        orderItemId,
        feature: 'order_item_preference',
      });
      return { success: false, error: 'Failed to remove service preference' };
    }
  }

  /**
   * Update packing preference for order item
   */
  static async updateItemPackingPref(
    supabase: SupabaseClient,
    tenantId: string,
    orderItemId: string,
    packingPrefCode: string,
    packingPrefIsOverride?: boolean,
    packingPrefSource?: string
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('org_order_items_dtl')
        .update({
          packing_pref_code: packingPrefCode,
          packing_pref_is_override: packingPrefIsOverride ?? false,
          packing_pref_source: packingPrefSource ?? null,
        })
        .eq('tenant_org_id', tenantId)
        .eq('id', orderItemId);

      if (error) {
        logger.error('Failed to update item packing pref', new Error(error.message), {
          tenantId,
          orderItemId,
          feature: 'order_item_preference',
        });
        return { success: false, error: error.message };
      }

      const packingPriceMap = await fetchOrgPackingExtraPriceByCodesSupabase(supabase, tenantId, [
        packingPrefCode,
      ]);
      const packExtra = packingPriceMap.get(packingPrefCode) ?? 0;

      // Sync packing pref into org_order_preferences_dtl (ITEM level)
      const { data: existing } = await supabase
        .from('org_order_preferences_dtl')
        .select('id')
        .eq('tenant_org_id', tenantId)
        .eq('order_item_id', orderItemId)
        .eq('preference_sys_kind', 'packing_prefs')
        .is('order_item_piece_id', null)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('org_order_preferences_dtl')
          .update({
            preference_code: packingPrefCode,
            preference_content: packingPrefCode,
            prefs_owner_type: packingPrefIsOverride ? 'OVERRIDE' : 'SYSTEM',
            prefs_source: packingPrefSource ?? 'ORDER_UPDATE',
            extra_price: packExtra,
            updated_at: new Date().toISOString(),
          })
          .eq('tenant_org_id', tenantId)
          .eq('id', existing.id);
      } else {
        const { data: itemRow } = await supabase
          .from('org_order_items_dtl')
          .select('order_id, branch_id')
          .eq('tenant_org_id', tenantId)
          .eq('id', orderItemId)
          .single();

        if (itemRow) {
          await supabase.from('org_order_preferences_dtl').insert({
            tenant_org_id: tenantId,
            order_id: itemRow.order_id,
            prefs_no: 1,
            prefs_level: 'ITEM',
            order_item_id: orderItemId,
            preference_code: packingPrefCode,
            preference_content: packingPrefCode,
            preference_sys_kind: 'packing_prefs',
            prefs_owner_type: packingPrefIsOverride ? 'OVERRIDE' : 'SYSTEM',
            prefs_source: packingPrefSource ?? 'ORDER_UPDATE',
            extra_price: packExtra,
            branch_id: itemRow.branch_id ?? null,
          });
        }
      }

      await this.recalcItemServicePrefCharge(supabase, tenantId, orderItemId);

      return { success: true };
    } catch (err) {
      logger.error('OrderItemPreferenceService.updateItemPackingPref failed', err instanceof Error ? err : new Error(String(err)), {
        tenantId,
        orderItemId,
        feature: 'order_item_preference',
      });
      return { success: false, error: 'Failed to update packing preference' };
    }
  }

  /**
   * Recalculate `service_pref_charge` on the item row: sum of ITEM-level `extra_price` for
   * `service_prefs` and `packing_prefs` (piece-level rows use `prefs_level=PIECE` and are excluded).
   */
  static async recalcItemServicePrefCharge(
    supabase: SupabaseClient,
    tenantId: string,
    orderItemId: string
  ): Promise<void> {
    try {
      const { data: prefs } = await supabase
        .from('org_order_preferences_dtl')
        .select('extra_price, preference_sys_kind')
        .eq('tenant_org_id', tenantId)
        .eq('order_item_id', orderItemId)
        .eq('prefs_level', 'ITEM')
        .in('preference_sys_kind', ['service_prefs', 'packing_prefs']);

      const total = (prefs || []).reduce((acc, p) => acc + Number(p.extra_price), 0);

      await supabase
        .from('org_order_items_dtl')
        .update({ service_pref_charge: total })
        .eq('tenant_org_id', tenantId)
        .eq('id', orderItemId);
    } catch (err) {
      logger.error('OrderItemPreferenceService.recalcItemServicePrefCharge failed', err instanceof Error ? err : new Error(String(err)), {
        tenantId,
        orderItemId,
        feature: 'order_item_preference',
      });
    }
  }
}
