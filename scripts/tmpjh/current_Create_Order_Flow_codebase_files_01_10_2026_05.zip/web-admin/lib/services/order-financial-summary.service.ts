import 'server-only';

import { Decimal } from '@prisma/client/runtime/library';

import { prisma } from '@/lib/db/prisma';
import { withTenantContext } from '@/lib/db/tenant-context';
import { getDiscountLinesForOrder } from '@/lib/db/order-discounts';
import { normalizeOrderPaymentStatus } from '@/lib/utils/order-payment-status';
import { buildEffectiveOrderFinancialSnapshot } from '@/lib/utils/order-financial-effective-snapshot';
import { ORDER_FINANCIAL_SNAPSHOT_STATUS } from '@/lib/constants/order-financial';

/**
 * Why:
 * Order Fin now exposes one richer read model so checkout, order detail,
 * reports, and future mobile/API consumers all read the same financial truth
 * instead of stitching together partial views independently.
 */

/**
 *
 */
export interface OrderFinancialSnapshot {
  orderId: string;
  orderNo: string | null;
  currencyCode: string | null;
  currencyExRate: number;
  baseCurCurrencyCode: string | null;
  paymentTypeCode: string | null;
  paymentStatus: string;
  subtotalAmount: number;
  itemsBaseAmount: number;
  pieceExtraPriceAmount: number;
  preferenceExtraPriceAmount: number;
  serviceChargeAmount: number;
  deliveryChargeAmount: number;
  expressChargeAmount: number;
  otherChargesAmount: number;
  totalChargesAmount: number;
  totalDiscountAmount: number;
  taxableAmount: number;
  /**
   * Tax-base decomposition (v1.1 §8.11). The tax engine currently emits only
   * `taxableAmount`; the four bucket fields below default to 0 until Phase 5
   * wires bucket classification. Surfaced here so UI breakdowns and reports
   * have a stable read contract once the engine starts populating them.
   */
  nonTaxableAmount: number;
  exemptAmount: number;
  zeroRatedAmount: number;
  outOfScopeAmount: number;
  totalTaxAmount: number;
  totalAmount: number;
  totalPaidAmount: number;
  pendingPaymentAmount: number;
  authorizedPaymentAmount: number;
  failedPaymentAmount: number;
  totalCreditAppliedAmount: number;
  pendingCreditApplicationAmount: number;
  failedCreditApplicationAmount: number;
  refundedAmount: number;
  realPaymentRefundedAmount: number;
  storedValueRestoredAmount: number;
  customerCreditIssuedAmount: number;
  netCollectedAmount: number;
  outstandingAmount: number;
  overpaidAmount: number;
  payOnCollectionAmount: number;
  arReceivableAmount: number;
  baseCurTotalAmount: number;
  baseCurTaxAmount: number;
  baseCurPaidAmount: number;
  baseCurCreditAppliedAmount: number;
  baseCurOutstandingAmount: number;
  baseCurArReceivableAmount: number;
  arInvoiceId: string | null;
  arInvoiceNo: string | null;
  arInvoiceStatus: string | null;
  taxDocumentId: string | null;
  taxDocumentNo: string | null;
  taxDocumentStatus: string | null;
  taxDocumentType: string | null;
  financialSnapshotStatus: string;
  financialMismatchWarningCount: number;
  financialCalculationSnapshot: Record<string, unknown> | null;
  financialCalculationHash: string | null;
  financialCalculationTraceId: string | null;
  financialEngineVersion: number | null;
  changeReturnedAmount: number;
  roundingAmount: number;
}

/**
 *
 */
export interface OrderChargeRow {
  id: string;
  charge_type: string;
  label: string | null;
  label2: string | null;
  amount: number;
  currency_code: string | null;
  is_voided: boolean;
  voided_at: string | null;
  voided_by: string | null;
  void_reason: string | null;
}

/**
 *
 */
export interface OrderTaxRow {
  id: string;
  tax_type: string;
  label: string;
  rate: number;
  tax_amount: number;
  taxable_amount?: number;
  currency_code: string;
}

/**
 *
 */
export interface OrderPaymentRow {
  id: string;
  payment_method_code: string | null;
  payment_method_name_snapshot: string | null;
  payment_nature_snapshot: string | null;
  amount: number;
  currency_code: string | null;
  tendered_amount: number | null;
  change_returned_amount: number | null;
  payment_status: string | null;
  received_by: string | null;
  gateway_code: string | null;
  gateway_transaction_id: string | null;
  gateway_reference: string | null;
  card_brand_code: string | null;
  card_last4: string | null;
  check_no: string | null;
  bank_reference: string | null;
  branch_payment_method_id: string | null;
  paid_at: string | null;
  created_at: string;
  rec_notes: string | null;
  fin_voucher_id: string | null;
}

/**
 *
 */
export interface OrderCreditApplicationRow {
  id: string;
  credit_type: string;
  application_status: string | null;
  credit_source_id: string | null;
  applied_amount: number;
  currency_code: string;
  reference_no: string | null;
  applied_by: string | null;
  applied_at: string;
  fin_voucher_id: string | null;
}

/**
 *
 */
export interface OrderRefundRow {
  id: string;
  refund_no: string | null;
  refund_amount: number;
  refund_status: string | null;
  refund_method_code: string | null;
  reason_code: string | null;
  currency_code: string | null;
  original_payment_id: string | null;
  /** B01 lineage: credit application whose applied value this refund returns (mig 0404). */
  original_credit_app_id: string | null;
  /** Phase 6+ canonical classification of the refund source (ADR-030; D002 v2 origin-only registry). */
  refund_source_type: string | null;
  /** B01 (D002 v2) reason_context — drives the D003 v2 reopen rules; null on pre-0404 rows. */
  refund_context: string | null;
  /** Amount that will reopen the order balance when this refund is processed (Phase 6+). */
  reopens_due_amount: number;
  metadata: Record<string, unknown>;
  created_at: string;
}

/** A single tax document record from org_tax_documents_mst for display in the UI. */
export interface TaxDocumentSummaryRow {
  id: string;
  document_type: string;
  trigger_event: string;
  status: string;
  fiscal_year: number;
  sequence_number: number;
  document_no: string | null;
  total_amount: number;
  tax_amount: number;
  currency_code: string | null;
  supersedes_id: string | null;
  issued_at: string | null;
  issued_by: string | null;
  cancelled_at: string | null;
  cancellation_reason: string | null;
  created_at: string;
}

/**
 *
 */
export interface OrderAdjustmentRow {
  id: string;
  adjustment_type: string;
  amount: number;
  currency_code: string;
  reason: string | null;
  status: string;
  approved_by: string | null;
  created_by: string | null;
  created_at: string;
  metadata: Record<string, unknown>;
}

/**
 *
 */
export interface OrderDiscountRow {
  id: string;
  source_type: string;
  source_name: string | null;
  discount_type: string;
  discount_rate: number | null;
  discount_amount: number;
}

/**
 *
 */
export interface OrderFinancialTimelineRow {
  id: string;
  eventType: string;
  status: string | null;
  amount: number | null;
  happenedAt: string;
}

/**
 *
 */
export interface OrderFinancialSummary {
  snapshot: OrderFinancialSnapshot;
  taxDocuments: TaxDocumentSummaryRow[];
  charges: OrderChargeRow[];
  discounts: OrderDiscountRow[];
  taxes: OrderTaxRow[];
  payments: OrderPaymentRow[];
  creditApplications: OrderCreditApplicationRow[];
  refunds: OrderRefundRow[];
  adjustments: OrderAdjustmentRow[];
  voucherReferences: Array<{ voucherId: string; voucherLineId: string | null; source: 'PAYMENT' | 'REFUND' | 'CREDIT_APPLICATION' }>;
  auditTimeline: OrderFinancialTimelineRow[];
}

function toNumber(value: Decimal | number | string | null | undefined): number {
  if (value == null) return 0;
  return Number(value);
}

function toIso(value: Date | string | null | undefined): string {
  if (!value) return new Date(0).toISOString();
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function toRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

/** Structural shape of an `org_order_payments_dtl` row as returned by Prisma. */
interface OrderPaymentDbRow {
  id: string;
  payment_method_code: string | null;
  payment_method_name_snapshot: string | null;
  payment_nature_snapshot: string | null;
  amount: Decimal | number | null;
  currency_code: string | null;
  tendered_amount: Decimal | number | null;
  change_returned_amount: Decimal | number | null;
  payment_status: string | null;
  received_by: string | null;
  gateway_code: string | null;
  gateway_transaction_id: string | null;
  gateway_reference: string | null;
  card_brand_code: string | null;
  card_last4: string | null;
  check_no: string | null;
  bank_reference: string | null;
  branch_payment_method_id: string | null;
  paid_at: Date | string | null;
  created_at: Date | string;
  rec_notes: string | null;
  fin_voucher_id: string | null;
}

function mapOrderPaymentRow(row: OrderPaymentDbRow): OrderPaymentRow {
  return {
    id: row.id,
    payment_method_code: row.payment_method_code ?? null,
    payment_method_name_snapshot: row.payment_method_name_snapshot ?? null,
    payment_nature_snapshot: row.payment_nature_snapshot ?? null,
    amount: toNumber(row.amount),
    currency_code: row.currency_code ?? null,
    tendered_amount: row.tendered_amount == null ? null : toNumber(row.tendered_amount),
    change_returned_amount:
      row.change_returned_amount == null ? null : toNumber(row.change_returned_amount),
    payment_status: row.payment_status ?? null,
    received_by: row.received_by ?? null,
    gateway_code: row.gateway_code ?? null,
    gateway_transaction_id: row.gateway_transaction_id ?? null,
    gateway_reference: row.gateway_reference ?? null,
    card_brand_code: row.card_brand_code ?? null,
    card_last4: row.card_last4 ?? null,
    check_no: row.check_no ?? null,
    bank_reference: row.bank_reference ?? null,
    branch_payment_method_id: row.branch_payment_method_id ?? null,
    paid_at: row.paid_at ? toIso(row.paid_at) : null,
    created_at: toIso(row.created_at),
    rec_notes: row.rec_notes ?? null,
    fin_voucher_id: row.fin_voucher_id ?? null,
  };
}

/**
 * Canonical order-payment rows for display surfaces (Payments tab, prints).
 *
 * Why:
 * `org_order_payments_dtl` is the single payment truth for orders (ADR-002 —
 * the legacy payments ledger is deprecated and unwritten by the canonical flow).
 * Every UI/report that lists an order's payments must read through here so it
 * can never diverge from the financial snapshot built over the same rows.
 *
 * @param tenantId authenticated tenant identifier
 * @param orderId order header identifier
 * @returns active payment rows, newest first
 */
export async function getOrderPaymentsCanonical(
  tenantId: string,
  orderId: string,
): Promise<OrderPaymentRow[]> {
  const rows = await withTenantContext(tenantId, () =>
    prisma.org_order_payments_dtl.findMany({
      where: { tenant_org_id: tenantId, order_id: orderId, is_active: true },
      orderBy: { created_at: 'desc' },
    }),
  );
  return rows.map(mapOrderPaymentRow);
}

function sumProcessedRefunds(refunds: Array<{ refund_status: string | null; refund_amount: Decimal }>): number {
  return refunds.reduce((sum, row) => {
    return String(row.refund_status ?? '').trim().toUpperCase() === 'PROCESSED'
      ? sum + toNumber(row.refund_amount)
      : sum;
  }, 0);
}

function sumRealPaymentRefunds(refunds: Array<{
  refund_status: string | null;
  refund_amount: Decimal;
  refund_method_code: string | null;
  original_payment_id: string | null;
}>): number {
  return refunds.reduce((sum, row) => {
    if (String(row.refund_status ?? '').trim().toUpperCase() !== 'PROCESSED') return sum;

    const method = String(row.refund_method_code ?? '').trim().toUpperCase();
    if (method === 'CASH' || method === 'ORIGINAL_METHOD' || row.original_payment_id) {
      return sum + toNumber(row.refund_amount);
    }

    return sum;
  }, 0);
}

/**
 * Read the full Order Fin summary for one order under tenant scope.
 *
 * @param tenantId authenticated tenant identifier
 * @param orderId order header identifier
 * @returns normalized read model used by routes and server actions
 */
export async function getOrderFinancialSummary(
  tenantId: string,
  orderId: string,
): Promise<OrderFinancialSummary> {
  let adjustments: OrderAdjustmentRow[] = [];

  const [
    order,
    charges,
    taxes,
    payments,
    creditApplications,
    refunds,
    discountLines,
    taxDocumentRows,
  ] = await Promise.all([
    withTenantContext(tenantId, () =>
      prisma.org_orders_mst.findFirstOrThrow({
        where: { tenant_org_id: tenantId, id: orderId },
        select: {
          id: true,
          order_no: true,
          currency_code: true,
          currency_ex_rate: true,
          base_cur_currency_code: true,
          base_cur_total_amount: true,
          base_cur_tax_amount: true,
          base_cur_paid_amount: true,
          base_cur_credit_applied_amount: true,
          base_cur_outstanding_amount: true,
          base_cur_ar_receivable_amount: true,
          payment_type_code: true,
          payment_status: true,
          subtotal_amount: true,
          items_base_amount: true,
          total_amount: true,
          piece_extra_price_amount: true,
          preference_extra_price_amount: true,
          service_charge_amount: true,
          delivery_charge_amount: true,
          express_charge_amount: true,
          other_charges_amount: true,
          total_charges_amount: true,
          total_discount_amount: true,
          taxable_amount: true,
          non_taxable_amount: true,
          exempt_amount: true,
          zero_rated_amount: true,
          out_of_scope_amount: true,
          total_tax_amount: true,
          total_credit_applied_amount: true,
          pending_credit_application_amount: true,
          failed_credit_application_amount: true,
          total_paid_amount: true,
          pending_payment_amount: true,
          authorized_payment_amount: true,
          failed_payment_amount: true,
          refunded_amount: true,
          real_payment_refunded_amount: true,
          stored_value_restored_amount: true,
          customer_credit_issued_amount: true,
          net_collected_amount: true,
          outstanding_amount: true,
          overpaid_amount: true,
          ar_receivable_amount: true,
          ar_invoice_id: true,
          ar_invoice_no: true,
          ar_invoice_status: true,
          tax_document_id: true,
          tax_document_no: true,
          tax_document_status: true,
          tax_document_type: true,
          pay_on_collection_amount: true,
          change_returned_amount: true,
          rounding_adjustment_amount: true,
          financial_engine_version: true,
          financial_snapshot_status: true,
          financial_mismatch_warning_count: true,
          financial_calculation_snapshot: true,
          financial_calculation_hash: true,
          financial_calculation_trace_id: true,
        },
      }),
    ),
    withTenantContext(tenantId, () =>
      prisma.org_order_charges_dtl.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId },
        orderBy: { created_at: 'asc' },
      }),
    ),
    withTenantContext(tenantId, () =>
      prisma.org_order_taxes_dtl.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId },
        orderBy: { created_at: 'asc' },
      }),
    ),
    withTenantContext(tenantId, () =>
      prisma.org_order_payments_dtl.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId, is_active: true },
        orderBy: { created_at: 'asc' },
      }),
    ),
    withTenantContext(tenantId, () =>
      prisma.org_order_credit_apps_dtl.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId },
        orderBy: { applied_at: 'asc' },
      }),
    ),
    withTenantContext(tenantId, () =>
      prisma.org_order_refunds_dtl.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId, is_active: true },
        orderBy: { created_at: 'asc' },
      }),
    ),
    getDiscountLinesForOrder(tenantId, orderId),
    withTenantContext(tenantId, () =>
      prisma.org_tax_documents_mst.findMany({
        where: { tenant_org_id: tenantId, order_id: orderId, is_active: true },
        orderBy: { created_at: 'desc' },
      }),
    ),
  ]);

  try {
    adjustments = await prisma.$queryRaw<OrderAdjustmentRow[]>`
      SELECT
        a.id,
        a.adjustment_type,
        a.amount::float8 AS amount,
        a.currency_code,
        a.reason,
        a.status,
        a.approved_by,
        a.created_by,
        a.created_at,
        a.metadata
      FROM public.org_order_adjustments_dtl a
      WHERE a.tenant_org_id = ${tenantId}::uuid
        AND a.order_id = ${orderId}::uuid
        AND a.is_active = true
        AND a.rec_status = 1
      ORDER BY a.created_at ASC
    `;
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    if (!message.includes('org_order_adjustments_dtl')) {
      throw error;
    }
  }

  const effectiveSnapshot = buildEffectiveOrderFinancialSnapshot({
    paymentTypeCode: order.payment_type_code ?? null,
    roundingAmount: toNumber(order.rounding_adjustment_amount),
    snapshot: {
      subtotalAmount: toNumber(order.subtotal_amount),
      itemsBaseAmount: toNumber(order.items_base_amount),
      pieceExtraPriceAmount: toNumber(order.piece_extra_price_amount),
      preferenceExtraPriceAmount: toNumber(order.preference_extra_price_amount),
      serviceChargeAmount: toNumber(order.service_charge_amount),
      deliveryChargeAmount: toNumber(order.delivery_charge_amount),
      expressChargeAmount: toNumber(order.express_charge_amount),
      otherChargesAmount: toNumber(order.other_charges_amount),
      totalChargesAmount: toNumber(order.total_charges_amount),
      totalDiscountAmount: toNumber(order.total_discount_amount),
      taxableAmount: toNumber(order.taxable_amount),
      nonTaxableAmount: toNumber(order.non_taxable_amount),
      exemptAmount: toNumber(order.exempt_amount),
      zeroRatedAmount: toNumber(order.zero_rated_amount),
      outOfScopeAmount: toNumber(order.out_of_scope_amount),
      totalTaxAmount: toNumber(order.total_tax_amount),
      totalAmount: toNumber(order.total_amount),
      totalPaidAmount: toNumber(order.total_paid_amount),
      pendingPaymentAmount: toNumber(order.pending_payment_amount),
      authorizedPaymentAmount: toNumber(order.authorized_payment_amount),
      failedPaymentAmount: toNumber(order.failed_payment_amount),
      totalCreditAppliedAmount: toNumber(order.total_credit_applied_amount),
      pendingCreditApplicationAmount: toNumber(order.pending_credit_application_amount),
      failedCreditApplicationAmount: toNumber(order.failed_credit_application_amount),
      refundedAmount: toNumber(order.refunded_amount),
      realPaymentRefundedAmount: toNumber(order.real_payment_refunded_amount),
      storedValueRestoredAmount: toNumber(order.stored_value_restored_amount),
      customerCreditIssuedAmount: toNumber(order.customer_credit_issued_amount),
      netCollectedAmount: toNumber(order.net_collected_amount),
      outstandingAmount: toNumber(order.outstanding_amount),
      overpaidAmount: toNumber(order.overpaid_amount),
      payOnCollectionAmount: toNumber(order.pay_on_collection_amount),
      arReceivableAmount: toNumber(order.ar_receivable_amount),
      currencyExRate: toNumber(order.currency_ex_rate),
      baseCurCurrencyCode: order.base_cur_currency_code ?? null,
      baseCurTotalAmount: toNumber(order.base_cur_total_amount),
      baseCurTaxAmount: toNumber(order.base_cur_tax_amount),
      baseCurPaidAmount: toNumber(order.base_cur_paid_amount),
      baseCurCreditAppliedAmount: toNumber(order.base_cur_credit_applied_amount),
      baseCurOutstandingAmount: toNumber(order.base_cur_outstanding_amount),
      baseCurArReceivableAmount: toNumber(order.base_cur_ar_receivable_amount),
    },
    charges: charges.map((row) => ({
      charge_type: row.charge_type,
      amount: toNumber(row.amount),
    })),
    discounts: discountLines.map((row) => ({
      discount_amount: row.discount_amount,
    })),
    taxes: taxes.map((row) => ({
      tax_amount: toNumber(row.tax_amount),
      taxable_amount: toNumber(row.taxable_amount),
    })),
    payments: payments.map((row) => ({
      amount: toNumber(row.amount),
      payment_status: row.payment_status ?? null,
      payment_nature_snapshot: row.payment_nature_snapshot ?? null,
      payment_method_code: row.payment_method_code ?? null,
      gateway_code: row.gateway_code ?? null,
      gateway_reference: row.gateway_reference ?? null,
      branch_payment_method_id: row.branch_payment_method_id ?? null,
    })),
    creditApplications: creditApplications.map((row) => ({
      applied_amount: toNumber(row.applied_amount),
      application_status: row.application_status ?? null,
    })),
    refunds: refunds.map((row) => ({
      refund_amount: toNumber(row.refund_amount),
      refund_status: row.refund_status ?? null,
      refund_method_code: row.refund_method_code ?? null,
      original_payment_id: row.original_payment_id ?? null,
      // B01/B02: five-facet facts so the read fallback classifies column-first
      // and includes the D005 refundReopens term.
      refund_source_type: (row as Record<string, unknown>).refund_source_type as string | null ?? null,
      reopens_due_amount: toNumber((row as Record<string, unknown>).reopens_due_amount as number | null),
      metadata: row.metadata ?? {},
    })),
  });

  const totalAmount = effectiveSnapshot.totalAmount;
  const totalPaidAmount = effectiveSnapshot.totalPaidAmount;
  const totalCreditAppliedAmount = effectiveSnapshot.totalCreditAppliedAmount;
  const refundedAmount = effectiveSnapshot.refundedAmount || sumProcessedRefunds(refunds);
  const realPaymentRefundedAmount =
    effectiveSnapshot.realPaymentRefundedAmount || sumRealPaymentRefunds(refunds);
  const outstandingAmount = effectiveSnapshot.outstandingAmount;
  const payOnCollectionAmount = effectiveSnapshot.payOnCollectionAmount;

  const normalizedPaymentStatus = normalizeOrderPaymentStatus(order.payment_status, {
    paymentTypeCode: order.payment_type_code ?? null,
    payOnCollectionAmount,
    outstandingAmount,
  });

  const financialSnapshotStatus =
    effectiveSnapshot.usedReadFallback
      && (order.financial_snapshot_status == null
        || order.financial_snapshot_status === ORDER_FINANCIAL_SNAPSHOT_STATUS.CURRENT)
      ? ORDER_FINANCIAL_SNAPSHOT_STATUS.RECALCULATION_REQUIRED
      : order.financial_snapshot_status ?? ORDER_FINANCIAL_SNAPSHOT_STATUS.RECALCULATION_REQUIRED;

  const snapshot: OrderFinancialSnapshot = {
    orderId: order.id,
    orderNo: order.order_no ?? null,
    currencyCode: order.currency_code ?? null,
    currencyExRate: toNumber(order.currency_ex_rate),
    baseCurCurrencyCode: effectiveSnapshot.baseCurCurrencyCode,
    paymentTypeCode: order.payment_type_code ?? null,
    paymentStatus: normalizedPaymentStatus,
    subtotalAmount: effectiveSnapshot.subtotalAmount,
    itemsBaseAmount: effectiveSnapshot.itemsBaseAmount,
    pieceExtraPriceAmount: effectiveSnapshot.pieceExtraPriceAmount,
    preferenceExtraPriceAmount: effectiveSnapshot.preferenceExtraPriceAmount,
    serviceChargeAmount: effectiveSnapshot.serviceChargeAmount,
    deliveryChargeAmount: effectiveSnapshot.deliveryChargeAmount,
    expressChargeAmount: effectiveSnapshot.expressChargeAmount,
    otherChargesAmount: effectiveSnapshot.otherChargesAmount,
    totalChargesAmount: effectiveSnapshot.totalChargesAmount,
    totalDiscountAmount: effectiveSnapshot.totalDiscountAmount,
    taxableAmount: effectiveSnapshot.taxableAmount,
    nonTaxableAmount: effectiveSnapshot.nonTaxableAmount,
    exemptAmount: effectiveSnapshot.exemptAmount,
    zeroRatedAmount: effectiveSnapshot.zeroRatedAmount,
    outOfScopeAmount: effectiveSnapshot.outOfScopeAmount,
    totalTaxAmount: effectiveSnapshot.totalTaxAmount,
    totalAmount,
    totalPaidAmount,
    pendingPaymentAmount: effectiveSnapshot.pendingPaymentAmount,
    authorizedPaymentAmount: effectiveSnapshot.authorizedPaymentAmount,
    failedPaymentAmount: effectiveSnapshot.failedPaymentAmount,
    totalCreditAppliedAmount,
    pendingCreditApplicationAmount: effectiveSnapshot.pendingCreditApplicationAmount,
    failedCreditApplicationAmount: effectiveSnapshot.failedCreditApplicationAmount,
    refundedAmount,
    realPaymentRefundedAmount,
    storedValueRestoredAmount: effectiveSnapshot.storedValueRestoredAmount,
    customerCreditIssuedAmount: effectiveSnapshot.customerCreditIssuedAmount,
    netCollectedAmount: effectiveSnapshot.netCollectedAmount || Math.max(0, totalPaidAmount - realPaymentRefundedAmount),
    outstandingAmount,
    overpaidAmount: effectiveSnapshot.overpaidAmount || Math.max(0, totalPaidAmount + totalCreditAppliedAmount - totalAmount),
    payOnCollectionAmount,
    arReceivableAmount: effectiveSnapshot.arReceivableAmount,
    baseCurTotalAmount: effectiveSnapshot.baseCurTotalAmount,
    baseCurTaxAmount: effectiveSnapshot.baseCurTaxAmount,
    baseCurPaidAmount: effectiveSnapshot.baseCurPaidAmount,
    baseCurCreditAppliedAmount: effectiveSnapshot.baseCurCreditAppliedAmount,
    baseCurOutstandingAmount: effectiveSnapshot.baseCurOutstandingAmount,
    baseCurArReceivableAmount: effectiveSnapshot.baseCurArReceivableAmount,
    arInvoiceId: order.ar_invoice_id ?? null,
    arInvoiceNo: order.ar_invoice_no ?? null,
    arInvoiceStatus: order.ar_invoice_status ?? null,
    taxDocumentId: order.tax_document_id ?? null,
    taxDocumentNo: order.tax_document_no ?? null,
    taxDocumentStatus: order.tax_document_status ?? null,
    taxDocumentType: order.tax_document_type ?? null,
    financialSnapshotStatus,
    financialMismatchWarningCount: order.financial_mismatch_warning_count ?? 0,
    financialCalculationSnapshot: toRecord(order.financial_calculation_snapshot),
    financialCalculationHash: order.financial_calculation_hash ?? null,
    financialCalculationTraceId: order.financial_calculation_trace_id ?? null,
    financialEngineVersion: order.financial_engine_version ?? null,
    changeReturnedAmount: toNumber(order.change_returned_amount),
    roundingAmount: toNumber(order.rounding_adjustment_amount),
  };

  const voucherReferences = [
    ...payments
      .filter((row) => row.fin_voucher_id || row.fin_voucher_trx_line_id)
      .map((row) => ({
        voucherId: row.fin_voucher_id ?? '',
        voucherLineId: row.fin_voucher_trx_line_id ?? null,
        source: 'PAYMENT' as const,
      })),
    ...refunds
      .map((row) => {
        const metadata = row.metadata as Record<string, unknown>;
        const voucherId = typeof metadata.fin_voucher_id === 'string' ? metadata.fin_voucher_id : '';
        const voucherLineId = typeof metadata.fin_voucher_trx_line_id === 'string'
          ? metadata.fin_voucher_trx_line_id
          : null;
        return voucherId || voucherLineId
          ? { voucherId, voucherLineId, source: 'REFUND' as const }
          : null;
      })
      .filter((row): row is { voucherId: string; voucherLineId: string | null; source: 'REFUND' } => row !== null),
    ...creditApplications
      .map((row) => {
        const metadata = row.metadata as Record<string, unknown>;
        const voucherId = typeof metadata.fin_voucher_id === 'string' ? metadata.fin_voucher_id : '';
        const voucherLineId = typeof metadata.fin_voucher_trx_line_id === 'string'
          ? metadata.fin_voucher_trx_line_id
          : null;
        return voucherId || voucherLineId
          ? { voucherId, voucherLineId, source: 'CREDIT_APPLICATION' as const }
          : null;
      })
      .filter((row): row is { voucherId: string; voucherLineId: string | null; source: 'CREDIT_APPLICATION' } => row !== null),
  ];

  const auditTimeline: OrderFinancialTimelineRow[] = [
    ...payments.map((row) => ({
      id: row.id,
      eventType: 'PAYMENT',
      status: row.payment_status,
      amount: toNumber(row.amount),
      happenedAt: toIso(row.created_at),
    })),
    ...creditApplications.map((row) => ({
      id: row.id,
      eventType: 'CREDIT_APPLICATION',
      status: row.application_status ?? row.credit_type,
      amount: toNumber(row.applied_amount),
      happenedAt: toIso(row.applied_at),
    })),
    ...refunds.map((row) => ({
      id: row.id,
      eventType: 'REFUND',
      status: row.refund_status,
      amount: toNumber(row.refund_amount),
      happenedAt: toIso(row.created_at),
    })),
    ...adjustments.map((row) => ({
      id: row.id,
      eventType: 'ADJUSTMENT',
      status: row.status,
      amount: toNumber(row.amount),
      happenedAt: toIso(row.created_at),
    })),
  ].sort((a, b) => a.happenedAt.localeCompare(b.happenedAt));

  return {
    snapshot,
    charges: charges.map((row) => ({
      id: row.id,
      charge_type: row.charge_type,
      label: row.label ?? null,
      label2: row.label2 ?? null,
      amount: toNumber(row.amount),
      currency_code: row.currency_code ?? null,
      is_voided: row.is_voided,
      voided_at: row.voided_at ? toIso(row.voided_at) : null,
      voided_by: row.voided_by ?? null,
      void_reason: row.void_reason ?? null,
    })),
    discounts: discountLines.map((row) => ({
      id: row.id,
      source_type: row.source_type,
      source_name: row.source_name ?? null,
      discount_type: row.discount_type,
      discount_rate: row.discount_rate ?? null,
      discount_amount: row.discount_amount,
    })),
    taxes: taxes.map((row) => ({
      id: row.id,
      tax_type: row.tax_type,
      label: row.label,
      rate: toNumber(row.rate),
      tax_amount: toNumber(row.tax_amount),
      taxable_amount: toNumber(row.taxable_amount),
      currency_code: row.currency_code,
    })),
    payments: payments.map(mapOrderPaymentRow),
    creditApplications: creditApplications.map((row) => ({
      id: row.id,
      credit_type: row.credit_type,
      application_status: row.application_status ?? null,
      credit_source_id: row.credit_source_id ?? null,
      applied_amount: toNumber(row.applied_amount),
      currency_code: row.currency_code,
      reference_no: row.reference_no ?? null,
      applied_by: row.applied_by ?? null,
      applied_at: toIso(row.applied_at),
      fin_voucher_id: row.fin_voucher_id ?? null,
    })),
    refunds: refunds.map((row) => ({
      id: row.id,
      refund_no: row.refund_no ?? null,
      refund_amount: toNumber(row.refund_amount),
      refund_status: row.refund_status ?? null,
      refund_method_code: row.refund_method_code ?? null,
      reason_code: row.reason_code ?? null,
      currency_code: row.currency_code ?? null,
      original_payment_id: row.original_payment_id ?? null,
      original_credit_app_id: (row as Record<string, unknown>).original_credit_app_id as string | null ?? null,
      refund_source_type: (row as Record<string, unknown>).refund_source_type as string | null ?? null,
      refund_context: (row as Record<string, unknown>).refund_context as string | null ?? null,
      reopens_due_amount: toNumber((row as Record<string, unknown>).reopens_due_amount as number | null),
      metadata: (row.metadata ?? {}) as Record<string, unknown>,
      created_at: toIso(row.created_at),
    })),
    adjustments: adjustments.map((row) => ({
      ...row,
      amount: toNumber(row.amount),
      metadata: (row.metadata ?? {}) as Record<string, unknown>,
      created_at: toIso(row.created_at),
    })),
    voucherReferences,
    auditTimeline,
    taxDocuments: taxDocumentRows.map((row) => ({
      id: row.id,
      document_type: row.document_type,
      trigger_event: row.trigger_event,
      status: row.status,
      fiscal_year: row.fiscal_year,
      sequence_number: row.sequence_number,
      document_no: row.document_no ?? null,
      total_amount: toNumber(row.total_amount),
      tax_amount: toNumber(row.tax_amount),
      currency_code: row.currency_code ?? null,
      supersedes_id: row.supersedes_id ?? null,
      issued_at: row.issued_at ? toIso(row.issued_at) : null,
      issued_by: row.issued_by ?? null,
      cancelled_at: row.cancelled_at ? toIso(row.cancelled_at) : null,
      cancellation_reason: row.cancellation_reason ?? null,
      created_at: toIso(row.created_at),
    })),
  };
}
