/**
 * Orders API - Main endpoints
 * PRD-010: Advanced Order Management
 */

import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { OrderService } from '@/lib/services/order-service';
import { CreateOrderRequestSchema } from '@/lib/validations/workflow-schema';
import { getAuthContext, requirePermission } from '@/lib/middleware/require-permission';
import { checkAPIRateLimitTenant, checkAPIRateLimitUser } from '@/lib/middleware/rate-limit';
import { validateCSRF } from '@/lib/middleware/csrf';
import { logger } from '@/lib/utils/logger';
import { getRequestAuditContext } from '@/lib/utils/request-audit';
import { withTenantContext } from '@/lib/db/tenant-context';
import {
  isWorkflowProfileCreateErrorCode,
  workflowProfileCreateErrorPayload,
  WORKFLOW_PROFILE_CREATE_HTTP_STATUS,
} from '@/lib/services/workflow/workflow-profile-error-catalog';
import { emitNotificationEvent } from '@lib/notifications/event-emitter';
import { buildOrderCreatedNotificationVariables } from '@lib/notifications/order-event-variables';
import { getPickupReleaseSummaries } from '@/lib/services/pickup/pickup-release-state.service';
import { listStageWorklistOrderPage } from '@/lib/services/workflow/stage-worklist-query.service';
import {
  isReadyFloorScreen,
  parseReadyListQueryFromApi,
  readyListQueryToWorklist,
} from '@/lib/constants/ready-list-focus';

/**
 * POST /api/v1/orders
 * Create new order
 * Requires: orders:create permission
 * @param request
 */
export async function POST(request: NextRequest) {
  try {
    // Validate CSRF token
    const csrfResponse = await validateCSRF(request);
    if (csrfResponse) {
      return csrfResponse;
    }

    // Check permission 
    const authCheck = await requirePermission('orders:create')(request);
    if (authCheck instanceof NextResponse) {
      return authCheck; // Permission denied 
    }
    const { tenantId, userId, userName } = authCheck;
    const requestAudit = getRequestAuditContext(request);

    // Apply rate limiting (per tenant)
    const rateLimitResponse = await checkAPIRateLimitTenant(tenantId);
    if (rateLimitResponse) {
      return rateLimitResponse;
    }

    const body = await request.json();

    // Support both old and new request formats for useOldWfCodeOrNew
    const useOldWfCodeOrNew = false; // body.useOldWfCodeOrNew ?? body.use_old_wf_code_or_new;

    const parsed = await CreateOrderRequestSchema.safeParseAsync(body);

    if (!parsed.success) {
      const errorDetails =
        parsed.error.issues?.map(issue => {
          const path = issue.path.join('.');
          const detail: Record<string, unknown> = {
            path,
            message: issue.message,
            code: issue.code,
          };

          // Enrich item-level errors with additional context from the raw request body
          if (issue.path[0] === 'items' && typeof issue.path[1] === 'number') {
            const itemIndex = issue.path[1] as number;
            const items = Array.isArray((body as any).items) ? (body as any).items : [];
            const rawItem = items[itemIndex];

            detail.itemIndex = itemIndex;

            if (rawItem && typeof rawItem === 'object') {
              detail.item = {
                productId: (rawItem as any).productId,
                productName:
                  (rawItem as any).productName ??
                  (rawItem as any).name ??
                  (rawItem as any).label ??
                  null,
                serviceCategoryCode: (rawItem as any).serviceCategoryCode,
                quantity: (rawItem as any).quantity,
                pricePerUnit: (rawItem as any).pricePerUnit,
                totalPrice: (rawItem as any).totalPrice,
              };
            }
          }

          return detail;
        }) || [];

      logger.warn('Create order validation failed', {
        feature: 'orders',
        action: 'create',
        tenantId,
        userId,
        errorDetails,
      });

      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          details: errorDetails
        },
        { status: 400 }
      );
    }

    // Validate: orders cannot mix retail items and service items
    const items = parsed.data.items || [];
    if (items.length > 1) {
      const hasRetail = items.some((i) => i.serviceCategoryCode === 'RETAIL_ITEMS');
      const hasServices = items.some((i) => i.serviceCategoryCode && i.serviceCategoryCode !== 'RETAIL_ITEMS');
      if (hasRetail && hasServices) {
        return NextResponse.json(
          { success: false, error: 'Orders cannot mix retail items and service items. Please add only one type per order.' },
          { status: 400 }
        );
      }
    }

    const result = await withTenantContext(tenantId, async () =>
      OrderService.createOrder({
        tenantId,
        userId,
        userName,
        ...parsed.data,
        orderSourceCode: parsed.data.orderSourceCode ?? 'web_admin',
        useOldWfCodeOrNew,
        stockDeductionAudit: {
          referenceType: 'ORDER',
          userId,
          userName,
          userAgent: requestAudit.userAgent,
          userIp: requestAudit.userIp,
          reason: 'Order sale deduction',
        },
      })
    );

    if (!result.success) {
      if (isWorkflowProfileCreateErrorCode(result.errorCode)) {
        return NextResponse.json(
          workflowProfileCreateErrorPayload(result.errorCode, { serviceCode: result.serviceCode }),
          { status: WORKFLOW_PROFILE_CREATE_HTTP_STATUS },
        );
      }
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    if (result.order) {
      void emitNotificationEvent({
        code: 'order.created',
        tenantOrgId: tenantId,
        recipientUserIds: [userId],
        sourceEntityType: 'order',
        sourceEntityId: result.order.id,
        variables: buildOrderCreatedNotificationVariables({
          orderNo:   result.order.orderNo,
          readyByAt: result.order.readyByAt,
        }),
      });
    }

    return NextResponse.json({ success: true, data: result.order });
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Unknown error';
    const status = message.includes('Unauthorized') ? 401 : 400;
    logger.error('Create order failed', e as Error, {
      feature: 'orders',
      action: 'create',
      status,
      message,
    });
    return NextResponse.json({ error: message }, { status });
  }
}

/**
 * GET /api/v1/orders
 * List tenant orders. `workflow_screen` selects floor-queue membership from each
 * order's artifact or live catalog instead of a client status list.
 * Requires: orders:read permission. Tenant is resolved from the session.
 */
export const maxDuration = 10; // Vercel timeout limit

/**
 * @param request Authenticated list request; tenant comes from the session.
 */
export async function GET(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Check permission
    const authCheck = await requirePermission('orders:read')(request);
    if (authCheck instanceof NextResponse) {
      return authCheck; // Permission denied
    }
    const { tenantId, userId } = authCheck;

    // Apply rate limiting (per tenant)
    const rateLimitResponse = await checkAPIRateLimitTenant(tenantId);
    if (rateLimitResponse) {
      return rateLimitResponse;
    }
    const { searchParams } = new URL(request.url);

    const supabase = await createClient();

    // Get filters
    const currentStatus = searchParams.get('current_status');
    const currentStage = searchParams.get('current_stage');
    const statusFilter = searchParams.get('status_filter');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const includeItemsParam = searchParams.get('include_items');
    const includeItemsFull = includeItemsParam === 'true';
    const includeItemsPreview = includeItemsParam === 'preview';
    const includeItems = includeItemsFull || includeItemsPreview;
    const createdAfter = searchParams.get('created_after');
    const updatedAfter = searchParams.get('updated_after');
    const search = searchParams.get('search')?.trim() || '';
    const sortBy = searchParams.get('sort_by') || 'received_at';
    const sortOrder = searchParams.get('sort_order') === 'asc' ? true : false;
    const receivedFrom = searchParams.get('received_from');
    const receivedTo = searchParams.get('received_to');
    const readyByFrom = searchParams.get('ready_by_from');
    const readyByTo = searchParams.get('ready_by_to');
    const isRetail = searchParams.get('is_retail');
    const orderSourceCode = searchParams.get('order_source_code')?.trim() || '';
    const physicalIntakeStatus = searchParams.get('physical_intake_status')?.trim() || '';
    const workflowScreen = searchParams.get('workflow_screen')?.trim() || '';
    const readyListQuery = isReadyFloorScreen(workflowScreen)
      ? parseReadyListQueryFromApi(searchParams)
      : null;

    // Optimize query - only select essential fields for list view
    // For list view, we don't need all nested data - just customer info
    const is_show_null_org_customers = searchParams.get('is_show_null_org_customers') !== 'false';

    const baseSelect = `
        id,
        order_no,
        current_status,
        current_stage,
        status,
        bag_count,
        received_at,
        order_source_code,
        physical_intake_status,
        physical_intake_at,
        physical_intake_by,
        physical_intake_info,
        received_info,
        preparation_status,
        ready_at,
        ready_by_override,
        delivered_at,
        created_at,
        created_by,
        created_info,
        updated_at,
        updated_by,
        updated_info,
        rec_status,
        rec_order,
        rec_notes,
        total_items,
        subtotal:subtotal_amount,
        tax:total_tax_amount,
        total:total_amount,
        payment_status,
        paid_amount:total_paid_amount,
        outstanding_amount,
        payment_type_code,
        currency_code,
        branch_id,
        priority,
        has_issue,
        is_rejected,
        is_retail,
        customer_notes,
        internal_notes,
        rack_location,
        ready_by_at_new,
        ready_by,
        sys_order_sources_cd(
          order_source_code,
          name,
          name2,
          requires_remote_intake_confirm
        ),
        org_customers_mst(
          id,
          name,
          name2,
          phone,
          email,
          sys_customers_mst(
            id,
            name,
            name2,
            phone,
            email
          )
        )
        ${includeItems
        ? includeItemsPreview
          ? `,
        org_order_items_dtl(
          id,
          product_name,
          product_name2,
          quantity,
          quantity_ready,
          service_category_code,
          item_is_rejected,
          has_stain,
          has_damage
        )`
          : `,
        org_order_items_dtl(
          id,
          product_name,
          product_name2,
          quantity,
          quantity_ready,
          service_category_code,
          item_last_step,
          item_status,
          color,
          brand,
          has_stain,
          has_damage,
          org_product_data_mst(
            id,
            product_name,
            product_name2,
            product_code
          )
        )`
        : ''
      }
      `;

    let query = supabase
      .from('org_orders_mst')
      .select(baseSelect, { count: 'exact' })
      .eq('tenant_org_id', tenantId);

    // If we need to exclude null customers, use inner join
    if (!is_show_null_org_customers) {
      query = supabase
        .from('org_orders_mst')
        .select(
          baseSelect.replace('org_customers_mst(', 'org_customers_mst!inner('),
          { count: 'exact' }
        )
        .eq('tenant_org_id', tenantId);
    }

    // Apply is_retail filter
    if (isRetail === 'true') {
      query = query.eq('is_retail', true);
    } else if (isRetail === 'false') {
      query = query.eq('is_retail', false);
    }

    if (orderSourceCode) {
      const codes = orderSourceCode.split(',').map((s) => s.trim()).filter(Boolean);
      if (codes.length === 1) {
        query = query.eq('order_source_code', codes[0]!);
      } else if (codes.length > 1) {
        query = query.in('order_source_code', codes);
      }
    }

    if (physicalIntakeStatus) {
      const statuses = physicalIntakeStatus.split(',').map((s) => s.trim()).filter(Boolean);
      if (statuses.length === 1) {
        query = query.eq('physical_intake_status', statuses[0]!);
      } else if (statuses.length > 1) {
        query = query.in('physical_intake_status', statuses);
      }
    }

    let stageWorklistTotal: number | null = null;
    let stageWorklistOrderIds: string[] | null = null;
    if (workflowScreen) {
      const focusNarrow = readyListQuery ? readyListQueryToWorklist(readyListQuery) : {};
      const statusNarrow = (
        focusNarrow.statusNarrow?.join(',')
        || statusFilter
        || currentStatus
        || currentStage
      )
        ?.split(',')
        .map((value) => value.trim())
        .filter(Boolean);
      const worklist = await listStageWorklistOrderPage(tenantId, {
        screen: workflowScreen,
        page,
        pageSize: limit,
        search: search || undefined,
        statusNarrow,
        collectionDue: focusNarrow.collectionDue,
        missingRack: focusNarrow.missingRack,
        receivedFrom: receivedFrom || undefined,
        receivedTo: receivedTo || undefined,
        readyByFrom: readyByFrom || undefined,
        readyByTo: readyByTo || undefined,
        sortBy,
        sortAscending: sortOrder,
      });
      stageWorklistTotal = worklist.total;
      stageWorklistOrderIds = worklist.orderIds;
      if (worklist.orderIds.length === 0) {
        return NextResponse.json({
          success: true,
          data: {
            orders: [],
            pagination: {
              page,
              limit,
              total: worklist.total,
              totalPages: Math.ceil(worklist.total / limit),
            },
          },
        });
      }
      query = query.in('id', worklist.orderIds);
    }

    // Apply status filter - support multiple statuses (comma-separated)
    // Priority: status_filter > current_status > current_stage
    // Floor queues with workflow_screen already applied membership; do not
    // also flatten a live catalog status list from the client.
    const statusToFilter = statusFilter || currentStatus || currentStage;
    if (!workflowScreen && statusToFilter) {
      const statuses = statusToFilter.split(',').map(s => s.trim()).filter(Boolean);
      if (statuses.length === 1) {
        // Single status - use .eq() for better performance
        query = query.eq('current_status', statuses[0]);
      } else if (statuses.length > 1) {
        // Multiple statuses - use .in()
        query = query.in('current_status', statuses);
      }
    }

    // Search - order_no, customer name, phone, email
    if (!workflowScreen && search.length > 0) {
      const escaped = search.replace(/[%_\\]/g, '\\$&').replace(/,/g, '');
      const pattern = `%${escaped}%`;
      query = query.or(
        `order_no.ilike.${pattern},` +
        `org_customers_mst.name.ilike.${pattern},` +
        `org_customers_mst.name2.ilike.${pattern},` +
        `org_customers_mst.phone.ilike.${pattern},` +
        `org_customers_mst.email.ilike.${pattern}`
      );
    }

    // Date filters
    if (!workflowScreen) {
      if (receivedFrom) {
        query = query.gte('received_at', receivedFrom);
      }
      if (receivedTo) {
        query = query.lte('received_at', receivedTo);
      }
      if (readyByFrom) {
        query = query.gte('ready_by_at_new', readyByFrom);
      }
      if (readyByTo) {
        query = query.lte('ready_by_at_new', readyByTo);
      }
    }

    // Sorting
    const validSortColumns: Record<string, string> = {
      order_no: 'order_no',
      received_at: 'received_at',
      ready_by: 'ready_by_at_new',
      ready_by_at: 'ready_by_at_new',
      ready_by_at_new: 'ready_by_at_new',
      created_at: 'created_at',
      total: 'total_amount',
    };
    const sortColumn = validSortColumns[sortBy] || 'received_at';
    query = query.order(sortColumn, { ascending: sortOrder });

    if (!workflowScreen) {
      const from = (page - 1) * limit;
      const to = from + limit - 1;
      query = query.range(from, to);
    }

    // Optional time filters (ISO timestamps)
    if (createdAfter) {
      query = query.gte('created_at', createdAfter);
    }
    if (updatedAfter) {
      query = query.gte('updated_at', updatedAfter);
    }

    // Add timeout wrapper to prevent hanging requests
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), 8000);
    });

    // Execute query with timeout protection
    const queryPromise = query.then((result: any) => result);
    const result = await Promise.race([
      queryPromise,
      timeoutPromise
    ]);

    const { data: orders, error, count } = result;

    if (error) {
      logger.error('List orders failed', new Error(error.message), {
        feature: 'orders',
        action: 'list',
        tenantId,
      });
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      );
    }

    const duration = Date.now() - startTime;
    const normalizedOrders =
      includeItemsPreview && orders
        ? orders.map((orderRow: Record<string, unknown>) => {
            const rawItems = orderRow.org_order_items_dtl;
            const items = Array.isArray(rawItems) ? rawItems.slice(0, 3) : rawItems;
            return { ...orderRow, org_order_items_dtl: items };
          })
        : orders;
    const pickupReleaseSummaries = await getPickupReleaseSummaries({
      tenantId,
      orderIds: (normalizedOrders ?? []).map((order: { id: string }) => order.id),
    });
    const unorderedOrders = (normalizedOrders ?? []).map((order: Record<string, unknown>) => ({
      ...order,
      pickup_release: pickupReleaseSummaries.get(String(order.id)),
    }));
    const ordersWithPickupRelease = stageWorklistOrderIds
      ? stageWorklistOrderIds.flatMap((orderId) => {
          const match = unorderedOrders.find((order) => String(order.id) === orderId);
          return match ? [match] : [];
        })
      : unorderedOrders;

    logger.info('List orders success', {
      feature: 'orders',
      action: 'list',
      tenantId,
      durationMs: duration,
      count: ordersWithPickupRelease.length,
    });

    const total = stageWorklistTotal ?? (count || 0);
    return NextResponse.json({
      success: true,
      data: {
        orders: ordersWithPickupRelease,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (e) {
    const duration = Date.now() - startTime;
    const message = e instanceof Error ? e.message : 'Unknown error';

    // Handle timeout specifically
    if (message === 'Request timeout' || message.includes('timeout')) {
      logger.warn('List orders timeout', {
        feature: 'orders',
        action: 'list',
        durationMs: duration,
      });
      return NextResponse.json(
        { success: false, error: 'Request timeout - please try again' },
        { status: 504 }
      );
    }

    const status = message.includes('Unauthorized') ? 401 : 500;
    logger.error('List orders error', e as Error, {
      feature: 'orders',
      action: 'list',
      durationMs: duration,
      status,
      message,
    });
    return NextResponse.json(
      { success: false, error: message },
      { status }
    );
  }
}
