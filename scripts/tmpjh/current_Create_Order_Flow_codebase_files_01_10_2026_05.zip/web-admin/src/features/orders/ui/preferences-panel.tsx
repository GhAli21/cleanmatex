/**
 * Preferences Panel
 * Unified dynamic tabbed panel — tabs driven by preference kinds from DB.
 * PRD-010: Advanced Order Management
 */

'use client';
/* eslint-disable react-hooks/set-state-in-effect, react-hooks/preserve-manual-memoization */

import { useEffect, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { useRTL } from '@/lib/hooks/useRTL';
import { useBilingual } from '@/lib/utils/bilingual';
import { cn } from '@/lib/utils';
import { isSafeMdiIconClass } from '@/lib/utils/mdi-icon';
import { useNewOrderStateWithDispatch } from '../hooks/use-new-order-state';
import { usePreferenceCatalog } from '../hooks/use-preference-catalog';
import { ServicePreferenceSelector } from './preferences/ServicePreferenceSelector';
import { PackingPreferenceSelector } from './preferences/PackingPreferenceSelector';
import { StainConditionToggles } from './stain-condition-toggles';
import { CmxTextarea } from '@ui/primitives';
import { ShoppingCart } from 'lucide-react';
import type { PreSubmissionPiece } from '../model/new-order-types';
import type { PreferenceKind, ServicePreference } from '@/lib/types/service-preferences';
import { PREFERENCE_MAIN_TYPES } from '@/lib/types/service-preferences';
import { orderItemLinePackingCharge, packingPreferencePriceMap } from '@/lib/utils/order-packing-charges';

/**
 * Inactive preference-kind tabs: show catalog color as a small dot only, or as the full tab background.
 * Set to `full_tab` for colored pills on every tab that has `kind_bg_color`.
 */
export const PREFERENCE_KIND_INACTIVE_COLOR_MODE: 'dot' | 'full_tab' = 'full_tab';//'dot';

interface PreferencesPanelProps {
  selectedPieceId: string | null;
  selectedConditions: string[];
  onConditionToggle: (conditionCode: string) => void;
  enforcePrefCompatibility?: boolean;
}

/**
 *
 * @param root0
 * @param root0.selectedPieceId
 * @param root0.selectedConditions
 * @param root0.onConditionToggle
 * @param root0.enforcePrefCompatibility
 */
export function PreferencesPanel({
  selectedPieceId,
  selectedConditions,
  onConditionToggle,
  enforcePrefCompatibility = false,
}: PreferencesPanelProps) {
  const t = useTranslations('newOrder.preferences');
  const tPieces = useTranslations('newOrder.pieces');
  const tPalette = useTranslations('newOrder.notesPalette');
  const isRTL = useRTL();
  const getBilingual = useBilingual();

  const [activeKindCode, setActiveKindCode] = useState<string | null>(null);

  const {
    state,
    updateItemPieces,
    updateItemServicePrefs,
    updateItemNotes,
    updateItemPackingPref,
    adjustItemPackingCharge,
  } = useNewOrderStateWithDispatch();
  const {
    servicePrefs,
    packingPrefs,
    conditionCatalog,
    preferenceKinds,
    kindsLoading,
    prefsByKind,
  } = usePreferenceCatalog(state.branchId);

  const packingPriceByCode = useMemo(() => packingPreferencePriceMap(packingPrefs), [packingPrefs]);

  // Set default tab to first kind once loaded
  useEffect(() => {
    if (!activeKindCode && preferenceKinds.length > 0) {
      setActiveKindCode(preferenceKinds[0].kind_code);
    }
  }, [preferenceKinds, activeKindCode]);

  const activeKind = preferenceKinds.find((k) => k.kind_code === activeKindCode) ?? null;

  const { item, piece, isItemLevel } = useMemo(() => {
    if (!selectedPieceId || state.items.length === 0) {
      return { item: null, piece: null, isItemLevel: false };
    }
    for (const i of state.items) {
      if (!i.pieces || i.pieces.length === 0) {
        if (selectedPieceId === `temp-${i.productId}-1`) {
          return { item: i, piece: null, isItemLevel: true };
        }
      } else {
        const p = i.pieces.find((x) => x.id === selectedPieceId);
        if (p) return { item: i, piece: p, isItemLevel: false };
      }
    }
    return { item: null, piece: null, isItemLevel: false };
  }, [selectedPieceId, state.items]);

  const handlePieceUpdate = (productId: string, pieceId: string, updates: Partial<PreSubmissionPiece>) => {
    const it = state.items.find((c) => c.productId === productId);
    if (!it) return;
    const existingPieces: PreSubmissionPiece[] = it.pieces ?? [];
    const updatedPieces = existingPieces.map((p) =>
      p.id === pieceId ? { ...p, ...updates } : p
    );
    updateItemPieces(productId, updatedPieces);

    if ('servicePrefs' in updates) {
      const pieceCharge = (pieces: PreSubmissionPiece[]) =>
        pieces.reduce(
          (sum, p) =>
            sum + (p.servicePrefs ?? []).reduce((s, pref) => s + (pref.extra_price ?? 0), 0),
          0
        );
      const newCharge = pieceCharge(updatedPieces);
      updateItemServicePrefs(productId, it.servicePrefs ?? [], newCharge);
    }
  };

  const hasItems = state.items.length > 0;
  const hasPieceSelected = !!selectedPieceId && !!(item && (piece || isItemLevel));

  const pieceLabel = item
    ? `${item.productName || 'Item'}${piece ? ` — ${tPieces('pieceNumber', { number: piece.pieceSeq })}` : ''}`
    : '';

  function renderKindContent(kind: PreferenceKind) {
    const kindPrefs = prefsByKind.get(kind.kind_code) ?? [];

    switch (kind.main_type_code) {
      case PREFERENCE_MAIN_TYPES.PREFERENCES: {
        if (kind.kind_code === 'packing_prefs') {
          return (
            <>
              {isItemLevel && item ? (
                <PackingPreferenceSelector
                  value={item.packingPrefCode}
                  availablePrefs={packingPrefs}
                  onChange={(code, packingCfId) =>
                    updateItemPackingPref(
                      item.productId,
                      code ?? '',
                      undefined,
                      undefined,
                      packingCfId,
                      code ? packingPriceByCode.get(code) ?? 0 : 0
                    )
                  }
                />
              ) : piece && item ? (
                <PackingPreferenceSelector
                  value={piece.packingPrefCode}
                  availablePrefs={packingPrefs}
                  onChange={(code, packingCfId) => {
                    handlePieceUpdate(item.productId, piece.id, {
                      packingPrefCode: code || undefined,
                      ...(code ? { packingCfId: packingCfId ?? null } : { packingCfId: undefined }),
                    });
                    const updatedPieces = (item.pieces ?? []).map((p) =>
                      p.id === piece.id
                        ? {
                            ...p,
                            packingPrefCode: code || undefined,
                            ...(code ? { packingCfId: packingCfId ?? null } : { packingCfId: undefined }),
                          }
                        : p
                    );
                    adjustItemPackingCharge(
                      item.productId,
                      orderItemLinePackingCharge({ ...item, pieces: updatedPieces }, packingPriceByCode)
                    );
                  }}
                />
              ) : null}
            </>
          );
        }

        const prefsToShow: ServicePreference[] =
          kindPrefs.length > 0 ? kindPrefs : servicePrefs;

        return (
          <>
            {isItemLevel && item ? (
              <ServicePreferenceSelector
                selectedPrefs={item.servicePrefs ?? []}
                availablePrefs={prefsToShow}
                onChange={(prefs, charge) =>
                  updateItemServicePrefs(item.productId, prefs, charge)
                }
                enforceCompatibility={enforcePrefCompatibility}
              />
            ) : piece && item ? (
              <ServicePreferenceSelector
                selectedPrefs={piece.servicePrefs ?? []}
                availablePrefs={prefsToShow}
                onChange={(prefs) =>
                  handlePieceUpdate(item.productId, piece.id, { servicePrefs: prefs })
                }
                maxPrefs={5}
                enforceCompatibility={enforcePrefCompatibility}
              />
            ) : null}
          </>
        );
      }

      case PREFERENCE_MAIN_TYPES.CONDITIONS: {
        // For stain/damage we keep the existing stainCatalog/damageCatalog split
        // For special + new kinds (pattern, material) we use prefsByKind directly
        if (kind.kind_code === 'condition_stain') {
          return (
            <StainConditionToggles
              selectedConditions={selectedConditions}
              onConditionToggle={onConditionToggle}
              disabled={false}
              defaultFilter="stain"
              hideFilterBar
              stainCatalog={conditionCatalog.stains}
              damageCatalog={[]}
            />
          );
        }
        if (kind.kind_code === 'condition_damag') {
          return (
            <StainConditionToggles
              selectedConditions={selectedConditions}
              onConditionToggle={onConditionToggle}
              disabled={false}
              defaultFilter="damage"
              hideFilterBar
              stainCatalog={[]}
              damageCatalog={conditionCatalog.damages}
            />
          );
        }
        // condition_special, condition_pattern, condition_material — generic chip grid
        return (
          <div className="flex flex-wrap gap-2.5">
            {kindPrefs.map((cond) => {
              const isSelected = selectedConditions.includes(cond.code);
              const label = getBilingual(cond.name, cond.name2 ?? null) || cond.name;
              return (
                <button
                  key={cond.code}
                  type="button"
                  onClick={() => onConditionToggle(cond.code)}
                  className={cn(
                    'inline-flex min-h-10 items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1',
                    isSelected
                      ? 'border-blue-600 bg-blue-600 text-white shadow-sm'
                      : 'border-gray-200 bg-gray-50 text-gray-800 hover:border-gray-400 hover:bg-white'
                  )}
                  aria-pressed={isSelected}
                >
                  {isSafeMdiIconClass(cond.icon) ? (
                    <i
                      className={cn(
                        'mdi shrink-0 text-lg leading-none',
                        cond.icon,
                        isSelected ? 'text-white' : 'text-gray-600'
                      )}
                      aria-hidden="true"
                    />
                  ) : null}
                  <span>{label}</span>
                </button>
              );
            })}
            {kindPrefs.length === 0 && (
              <p className="w-full py-6 text-center text-sm text-gray-500">
                {tPalette('noItemsAvailable') || 'No items available'}
              </p>
            )}
          </div>
        );
      }

      case PREFERENCE_MAIN_TYPES.COLOR: {
        const colors = prefsByKind.get('color') ?? conditionCatalog.colors;
        return (
          <div>
            <div className="flex flex-wrap gap-3">
              {colors.map((color) => {
                const isSelected = selectedConditions.includes(color.code);
                const label = getBilingual(color.name, color.name2 ?? null) || color.name;
                return (
                  <div key={color.code} className="flex max-w-[5.5rem] flex-col items-center gap-1">
                    <button
                      type="button"
                      title={label}
                      onClick={() => onConditionToggle(color.code)}
                      className={`h-11 w-11 rounded-full border-2 transition-all focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 ${
                        isSelected
                          ? 'scale-110 border-blue-600 ring-2 ring-blue-300'
                          : 'border-gray-300 hover:border-gray-500'
                      }`}
                      style={{ backgroundColor: color.color_hex ?? '#e5e7eb' }}
                      aria-label={label}
                      aria-pressed={isSelected}
                    />
                    {!color.color_hex && (
                      <span className="line-clamp-2 text-center text-xs font-medium leading-snug text-gray-600">
                        {label}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
            {colors.length === 0 && (
              <p className="py-4 text-center text-sm text-gray-500">
                {tPalette('colors') || 'No colors available'}
              </p>
            )}
          </div>
        );
      }

      case PREFERENCE_MAIN_TYPES.NOTES: {
        return (
          <>
            {piece && item && (
              <CmxTextarea
                value={piece.notes ?? ''}
                onChange={(e) =>
                  handlePieceUpdate(item.productId, piece.id, { notes: e.target.value })
                }
                placeholder={tPieces('notesPlaceholder') || 'Add notes for this piece...'}
                className="min-h-[80px] text-sm"
                rows={3}
              />
            )}
            {isItemLevel && item && (
              <CmxTextarea
                value={item.notes ?? ''}
                onChange={(e) => updateItemNotes(item.productId, e.target.value)}
                placeholder={tPieces('notesPlaceholder') || 'Add notes...'}
                className="min-h-[80px] text-sm"
                rows={3}
              />
            )}
          </>
        );
      }

      default:
        return null;
    }
  }

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
      {/* Context header — shows piece label when selected, title when not */}
      <div className={`flex items-center justify-between border-b border-gray-100 px-4 py-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h3 className={`text-base font-semibold text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
          {hasPieceSelected ? pieceLabel : (t('preferences') || 'Preferences')}
        </h3>
        {hasPieceSelected && isItemLevel && (
          <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-600">
            {t('itemLevel') || 'Item'}
          </span>
        )}
      </div>

      {/* Dynamic Tab Bar — always visible once kinds loaded */}
      {kindsLoading ? (
        <div className={`flex gap-2 border-b border-gray-100 px-3 py-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-9 w-20 rounded-xl bg-gray-100 animate-pulse" />
          ))}
        </div>
      ) : preferenceKinds.length > 0 ? (
        <div className={`flex gap-2 overflow-x-auto border-b border-gray-100 bg-gray-50/70 px-3 py-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          {preferenceKinds.map((kind) => {
            const label = getBilingual(kind.name, kind.name2 ?? null) || kind.kind_code;
            const isActive = kind.kind_code === activeKindCode;
            const bg = kind.kind_bg_color;
            const hasBg = Boolean(bg);
            const inactiveFullColor =
              PREFERENCE_KIND_INACTIVE_COLOR_MODE === 'full_tab' && !isActive && hasBg;
            const showColorBackground = (isActive && hasBg) || inactiveFullColor;
            const showDot =
              PREFERENCE_KIND_INACTIVE_COLOR_MODE === 'dot' && !isActive && hasBg;
            const showSelectionRing =
              isActive &&
              PREFERENCE_KIND_INACTIVE_COLOR_MODE === 'full_tab' &&
              hasBg;

            const buttonClass = cn(
              'flex shrink-0 items-center gap-2 whitespace-nowrap rounded-xl border px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-1',
              isActive
                ? hasBg
                  ? cn(
                      'border-transparent text-white shadow-sm',
                      showSelectionRing && 'z-[1] ring-2 ring-blue-600 ring-offset-1'
                    )
                  : 'border-transparent bg-blue-600 text-white shadow-sm'
                : inactiveFullColor
                  ? 'border-transparent text-white shadow-sm hover:brightness-110'
                  : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900'
            );

            const mdiToneClass = isActive || inactiveFullColor ? 'text-white' : 'text-gray-600';

            return (
              <button
                key={kind.kind_code}
                type="button"
                onClick={() => setActiveKindCode(kind.kind_code)}
                className={buttonClass}
                style={showColorBackground && bg ? { backgroundColor: bg } : undefined}
              >
                {isSafeMdiIconClass(kind.icon) ? (
                  <i
                    className={cn('mdi shrink-0 text-base leading-none', kind.icon, mdiToneClass)}
                    aria-hidden="true"
                  />
                ) : null}
                {showDot ? (
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: bg ?? undefined }}
                    aria-hidden="true"
                  />
                ) : null}
                {label}
              </button>
            );
          })}
        </div>
      ) : null}

      {/* Tab Content — placeholder when no piece selected, actual content when piece selected */}
      <div className="p-4 md:p-5">
        {!hasPieceSelected ? (
          <div className={`flex flex-col items-center justify-center px-4 py-10 ${isRTL ? 'text-right' : 'text-center'}`}>
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gray-100">
              <ShoppingCart className="h-7 w-7 text-gray-400" aria-hidden="true" />
            </div>
            <p className="mb-1 text-base font-medium text-gray-700">
              {hasItems
                ? (t('selectPieceHint') || 'Select a piece from the cart to apply preferences')
                : (t('addItemFirst') || 'Add an item to get started')}
            </p>
            {hasItems && (
              <p className="max-w-2xl text-sm text-gray-500">
                {t('selectPieceFromCart') || 'Tap an item or piece in the cart to configure conditions and notes.'}
              </p>
            )}
          </div>
        ) : (
          activeKind && renderKindContent(activeKind)
        )}
      </div>
    </div>
  );
}
