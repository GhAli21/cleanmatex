/* eslint-disable jsdoc/require-jsdoc, jsdoc/require-param */
/**
 * OrderService
 * Core business logic for order operations
 * PRD-010: Advanced Order Management with workflow support
 */

import type { SupabaseClient } from '@supabase/supabase-js';
import { createClient } from '@/lib/supabase/server';
import { getOrderById } from '@/lib/db/orders';
import { prisma } from '@/lib/db/prisma';
import { Prisma } from '@prisma/client';
import { WorkflowService } from './workflow-service';
import { OrderPieceService, type OrderPreferencesSourceDefault } from './order-piece-service';
import { createTenantSettingsService } from './tenant-settings.service';
import { logger } from '@/lib/utils/logger';
import type { OrderStatus } from '@/lib/types/workflow';
import { resolveOrderCreateWorkflowState } from '@/lib/services/workflow/order-create-workflow.service';
import { generateOrderNumberWithTx } from '@/lib/utils/order-number-generator';
import { isOrderEditable } from '@/lib/utils/order-editability';
import { checkOrderLock, unlockOrder, lockOrderForEdit } from '@/lib/services/order-lock.service';
import { createEditAudit } from '@/lib/services/order-audit.service';
import {
  computeAmendmentDelta,
  assertGovernedAmendmentAllowed,
  stakeAmendmentIdempotency,
  completeAmendmentIdempotency,
  AmendmentGovernanceError,
  type AmendmentDeltaResult,
} from '@/lib/services/order-amendment.service';
import { canAccess } from '@/lib/services/feature-flags.service';
import { calculateOrderTotals } from '@/lib/services/order-calculation.service';
import {
  recalculateOrderFinancialSnapshot,
  recalculateOrderFinancialSnapshotTx,
} from '@/lib/services/order-financial-write.service';
import type { UpdateOrderInput } from '@/lib/validations/edit-order-schemas';
import { getConditionPrefKind } from '@/lib/utils/condition-codes';
import { DEFAULT_ORDER_SOURCE_CODE } from '@/lib/constants/order-sources';
import { PAYMENT_METHODS } from '@/lib/constants/payment';
import { validateOrderSourceForCreation, type OrderSourceCatalogRow } from '@/lib/services/order-source-policy';
import { buildDiscountLinesFromOrderInput, insertDiscountLines, insertDiscountLinesTx } from '@/lib/db/order-discounts';
import { effectivePieceColorsForPersist } from '@/lib/utils/order-piece-color-persist';
import { fetchOrgPackingExtraPriceByCodesSupabase, fetchOrgPackingExtraPriceByCodesPrismaTx } from '@/lib/utils/org-packing-extra-price';
import { fetchOrgServicePreferenceCfIdsByCodesPrismaTx } from '@/lib/utils/org-service-preference-cf-lookup';
import { readCanonicalOrderFinancialSnapshot } from '@/lib/utils/order-financial-snapshot';
import {
  DEFAULT_PRIORITY,
  ORDER_ISSUE_ERROR,
  ORDER_ISSUE_SCOPE,
  ORDER_ISSUE_STATUS,
  type OrderIssueScope,
} from '@/lib/constants/order-issues';
import { lookupAuditActors } from '@/lib/services/audit-actor.service';
import {
  getIssueTypesByCodes,
  getPrioritiesByCodes,
  isActiveIssueType,
  isActivePriority,
} from '@/lib/services/lookups';
import {
  resolveWorkflowProfileBindingForOrderWithPrisma,
  resolveWorkflowProfileBindingForOrderWithSupabase,
  WorkflowProfileResolutionError,
} from '@/lib/services/workflow/workflow-profile-resolution.service';
import { SemanticInitialStatusResolutionError } from '@/lib/services/workflow/initial-status-resolver.service';
import { OrderCreatePresetError } from '@/lib/services/workflow/order-create-hydrator';
import {
  staffEnForWorkflowProfileError,
} from '@/lib/services/workflow/workflow-profile-error-catalog';

function createOrderFailureFromProfileError(error: unknown): CreateOrderResult | null {
  if (error instanceof SemanticInitialStatusResolutionError) {
    return {
      success: false,
      error: staffEnForWorkflowProfileError(error.code) ?? error.message,
      errorCode: error.code,
    };
  }
  if (error instanceof OrderCreatePresetError) {
    return {
      success: false,
      error: staffEnForWorkflowProfileError(error.code) ?? error.message,
      errorCode: error.code,
    };
  }
  if (error instanceof WorkflowProfileResolutionError) {
    return {
      success: false,
      error: staffEnForWorkflowProfileError(error.code, error.details) ?? error.message,
      errorCode: error.code,
      ...(error.details.serviceCode ? { serviceCode: error.details.serviceCode } : {}),
    };
  }
  return null;
}

/** Packing codes from order item payload (ITEM + piece rows). */
function collectPackingPrefCodesFromOrderPayload(
  orderItems: ReadonlyArray<{
    packingPrefCode?: string;
    pieces?: ReadonlyArray<{ packingPrefCode?: string }>;
  }>
): string[] {
  const c: string[] = [];
  for (const it of orderItems) {
    if (it.packingPrefCode) c.push(it.packingPrefCode);
    for (const p of it.pieces ?? []) {
      if (p.packingPrefCode) c.push(p.packingPrefCode);
    }
  }
  return c;
}

/** Catalog `preference_code` values for all piece-level conditions on the order (stain / damage / special). */
function collectConditionCatalogCodesFromOrderItems(
  orderItems: ReadonlyArray<{
    pieces?: ReadonlyArray<{ conditions?: string[] }>;
  }>
): string[] {
  const set = new Set<string>();
  for (const it of orderItems) {
    for (const p of it.pieces ?? []) {
      for (const uiCode of p.conditions ?? []) {
        set.add(getConditionPrefKind(uiCode).preference_code);
      }
    }
  }
  return [...set];
}

function inferredPackingLineChargeOnCreateItem(
  item: CreateOrderParams['items'][number],
  map: Map<string, number>
): number {
  const pcs = item.pieces ?? [];
  if (pcs.length === 0) {
    return item.packingPrefCode ? map.get(item.packingPrefCode) ?? 0 : 0;
  }
  let sum = 0;
  for (const p of pcs) {
    const code = p.packingPrefCode ?? item.packingPrefCode;
    if (code) sum += map.get(code) ?? 0;
  }
  return sum;
}

function persistedServicePrefChargeColumn(
  item: CreateOrderParams['items'][number],
  packingMap: Map<string, number>
): number {
  const packingLine =
    item.packingPrefCharge !== undefined && item.packingPrefCharge !== null
      ? Number(item.packingPrefCharge)
      : inferredPackingLineChargeOnCreateItem(item, packingMap);
  return (item.servicePrefCharge ?? 0) + packingLine;
}

/** Prisma transaction client for use inside $transaction */
type PrismaTx = Parameters<Parameters<typeof prisma.$transaction>[0]>[0];

export interface CreateOrderPieceData {
  pieceSeq: number;
  color?: string;
  colorCodes?: string[];
  /** Tenant CF ids for `color` rows — `org_service_preference_cf.id` */
  colorCfIds?: (string | null | undefined)[];
  brand?: string;
  hasStain?: boolean;
  hasDamage?: boolean;
  notes?: string;
  rackLocation?: string;
  metadata?: Record<string, any>;
  packingPrefCode?: string;
  packingCfId?: string | null;
  /** Piece-level service prefs (Enterprise-gated) */
  servicePrefs?: Array<{
    preference_code: string;
    source?: string;
    extra_price?: number;
    preferenceCfId?: string | null;
  }>;
  /** Piece-level conditions (stains, damage, special) */
  conditions?: string[];
}

/** Service preference for order item (processing prefs: starch, perfume, etc.) */
export interface CreateOrderServicePref {
  preference_code: string;
  source?: string;
  extra_price?: number;
  preferenceCfId?: string | null;
}

export interface CreateOrderParams {
  tenantId: string;
  customerId: string;
  branchId?: string;
  orderTypeId: string;
  items: Array<{
    productId: string;
    productName?: string | null;
    productName2?: string | null;
    quantity: number;
    pricePerUnit: number;
    totalPrice: number;
    serviceCategoryCode?: string;
    notes?: string;
    hasStain?: boolean;
    hasDamage?: boolean;
    stainNotes?: string;
    damageNotes?: string;
    pieces?: CreateOrderPieceData[]; // Optional piece-level data for new orders
    /** Service preferences (starch, perfume, delicate, etc.) */
    servicePrefs?: CreateOrderServicePref[];
    /** Packing preference (hang, fold, box, etc.) */
    packingPrefCode?: string;
    packingPrefIsOverride?: boolean;
    packingPrefSource?: string;
    packingCfId?: string | null;
    /** Line packing surcharge from catalog (`org_packing_preference_cf.extra_price`); included in persisted `service_pref_charge` plus preference row `extra_price`. */
    packingPrefCharge?: number;
    /** Aggregated charge from service prefs. Included in order total. */
    servicePrefCharge?: number;
  }>;
  /** B18 — order-level preferences (`org_order_preferences_dtl.prefs_level='ORDER'`), independent of any item. */
  orderServicePrefs?: CreateOrderServicePref[];
  isQuickDrop?: boolean;
  quickDropQuantity?: number;
  priority?: string;
  express?: boolean;
  customerNotes?: string;
  internalNotes?: string;
  paymentNotes?: string;
  paymentMethod?: string;
  idempotencyKey?: string;
  readyByAt?: string; // ISO datetime string for ready-by date from screen
  /** B2B: Contract, cost center, PO */
  b2bContractId?: string;
  costCenterCode?: string;
  poNumber?: string;
  /** B2B: Credit limit override audit - set when admin overrides in payment modal */
  creditLimitOverrideBy?: string;
  creditLimitOverrideAt?: Date;
  userId: string;
  userName: string;
  useOldWfCodeOrNew?: boolean;
  totals?: { subtotal: number; discount?: number; tax?: number; total: number; vatRate?: number; vatAmount?: number; taxRate?: number; roundingAdjustment?: number; chargesTotal?: number };
  discountRate?: number;
  discountType?: string;
  promoCodeId?: string;
  giftCardId?: string;
  promoDiscountAmount?: number;
  giftCardDiscountAmount?: number;
  paymentTypeCode?: string;
  currencyCode?: string;
  currencyExRate?: number;
  /** FK to sys_order_sources_cd — sales / integration channel */
  orderSourceCode?: string;
  /** When set, overrides catalog-driven remote intake behavior */
  physicalIntakeStatus?: 'pending_dropoff' | 'received' | 'not_applicable';
  /** Optional escape hatch; normally derived from source + intake */
  initialWorkflowScreen?: string;
  /** Staff or integration notes before physical receipt */
  physicalIntakeInfo?: string | null;
  /** Staff or integration notes when goods are received at branch */
  receivedInfo?: string | null;
  /** Customer snapshot at order time (order-level, not customer master) */
  isDefaultCustomer?: boolean;
  customerMobile?: string;
  customerEmail?: string;
  customerName?: string;
  customerDetails?: Record<string, unknown>;
  /**
   * When set (e.g. public customer booking), used for Supabase writes. Cookie-based clients
   * have no staff JWT, so RLS `current_tenant_id()` fails unless this is the service-role client.
   */
  supabaseClient?: SupabaseClient;
  /** Optional audit context for stock deduction (org_inv_stock_tr) */
  stockDeductionAudit?: {
    referenceType?: string;
    referenceId?: string;
    referenceNo?: string;
    userId?: string;
    userName?: string;
    userInfo?: string;
    userAgent?: string;
    userDevice?: string;
    userBrowser?: string;
    userOs?: string;
    userIp?: string;
    reason?: string;
  };
}

export interface CreateOrderResult {
  success: boolean;
  order?: {
    id: string;
    orderNo: string;
    currentStatus: string;
    readyByAt: string;
  };
  error?: string;
  errorCode?: string;
  serviceCode?: string;
}

export interface EstimateReadyByParams {
  items: Array<{
    serviceCategoryCode: string;
    turnaroundHh?: number;
    quantity: number;
    /** Service preference codes for SLA adjustment (extra_turnaround_minutes) */
    servicePrefs?: Array<{ preference_code: string }>;
  }>;
  isQuickDrop?: boolean;
  express?: boolean;
}

export interface EstimateReadyByResult {
  success: boolean;
  readyByAt?: string;
  error?: string;
}

export interface UpdateOrderParams extends Partial<UpdateOrderInput> {
  orderId: string;
  tenantId: string;
  userId: string;
  userName: string;
  ipAddress?: string;
  userAgent?: string;
  /** B12 — required when this edit is financially governed (see UpdateOrderResult.financialDelta). */
  editReason?: string;
  /** B12 — required when this edit is financially governed; D010-shaped replay/conflict key. */
  idempotencyKey?: string;
}

export interface UpdateOrderResult {
  success: boolean;
  order?: any;
  error?: string;
  /** B12 — set when `error` came from a governed-amendment gate (AmendmentGovernanceError.code). */
  errorCode?:
    | 'EDIT_REASON_REQUIRED'
    | 'PERMISSION_DENIED'
    | 'IDEMPOTENCY_KEY_REQUIRED'
    | 'IDEMPOTENCY_CONFLICT'
    | 'IDEMPOTENCY_IN_PROGRESS';
  /** B12 — signed grand-total delta from a governed edit (item change on an order with prior payments). Absent when not governed. */
  financialDelta?: AmendmentDeltaResult;
  /** B12 — the org_order_edit_history row id to attach a settlement outcome to, when financialDelta.isGoverned is true. */
  editHistoryId?: string;
  /** B12 — true when the caller must still complete a collect-additional/overpayment-resolution step before this edit is considered settled. */
  requiresSettlement?: boolean;
  /** B12 — true when this call replayed a prior successful edit with the same idempotency key (no new writes). */
  idempotentReplay?: boolean;
}

export class OrderService {
  /**
   * Shared workflow + create-hydration resolution for createOrder paths.
   * Initial status and column stamps come from profile Initial rules + presets.
   */
  private static async computeCreateOrderWorkflowState(args: {
    tenantId: string;
    items: CreateOrderParams['items'];
    isQuickDrop?: boolean;
    quickDropQuantity?: number;
    physicalIntakeStatus?: CreateOrderParams['physicalIntakeStatus'];
    initialWorkflowScreen?: string;
    orderTypeId?: string | null;
    sourceRow: OrderSourceCatalogRow;
    semanticInitialRules: Parameters<typeof resolveOrderCreateWorkflowState>[0]['semanticInitialRules'];
    userId?: string | null;
    physicalIntakeInfo?: string | null;
    receivedInfo?: string | null;
  }): Promise<{
    v_initialStatus: string;
    v_transitionFrom: string;
    v_orderStatus: string;
    v_current_status: string;
    v_current_stage: string;
    physicalIntakeStatus: string;
    receivedAt: Date | null;
    contractScreen: string;
    isRetailOnlyOrder: boolean;
    hydrated: Awaited<ReturnType<typeof resolveOrderCreateWorkflowState>>['hydrated'];
  }> {
    const resolved = await resolveOrderCreateWorkflowState({
      items: args.items.map((item) => ({
        serviceCategoryCode: item.serviceCategoryCode ?? 'GENERAL',
      })),
      isQuickDrop: args.isQuickDrop,
      physicalIntakeStatus: args.physicalIntakeStatus,
      initialWorkflowScreen: args.initialWorkflowScreen,
      orderTypeId: args.orderTypeId,
      sourceRow: args.sourceRow,
      semanticInitialRules: args.semanticInitialRules,
      userId: args.userId,
      physicalIntakeInfo: args.physicalIntakeInfo,
      receivedInfo: args.receivedInfo,
    });

    return {
      v_initialStatus: resolved.v_initialStatus,
      v_transitionFrom: resolved.v_transitionFrom,
      v_orderStatus: resolved.v_orderStatus,
      v_current_status: resolved.v_current_status,
      v_current_stage: resolved.v_current_stage,
      physicalIntakeStatus: resolved.physicalIntakeStatus,
      receivedAt: resolved.receivedAt,
      contractScreen: resolved.contractScreen,
      isRetailOnlyOrder: resolved.isRetailOnlyOrder,
      hydrated: resolved.hydrated,
    };
  }

  /**
   * Create new order with workflow logic
   * PRD-010: Quick Drop vs Normal order handling
   */
  static async createOrder(params: CreateOrderParams): Promise<CreateOrderResult> {
    try {
      const {
        tenantId,
        customerId,
        branchId,
        orderTypeId,
        items,
        isQuickDrop,
        quickDropQuantity,
        priority,
        express,
        customerNotes,
        internalNotes,
        paymentMethod,
        readyByAt: providedReadyByAt,
        userId,
        userName,
        totals,
        discountRate,
        discountType,
        promoCodeId,
        giftCardId,
        promoDiscountAmount,
        giftCardDiscountAmount,
        paymentTypeCode,
        currencyCode: passedCurrencyCode,
        currencyExRate: passedCurrencyExRate,
        isDefaultCustomer,
        customerMobile,
        customerEmail,
        customerName,
        customerDetails,
        supabaseClient,
      } = params;

      const supabase = supabaseClient ?? (await createClient());

      const orderSourceCode = (params.orderSourceCode ?? DEFAULT_ORDER_SOURCE_CODE).trim();
      const sourceValidated = await validateOrderSourceForCreation(tenantId, orderSourceCode);
      if (sourceValidated.ok === false) {
        return { success: false, error: sourceValidated.error };
      }

      const workflowProfileBinding = await resolveWorkflowProfileBindingForOrderWithSupabase(supabase, {
        tenantId,
        branchId,
        serviceCodes: items.flatMap((item) => item.serviceCategoryCode ? [item.serviceCategoryCode] : []),
      });

      const wf = await this.computeCreateOrderWorkflowState({
        tenantId,
        items,
        isQuickDrop,
        quickDropQuantity,
        physicalIntakeStatus: params.physicalIntakeStatus,
        initialWorkflowScreen: params.initialWorkflowScreen,
        orderTypeId,
        sourceRow: sourceValidated.row,
        semanticInitialRules: workflowProfileBinding.initialRules,
        userId,
        physicalIntakeInfo: params.physicalIntakeInfo,
        receivedInfo: params.receivedInfo,
      });

      const {
        v_initialStatus,
        v_transitionFrom,
        v_orderStatus,
        v_current_status,
        v_current_stage,
        physicalIntakeStatus,
        receivedAt,
        contractScreen,
        isRetailOnlyOrder,
        hydrated,
      } = wf;

      // T03: retail must always pay at POS — the client blocks PAY_ON_COLLECTION
      // for retail-only orders, but retail lands directly at a terminal status
      // with no downstream collection gate, so a direct/forged API call must be
      // rejected here too rather than relying on the UI guard alone.
      if (isRetailOnlyOrder && paymentMethod === PAYMENT_METHODS.PAY_ON_COLLECTION) {
        return {
          success: false,
          errorCode: 'RETAIL_PAY_ON_COLLECTION_NOT_ALLOWED',
          error: 'Retail orders must be paid at POS. Please select Cash or Card.',
        };
      }

      if (isRetailOnlyOrder) {
        logger.info('Retail order created from workflow initial rules', {
          tenantId,
          userId,
          feature: 'orders',
          action: 'create_order',
        });
      } else {
        logger.info('Using workflow initial rules for order creation', {
          tenantId,
          userId,
          screen: contractScreen,
          contractStatus: v_current_status,
          isQuickDrop,
          physicalIntakeStatus,
          feature: 'orders',
          action: 'create_order',
        });
      }

      // Generate order number
      const { data: orderNoData, error: orderNoError } = await supabase.rpc(
        'generate_order_number',
        { p_tenant_org_id: tenantId }
      );

      if (orderNoError || !orderNoData) {
        return {
          success: false,
          error: 'Failed to generate order number',
        };
      }

      const orderNo = orderNoData as string;

      // Calculate totals (use provided totals when present, else from items)
      const subtotal =
        totals?.subtotal ??
        items.reduce(
          (sum, item) =>
            sum + item.totalPrice + (item.servicePrefCharge ?? 0),
          0
        );
      const discount = totals?.discount ?? 0;
      const tax = totals?.tax ?? 0;
      const total = totals?.total ?? subtotal - discount + tax;
      const roundingAdjustment = totals?.roundingAdjustment ?? 0;
      const vatRate = totals?.vatRate;

      // Currency: prefer passed values, else fetch from tenant settings when we have payment-related data
      const hasPaymentData = !!(
        totals || paymentMethod || paymentTypeCode ||
        discountRate != null || promoCodeId || giftCardId ||
        passedCurrencyCode
      );
      let currencyCode = passedCurrencyCode;
      let currencyExRate = passedCurrencyExRate;
      if (!currencyCode && hasPaymentData) {
        const tenantSettingsSvc = createTenantSettingsService(supabase);
        const config = await tenantSettingsSvc.getCurrencyConfig(tenantId, branchId ?? undefined, userId);
        currencyCode = config.currencyCode;
      }
      if (currencyExRate == null) {
        currencyExRate = 1;
      }

      // Get primary service category from first item
      const primaryServiceCategory = items[0]?.serviceCategoryCode || null;

      const workflowProfile = workflowProfileBinding;
      const v_workflowTemplateId = workflowProfile.basedOnTemplateId;

      const insertPayload: Record<string, unknown> = {
        tenant_org_id: tenantId,
        branch_id: branchId,
        customer_id: customerId,
        order_type_id: orderTypeId,
        order_no: orderNo,
        status: v_orderStatus,
        workflow_template_id: v_workflowTemplateId,
        wf_profile_id: workflowProfile.profileId,
        wf_version_no: workflowProfile.versionNo,
        wf_profile_version_id: workflowProfile.versionId,
        // wf_profile_artifact_id/checksum/schema_version: retired
        // compiled-artifact fields (Gate 5, ADR-SAAS-MNG-0010) — always null
        // for new orders. wf_profile_revision is the one field here that
        // still carries a real, useful value: the live policy_revision at
        // create time, kept for audit traceability only (nothing re-reads it
        // to make a decision).
        wf_profile_artifact_id: null,
        wf_profile_revision: workflowProfile.policyRevision,
        wf_profile_checksum: null,
        wf_profile_schema_version: null,
        current_status: v_current_status,
        current_stage: v_current_stage,
        priority: priority || 'normal',
        priority_multiplier: express ? 0.5 : 1.0,
        total_items:
          items.length > 0
            ? items.reduce((sum, item) => sum + item.quantity, 0)
            : quickDropQuantity || 0,
        subtotal_amount: subtotal,
        items_base_amount: subtotal,
        total_discount_amount: discount,
        total_tax_amount: tax,
        total_amount: total,
        rounding_adjustment_amount: roundingAdjustment,
        payment_status: paymentMethod ? 'partial' : 'pending',
        payment_method_code: paymentMethod,
        total_paid_amount: 0,
        outstanding_amount: total,
        service_category_code: primaryServiceCategory,
        is_order_quick_drop: isQuickDrop || false,
        quick_drop_quantity: quickDropQuantity,
        is_retail: isRetailOnlyOrder,
        customer_notes: customerNotes,
        internal_notes: internalNotes,
        created_by: userId,
        created_info: null,
        rec_status: 1,
        order_source_code: orderSourceCode,
        physical_intake_status: physicalIntakeStatus,
        physical_intake_at: hydrated.physical_intake_at
          ? hydrated.physical_intake_at.toISOString()
          : null,
        physical_intake_by: hydrated.physical_intake_by,
        physical_intake_info: hydrated.physical_intake_info,
        received_info: hydrated.received_info,
        received_at: receivedAt ? receivedAt.toISOString() : null,
        preparation_status: hydrated.preparation_status,
        prepared_at: hydrated.prepared_at
          ? hydrated.prepared_at.toISOString()
          : null,
        prepared_by: hydrated.prepared_by,
      };

      if (currencyCode != null) {
        insertPayload.currency_code = currencyCode;
        insertPayload.currency_ex_rate = currencyExRate ?? 1;
      }
      if (vatRate != null) insertPayload.vat_rate = vatRate;
      if (discountRate != null) insertPayload.discount_rate = discountRate;
      if (discountType != null) insertPayload.discount_type = discountType;
      if (promoCodeId != null) insertPayload.promo_code_id = promoCodeId;
      if (giftCardId != null) insertPayload.gift_card_id = giftCardId;
      if (paymentTypeCode != null) insertPayload.payment_type_code = paymentTypeCode;
      if (params.paymentNotes != null) insertPayload.payment_notes = params.paymentNotes;
      if (isDefaultCustomer != null) insertPayload.is_default_customer = isDefaultCustomer;
      if (customerMobile != null && customerMobile !== '') {
        insertPayload.customer_mobile_number = customerMobile;
      }
      if (customerEmail != null && customerEmail !== '') {
        insertPayload.customer_email = customerEmail;
      }
      if (customerName != null && customerName !== '') {
        insertPayload.customer_name = customerName;
      }
      if (customerDetails != null && Object.keys(customerDetails).length > 0) {
        insertPayload.customer_details = customerDetails;
      }

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('org_orders_mst')
        .insert(insertPayload as any)
        .select()
        .single();

      if (orderError || !order) {
        return {
          success: false,
          error: orderError?.message || 'Failed to create order',
        };
      }

      // Create order items (only if not Quick Drop or if items were provided)
      if (items.length > 0) {
        const packingPriceMapSb = await fetchOrgPackingExtraPriceByCodesSupabase(
          supabase,
          tenantId,
          collectPackingPrefCodesFromOrderPayload(items)
        );

        const itemsToInsert = items.map((item, index) => ({
          order_id: order.id,
          tenant_org_id: tenantId,
          branch_id: branchId ?? null,
          service_category_code: item.serviceCategoryCode,
          order_item_srno: `${orderNo}-${index + 1}`,
          product_id: item.productId,
          quantity: item.quantity,
          price_per_unit: item.pricePerUnit,
          total_price: item.totalPrice,
          status: 'pending',
          item_status: v_initialStatus,
          item_stage: v_transitionFrom,
          notes: item.notes,
          has_stain: item.hasStain,
          has_damage: item.hasDamage,
          stain_notes: item.stainNotes,
          damage_notes: item.damageNotes,
          packing_pref_code: item.packingPrefCode ?? null,
          packing_pref_is_override: item.packingPrefIsOverride ?? false,
          packing_pref_source: item.packingPrefSource ?? null,
          service_pref_charge: persistedServicePrefChargeColumn(item, packingPriceMapSb),
        }));

        const { error: itemsError, data: createdItems } = await supabase
          .from('org_order_items_dtl')
          .insert(itemsToInsert)
          .select();

        if (itemsError) {
          logger.error('Failed to create order items', new Error(itemsError.message), {
            tenantId,
            orderId: order.id,
            feature: 'orders',
            action: 'create_order',
          });
          await supabase
            .from('org_orders_mst')
            .delete()
            .eq('tenant_org_id', tenantId)
            .eq('id', order.id);
          return {
            success: false,
            error: 'Failed to create order items',
          };
        } else if (createdItems && createdItems.length > 0) {
          // Insert service preferences for items that have them
          const servicePrefsToInsert: Array<{
            tenant_org_id: string;
            order_id: string;
            prefs_no: number;
            prefs_level: string;
            order_item_id: string;
            preference_code: string;
            preference_content: string;
            preference_sys_kind: string;
            prefs_source: string;
            extra_price: number;
            branch_id: string | null;
            created_by: string;
            preference_id?: string;
          }> = [];
          for (let i = 0; i < createdItems.length; i++) {
            const createdItem = createdItems[i];
            const itemData = items[i];
            const prefs = itemData?.servicePrefs;
            if (createdItem && prefs && prefs.length > 0) {
              prefs.forEach((pref, idx) => {
                servicePrefsToInsert.push({
                  tenant_org_id: tenantId,
                  order_id: order.id,
                  prefs_no: idx + 1,
                  prefs_level: 'ITEM',
                  order_item_id: createdItem.id,
                  preference_code: pref.preference_code,
                  preference_content: pref.preference_code,
                  preference_sys_kind: 'service_prefs',
                  prefs_source: pref.source ?? 'manual',
                  extra_price: pref.extra_price ?? 0,
                  branch_id: branchId ?? null,
                  created_by: userId,
                  ...(pref.preferenceCfId ? { preference_id: pref.preferenceCfId } : {}),
                });
              });
            }
          }
          if (servicePrefsToInsert.length > 0) {
            const { error: prefsError } = await supabase
              .from('org_order_preferences_dtl')
              .insert(servicePrefsToInsert);
            if (prefsError) {
              logger.error('Failed to insert service preferences for order items', new Error(prefsError.message), {
                tenantId,
                orderId: order.id,
                feature: 'orders',
                action: 'create_order',
              });
              await supabase
                .from('org_orders_mst')
                .delete()
                .eq('tenant_org_id', tenantId)
                .eq('id', order.id);
              return {
                success: false,
                error: 'Failed to create order preferences',
              };
            }
          }

          // Insert packing preferences into org_order_preferences_dtl (ITEM level)
          const packingPrefsToInsert = createdItems
            .map((createdItem, i) => {
              const itemData = items[i];
              if (!createdItem || !itemData?.packingPrefCode) return null;
              return {
                tenant_org_id: tenantId,
                order_id: order.id,
                prefs_no: 1,
                prefs_level: 'ITEM',
                order_item_id: createdItem.id,
                preference_code: itemData.packingPrefCode,
                preference_content: itemData.packingPrefCode,
                preference_sys_kind: 'packing_prefs',
                prefs_owner_type: itemData.packingPrefIsOverride ? 'OVERRIDE' : 'SYSTEM',
                prefs_source: itemData.packingPrefSource ?? 'ORDER_CREATE',
                extra_price: packingPriceMapSb.get(itemData.packingPrefCode) ?? 0,
                branch_id: branchId ?? null,
                created_by: userId,
                ...(itemData.packingCfId ? { preference_id: itemData.packingCfId } : {}),
              };
            })
            .filter((r): r is NonNullable<typeof r> => r !== null);

          if (packingPrefsToInsert.length > 0) {
            const { error: packingPrefsError } = await supabase
              .from('org_order_preferences_dtl')
              .insert(packingPrefsToInsert);
            if (packingPrefsError) {
              logger.error('Failed to insert packing preferences for order items', new Error(packingPrefsError.message), {
                tenantId,
                orderId: order.id,
                feature: 'orders',
                action: 'create_order',
              });
              await supabase
                .from('org_orders_mst')
                .delete()
                .eq('tenant_org_id', tenantId)
                .eq('id', order.id);
              return {
                success: false,
                error: 'Failed to create order packing preferences',
              };
            }
          }

          // Always create pieces for each order item
          const piecesErrors: Array<{ itemId: string; error: string }> = [];

            for (let i = 0; i < createdItems.length; i++) {
              const createdItem = createdItems[i];
              const itemData = items[i];

              if (createdItem && itemData.quantity > 0) {
                // Use piece-level data if provided, otherwise use item-level data as fallback
                const piecesData = itemData.pieces && itemData.pieces.length > 0
                  ? itemData.pieces.map((piece, index) => ({
                    pieceSeq: piece.pieceSeq || index + 1,
                    color: piece.color,
                    colorCodes: piece.colorCodes,
                    colorCfIds: piece.colorCfIds,
                    brand: piece.brand,
                    hasStain: piece.hasStain ?? itemData.hasStain,
                    hasDamage: piece.hasDamage ?? itemData.hasDamage,
                    notes: piece.notes || itemData.notes,
                    rackLocation: piece.rackLocation,
                    metadata: piece.metadata || {},
                    packingPrefCode: piece.packingPrefCode,
                    packingCfId: piece.packingCfId,
                    servicePrefs: piece.servicePrefs,
                    conditions: piece.conditions,
                  }))
                  : undefined; // Will use baseData fallback

                const piecesResult = await OrderPieceService.createPiecesForItem(
                  tenantId,
                  order.id,
                  createdItem.id,
                  itemData.quantity,
                  {
                    serviceCategoryCode: itemData.serviceCategoryCode,
                    productId: itemData.productId,
                    pricePerUnit: itemData.pricePerUnit,
                    totalPrice: itemData.totalPrice,
                    color: undefined, // Fallback if no piece data
                    brand: undefined, // Fallback if no piece data
                    hasStain: itemData.hasStain,
                    hasDamage: itemData.hasDamage,
                    notes: itemData.notes,
                    metadata: {},
                  },
                  piecesData, // Pass piece-level data array
                  branchId ?? undefined,
                  supabase,
                  packingPriceMapSb
                );

                // If pieces creation failed, collect the error
                if (!piecesResult.success) {
                  piecesErrors.push({
                    itemId: createdItem.id,
                    error: piecesResult.error || 'Failed to create pieces',
                  });
                }
              }
            }

          // If any pieces creation failed, rollback order and items
          if (piecesErrors.length > 0) {
              const errorMessage = `Failed to create pieces: ${piecesErrors.map(e => e.error).join('; ')}`;
              logger.error('Failed to create pieces for order items, rolling back order', new Error(errorMessage), {
                tenantId,
                orderId: order.id,
                errors: piecesErrors,
                feature: 'orders',
                action: 'create_order',
              });

              // Delete all created items
              const itemIds = createdItems.map(item => item.id);
              await supabase
                .from('org_order_items_dtl')
                .delete()
                .eq('tenant_org_id', tenantId)
                .eq('order_id', order.id)
                .in('id', itemIds);

              // Delete the order
              await supabase
                .from('org_orders_mst')
                .delete()
                .eq('id', order.id)
                .eq('tenant_org_id', tenantId);

              return {
                success: false,
                error: `Failed to create pieces: ${piecesErrors.map(e => e.error).join('; ')}`,
              };
            }
        }

        // Stock deduction for retail items
        const hasRetailItems = items.some((i) => i.serviceCategoryCode === 'RETAIL_ITEMS');
        if (hasRetailItems) {
          try {
            const { error: deductError } = await supabase.rpc('deduct_retail_stock_for_order', {
              p_order_id: order.id,
              p_tenant_org_id: tenantId,
              p_branch_id: order.branch_id ?? null,
              ...(params.stockDeductionAudit && {
                p_reference_type: params.stockDeductionAudit.referenceType ?? 'ORDER',
                p_reference_id: params.stockDeductionAudit.referenceId ?? order.id,
                p_reference_no: params.stockDeductionAudit.referenceNo,
                p_user_id: params.stockDeductionAudit.userId ?? params.userId,
                p_user_name: params.stockDeductionAudit.userName ?? params.userName,
                p_user_info: params.stockDeductionAudit.userInfo,
                p_user_agent: params.stockDeductionAudit.userAgent,
                p_user_device: params.stockDeductionAudit.userDevice,
                p_user_browser: params.stockDeductionAudit.userBrowser,
                p_user_os: params.stockDeductionAudit.userOs,
                p_user_ip: params.stockDeductionAudit.userIp,
                p_reason: params.stockDeductionAudit.reason,
              }),
            });
            if (deductError) {
              const errMsg = deductError.message || 'Insufficient stock';
              logger.error('Stock deduction failed for retail order', new Error(errMsg), {
                tenantId,
                orderId: order.id,
                feature: 'orders',
                action: 'create_order',
              });
              // Rollback: delete items then order
              await supabase
                .from('org_order_items_dtl')
                .delete()
                .eq('tenant_org_id', tenantId)
                .eq('order_id', order.id);
              await supabase
                .from('org_orders_mst')
                .delete()
                .eq('id', order.id)
                .eq('tenant_org_id', tenantId);
              return {
                success: false,
                error: errMsg.includes('INSUFFICIENT_STOCK') ? errMsg : `Stock deduction failed: ${errMsg}`,
              };
            }
          } catch (deductErr) {
            const errMsg = deductErr instanceof Error ? deductErr.message : 'Stock deduction failed';
            logger.error('Stock deduction failed for retail order', deductErr as Error, {
              tenantId,
              orderId: order.id,
              feature: 'orders',
              action: 'create_order',
            });
            await supabase
              .from('org_order_items_dtl')
              .delete()
              .eq('tenant_org_id', tenantId)
              .eq('order_id', order.id);
            await supabase
              .from('org_orders_mst')
              .delete()
              .eq('id', order.id)
              .eq('tenant_org_id', tenantId);
            return {
              success: false,
              error: errMsg.includes('INSUFFICIENT_STOCK') ? errMsg : `Stock deduction failed: ${errMsg}`,
            };
          }
        }
      }

      // Write discount audit lines (best-effort — does not roll back order on failure)
      try {
        const orderDiscountLines = buildDiscountLinesFromOrderInput({
          discountType:           discountType,
          discountRate:           discountRate,
          discountAmount:         totals?.discount,
          promoCodeId:            promoCodeId,
          promoDiscountAmount:    promoDiscountAmount,
          giftCardId:             giftCardId,
          giftCardDiscountAmount: giftCardDiscountAmount,
        });
        if (orderDiscountLines.length > 0) {
          await insertDiscountLines({
            orderId:      order.id,
            tenantOrgId:  tenantId,
            lines:        orderDiscountLines,
            createdBy:    userId,
          });
        }
      } catch (discountLineErr) {
        logger.warn('Failed to write discount audit lines — order was created', {
          tenantId,
          orderId: order.id,
          feature: 'orders',
          action: 'create_order_discount_lines',
          error: discountLineErr instanceof Error ? discountLineErr.message : String(discountLineErr),
        });
      }

      // Handle ready_by date: use provided value or calculate if null
      let finalReadyByAt: string | undefined;

      if (providedReadyByAt) {
        // Use the ready_by date from the screen field
        finalReadyByAt = providedReadyByAt;
      } else {
        // Calculate ready_by date if not provided
        const readyByAt = await this.estimateReadyBy({
          items: items.map(item => ({
            serviceCategoryCode: item.serviceCategoryCode || '',
            quantity: item.quantity,
          })),
          isQuickDrop,
          express,
        });

        if (readyByAt.success && readyByAt.readyByAt) {
          finalReadyByAt = readyByAt.readyByAt;
        }
      }

      // Update order with ready_by date if we have one
      if (finalReadyByAt) {
        await supabase
          .from('org_orders_mst')
          .update({
            ready_by: finalReadyByAt,
            ready_by_at_new: finalReadyByAt,
          })
          .eq('id', order.id)
          .eq('tenant_org_id', tenantId);
      }

      await recalculateOrderFinancialSnapshot(tenantId, order.id);

      return {
        success: true,
        order: {
          id: order.id,
          orderNo: order.order_no,
          currentStatus: order.current_status,
          readyByAt: finalReadyByAt || '',
        },
      };
    } catch (error) {
      logger.error('OrderService.createOrder error', error as Error, {
        tenantId: params.tenantId,
        userId: params.userId,
        feature: 'orders',
        action: 'create_order',
      });
      const profileFailure = createOrderFailureFromProfileError(error);
      if (profileFailure) return profileFailure;
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Create order within a Prisma transaction (for atomic create-with-payment flow).
   * All operations use tx - if any step fails, the whole transaction rolls back.
   */
  static async createOrderInTransaction(
    tx: PrismaTx,
    params: CreateOrderParams
  ): Promise<CreateOrderResult> {
    const {
      tenantId,
      customerId,
      branchId,
      orderTypeId,
      items,
      orderServicePrefs,
      isQuickDrop,
      quickDropQuantity,
      priority,
      express,
      customerNotes,
      internalNotes,
      paymentMethod,
      idempotencyKey,
      userId,
      readyByAt,
      totals,
      discountRate,
      discountType,
      promoCodeId,
      giftCardId,
      promoDiscountAmount,
      giftCardDiscountAmount,
      paymentTypeCode,
      currencyCode: passedCurrencyCode,
      currencyExRate: passedCurrencyExRate,
      isDefaultCustomer,
      customerMobile,
      customerEmail,
      customerName,
      customerDetails,
    } = params;

    const orderSourceCode = (params.orderSourceCode ?? DEFAULT_ORDER_SOURCE_CODE).trim();
    const sourceValidated = await validateOrderSourceForCreation(tenantId, orderSourceCode);
    if (sourceValidated.ok === false) {
      return { success: false, error: sourceValidated.error };
    }

    let wf: Awaited<ReturnType<typeof OrderService.computeCreateOrderWorkflowState>>;
    let workflowProfileBinding: Awaited<ReturnType<typeof resolveWorkflowProfileBindingForOrderWithPrisma>>;
    try {
      workflowProfileBinding = await resolveWorkflowProfileBindingForOrderWithPrisma(tx, {
        tenantId,
        branchId,
        serviceCodes: items.flatMap((item) => item.serviceCategoryCode ? [item.serviceCategoryCode] : []),
      });

      wf = await OrderService.computeCreateOrderWorkflowState({
        tenantId,
        items,
        isQuickDrop,
        quickDropQuantity,
        physicalIntakeStatus: params.physicalIntakeStatus,
        initialWorkflowScreen: params.initialWorkflowScreen,
        orderTypeId,
        sourceRow: sourceValidated.row,
        semanticInitialRules: workflowProfileBinding.initialRules,
        userId,
        physicalIntakeInfo: params.physicalIntakeInfo,
        receivedInfo: params.receivedInfo,
      });
    } catch (error) {
      const profileFailure = createOrderFailureFromProfileError(error);
      if (profileFailure) return profileFailure;
      throw error;
    }

    const {
      v_initialStatus,
      v_transitionFrom,
      v_orderStatus,
      v_current_status,
      v_current_stage,
      physicalIntakeStatus,
      receivedAt,
      isRetailOnlyOrder,
      hydrated,
    } = wf;

    // T03: same server-side guard as createOrder — retail must always pay at
    // POS; do not rely on the client-side block alone for the transactional
    // create-with-payment path either.
    if (isRetailOnlyOrder && paymentMethod === PAYMENT_METHODS.PAY_ON_COLLECTION) {
      return {
        success: false,
        errorCode: 'RETAIL_PAY_ON_COLLECTION_NOT_ALLOWED',
        error: 'Retail orders must be paid at POS. Please select Cash or Card.',
      };
    }

    const orderNo = await generateOrderNumberWithTx(tx, tenantId);

    /** Piece-level preference rows on order create (distinct from ORDER_EDIT on update). */
    const prefsSourceOnCreate: OrderPreferencesSourceDefault = 'ORDER_CREATE';

    const subtotal =
      totals?.subtotal ??
      items.reduce(
        (sum, item) => sum + item.totalPrice + (item.servicePrefCharge ?? 0),
        0
      );
    const discount = totals?.discount ?? 0;
    const tax = totals?.tax ?? 0;
    const total = totals?.total ?? subtotal - discount + tax;
    const vatRate = totals?.vatRate;
    const taxRate = totals?.taxRate;
    const roundingAdjustment = totals?.roundingAdjustment ?? 0;
    const chargesTotal = totals?.chargesTotal ?? 0;
    const currencyCode = passedCurrencyCode;
    const currencyExRate = passedCurrencyExRate ?? 1;
    const primaryServiceCategory = items[0]?.serviceCategoryCode || null;

    const workflowProfile = workflowProfileBinding;
    const v_workflowTemplateId = workflowProfile.basedOnTemplateId;

    let readyByFields: { ready_by?: Date; ready_by_at_new?: Date } = {};
    if (readyByAt) {
      try {
        const d = new Date(readyByAt);
        if (!Number.isNaN(d.getTime())) {
          readyByFields = { ready_by: d, ready_by_at_new: d };
        }
      } catch {
        // ignore invalid date
      }
    }

    const order = await tx.org_orders_mst.create({
      data: {
        tenant_org_id: tenantId,
        branch_id: branchId,
        customer_id: customerId,
        order_type_id: orderTypeId,
        order_no: orderNo,
        status: v_orderStatus,
        workflow_template_id: v_workflowTemplateId,
        wf_profile_id: workflowProfile.profileId,
        wf_version_no: workflowProfile.versionNo,
        wf_profile_version_id: workflowProfile.versionId,
        // wf_profile_artifact_id/checksum/schema_version: retired
        // compiled-artifact fields (Gate 5, ADR-SAAS-MNG-0010) — always null
        // for new orders. wf_profile_revision is the one field here that
        // still carries a real, useful value: the live policy_revision at
        // create time, kept for audit traceability only (nothing re-reads it
        // to make a decision).
        wf_profile_artifact_id: null,
        wf_profile_revision: workflowProfile.policyRevision,
        wf_profile_checksum: null,
        wf_profile_schema_version: null,
        current_status: v_current_status,
        current_stage: v_current_stage,
        priority: priority || 'normal',
        priority_multiplier: express ? 0.5 : 1.0,
        total_items:
          items.length > 0
            ? items.reduce((sum, item) => sum + item.quantity, 0)
            : quickDropQuantity ?? 0,
        subtotal_amount: subtotal,
        items_base_amount: subtotal,
        total_discount_amount: discount,
        total_tax_amount: tax,
        total_amount: total,
        rounding_adjustment_amount: roundingAdjustment,
        total_charges_amount: chargesTotal,
        payment_status: paymentMethod ? 'partial' : 'pending',
        payment_method_code: paymentMethod,
        idempotency_key: idempotencyKey ?? null,
        total_paid_amount: 0,
        outstanding_amount: total,
        service_category_code: primaryServiceCategory,
        is_order_quick_drop: isQuickDrop ?? false,
        quick_drop_quantity: quickDropQuantity,
        is_retail: isRetailOnlyOrder,
        customer_notes: customerNotes,
        internal_notes: internalNotes,
        payment_notes: params.paymentNotes,
        created_by: userId,
        created_info: null,
        rec_status: 1,
        order_source_code: orderSourceCode,
        physical_intake_status: physicalIntakeStatus,
        physical_intake_at: hydrated.physical_intake_at ?? undefined,
        physical_intake_by: hydrated.physical_intake_by ?? undefined,
        physical_intake_info: hydrated.physical_intake_info ?? undefined,
        received_info: hydrated.received_info ?? undefined,
        received_at: receivedAt,
        preparation_status: hydrated.preparation_status,
        prepared_at: hydrated.prepared_at ?? undefined,
        prepared_by: hydrated.prepared_by ?? undefined,
        ...(currencyCode && { currency_code: currencyCode, currency_ex_rate: currencyExRate }),
        ...(vatRate != null && { vat_rate: vatRate }),
        ...(taxRate != null && { tax_rate: taxRate }),
        ...(discountRate != null && { discount_rate: discountRate }),
        ...readyByFields,
        ...(discountType != null && { discount_type: discountType }),
        ...(promoCodeId != null && { promo_code_id: promoCodeId }),
        ...(giftCardId != null && { gift_card_id: giftCardId }),
        ...(isDefaultCustomer != null && { is_default_customer: isDefaultCustomer }),
        ...(customerMobile != null && customerMobile !== '' && { customer_mobile_number: customerMobile }),
        ...(params.b2bContractId != null && { b2b_contract_id: params.b2bContractId }),
        ...(params.costCenterCode != null && params.costCenterCode !== '' && { cost_center_code: params.costCenterCode }),
        ...(params.poNumber != null && params.poNumber !== '' && { po_number: params.poNumber }),
        ...(params.creditLimitOverrideBy != null && { credit_limit_override_by: params.creditLimitOverrideBy }),
        ...(params.creditLimitOverrideAt != null && { credit_limit_override_at: params.creditLimitOverrideAt }),
        ...(customerEmail != null && customerEmail !== '' && { customer_email: customerEmail }),
        ...(customerName != null && customerName !== '' && { customer_name: customerName }),
        ...(customerDetails != null && Object.keys(customerDetails).length > 0 && { customer_details: customerDetails }),
        ...(paymentTypeCode != null && { payment_type_code: paymentTypeCode }),
      } as any,
    });

    if (items.length > 0) {
      const packingPriceMapPrisma = await fetchOrgPackingExtraPriceByCodesPrismaTx(
        tx,
        tenantId,
        collectPackingPrefCodesFromOrderPayload(items)
      );

      const conditionCfIdByCode = await fetchOrgServicePreferenceCfIdsByCodesPrismaTx(
        tx,
        tenantId,
        collectConditionCatalogCodesFromOrderItems(items)
      );

      for (let index = 0; index < items.length; index++) {
        const item = items[index];
        const createdItem = await tx.org_order_items_dtl.create({
          data: {
            order_id: order.id,
            tenant_org_id: tenantId,
            branch_id: branchId ?? null,
            service_category_code: item.serviceCategoryCode,
            order_item_srno: `${orderNo}-${index + 1}`,
            product_id: item.productId,
            product_name: item.productName ?? null,
            product_name2: item.productName2 ?? null,
            quantity: item.quantity,
            price_per_unit: item.pricePerUnit,
            total_price: item.totalPrice,
            status: 'pending',
            item_status: v_initialStatus,
            item_stage: v_transitionFrom,
            notes: item.notes,
            has_stain: item.hasStain,
            has_damage: item.hasDamage,
            stain_notes: item.stainNotes,
            damage_notes: item.damageNotes,
            packing_pref_code: item.packingPrefCode ?? null,
            packing_pref_is_override: item.packingPrefIsOverride ?? false,
            packing_pref_source: item.packingPrefSource ?? null,
            service_pref_charge: persistedServicePrefChargeColumn(item, packingPriceMapPrisma),
          },
        });

        // Insert service preferences for this item (org_order_preferences_dtl, prefs_level=ITEM)
        const prefs = item.servicePrefs;
        if (prefs && prefs.length > 0) {
          await tx.org_order_preferences_dtl.createMany({
            data: prefs.map((pref, idx) => ({
              tenant_org_id: tenantId,
              order_id: order.id,
              prefs_no: idx + 1,
              prefs_level: 'ITEM',
              order_item_id: createdItem.id,
              preference_code: pref.preference_code,
              preference_content: pref.preference_code,
              preference_sys_kind: 'service_prefs',
              prefs_source: pref.source ?? 'manual',
              extra_price: pref.extra_price ?? 0,
              branch_id: branchId ?? null,
              created_by: userId,
              ...(pref.preferenceCfId ? { preference_id: pref.preferenceCfId } : {}),
            })),
          });
        }

        // Insert item packing pref into org_order_preferences_dtl
        if (item.packingPrefCode) {
          await tx.org_order_preferences_dtl.create({
            data: {
              tenant_org_id: tenantId,
              order_id: order.id,
              prefs_no: 1,
              prefs_level: 'ITEM',
              order_item_id: createdItem.id,
              preference_code: item.packingPrefCode,
              preference_content: item.packingPrefCode,
              preference_sys_kind: 'packing_prefs',
              prefs_owner_type: item.packingPrefIsOverride ? 'OVERRIDE' : 'SYSTEM',
              prefs_source: item.packingPrefSource ?? 'ORDER_CREATE',
              extra_price: packingPriceMapPrisma.get(item.packingPrefCode) ?? 0,
              branch_id: branchId ?? null,
              created_by: userId,
              ...(item.packingCfId ? { preference_id: item.packingCfId } : {}),
            },
          });
        }

        // Always create pieces for each order item
        if (item.quantity > 0) {
          const pricePerPiece = item.totalPrice / item.quantity;

          for (let i = 0; i < item.quantity; i++) {
            const pieceInput = item.pieces?.[i];
            const pieceColors = effectivePieceColorsForPersist(pieceInput);
            const piecePrefs = pieceInput?.servicePrefs ?? [];
            const servicePrefChargePiece = piecePrefs.reduce(
              (s, p) => s + Number(p.extra_price ?? 0),
              0
            );
            const piecePackingCode = pieceInput?.packingPrefCode;
            const packingChargePiece = piecePackingCode
              ? packingPriceMapPrisma.get(piecePackingCode) ?? 0
              : 0;

            const createdPiece = await tx.org_order_item_pieces_dtl.create({
              data: {
                tenant_org_id: tenantId,
                order_id: order.id,
                order_item_id: createdItem.id,
                branch_id: branchId ?? null,
                piece_seq: i + 1,
                service_category_code: item.serviceCategoryCode,
                product_id: item.productId,
                scan_state: 'expected',
                quantity: 1,
                price_per_unit: pricePerPiece,
                total_price: pricePerPiece,
                piece_status: v_initialStatus,
                is_rejected: false,
                is_ready: false,
                color:
                  pieceColors.codes.length > 0
                    ? { codes: pieceColors.codes, primary: pieceColors.codes[0] }
                    : undefined,
                notes: pieceInput?.notes ?? null,
                has_stain: pieceInput?.hasStain ?? false,
                has_damage: pieceInput?.hasDamage ?? false,
                packing_pref_code: pieceInput?.packingPrefCode ?? null,
                service_pref_charge: servicePrefChargePiece + packingChargePiece,
              },
            });

            // Save piece conditions to org_order_preferences_dtl
            const conditions = pieceInput?.conditions ?? [];
            if (conditions.length > 0) {
              await tx.org_order_preferences_dtl.createMany({
                data: conditions.map((code, cidx) => {
                  const { preference_code, preference_sys_kind } = getConditionPrefKind(code);
                  const prefCfId = conditionCfIdByCode.get(preference_code);
                  return {
                    tenant_org_id: tenantId,
                    order_id: order.id,
                    prefs_no: cidx + 1,
                    prefs_level: 'PIECE',
                    order_item_id: createdItem.id,
                    order_item_piece_id: createdPiece.id,
                    preference_code,
                    preference_content: preference_code,
                    preference_sys_kind,
                    prefs_source: prefsSourceOnCreate,
                    extra_price: 0,
                    branch_id: branchId ?? null,
                    created_by: userId,
                    ...(prefCfId ? { preference_id: prefCfId } : {}),
                  };
                }),
              });
            }

            // Save piece-level service prefs to org_order_preferences_dtl
            if (piecePrefs.length > 0) {
              await tx.org_order_preferences_dtl.createMany({
                data: piecePrefs.map((pref, pidx) => ({
                  tenant_org_id: tenantId,
                  order_id: order.id,
                  prefs_no: conditions.length + pidx + 1,
                  prefs_level: 'PIECE',
                  order_item_id: createdItem.id,
                  order_item_piece_id: createdPiece.id,
                  preference_code: pref.preference_code,
                  preference_content: pref.preference_code,
                  preference_sys_kind: 'service_prefs',
                  prefs_source: pref.source ?? 'manual',
                  extra_price: pref.extra_price ?? 0,
                  branch_id: branchId ?? null,
                  created_by: userId,
                  ...(pref.preferenceCfId ? { preference_id: pref.preferenceCfId } : {}),
                })),
              });
            }

            // Save piece packing pref to org_order_preferences_dtl (PIECE level)
            if (pieceInput?.packingPrefCode) {
              await tx.org_order_preferences_dtl.create({
                data: {
                  tenant_org_id: tenantId,
                  order_id: order.id,
                  prefs_no: conditions.length + piecePrefs.length + 1,
                  prefs_level: 'PIECE',
                  order_item_id: createdItem.id,
                  order_item_piece_id: createdPiece.id,
                  preference_code: pieceInput.packingPrefCode,
                  preference_content: pieceInput.packingPrefCode,
                  preference_sys_kind: 'packing_prefs',
                  prefs_owner_type: 'SYSTEM',
                  prefs_source: prefsSourceOnCreate,
                  extra_price: packingChargePiece,
                  branch_id: branchId ?? null,
                  created_by: userId,
                  ...(pieceInput.packingCfId ? { preference_id: pieceInput.packingCfId } : {}),
                },
              });
            }

            const packingOffset = pieceInput?.packingPrefCode ? 1 : 0;

            // Save piece color(s) to org_order_preferences_dtl (PIECE level)
            if (pieceColors.codes.length > 0) {
              await tx.org_order_preferences_dtl.createMany({
                data: pieceColors.codes.map((code, ci) => ({
                  tenant_org_id: tenantId,
                  order_id: order.id,
                  prefs_no: conditions.length + piecePrefs.length + packingOffset + ci + 1,
                  prefs_level: 'PIECE',
                  order_item_id: createdItem.id,
                  order_item_piece_id: createdPiece.id,
                  preference_code: code,
                  preference_content: code,
                  preference_sys_kind: 'color',
                  prefs_source: prefsSourceOnCreate,
                  extra_price: 0,
                  branch_id: branchId ?? null,
                  created_by: userId,
                  ...(pieceColors.cfIds[ci]
                    ? { preference_id: pieceColors.cfIds[ci] as string }
                    : {}),
                })),
              });
            }

            const colorOffset = pieceColors.codes.length;

            // Save piece notes to org_order_preferences_dtl (PIECE level)
            if (pieceInput?.notes) {
              await tx.org_order_preferences_dtl.create({
                data: {
                  tenant_org_id: tenantId,
                  order_id: order.id,
                  prefs_no: conditions.length + piecePrefs.length + packingOffset + colorOffset + 1,
                  prefs_level: 'PIECE',
                  order_item_id: createdItem.id,
                  order_item_piece_id: createdPiece.id,
                  preference_code: pieceInput.notes,
                  preference_content: pieceInput.notes,
                  preference_sys_kind: 'note',
                  prefs_source: prefsSourceOnCreate,
                  extra_price: 0,
                  branch_id: branchId ?? null,
                  created_by: userId,
                },
              });
            }
          }
        }
      }

      // ── B18: order-level preferences + PREFERENCE charge facts ──────────────
      // Order-level preferences have no item/piece to fold into — write them
      // directly at prefs_level=ORDER. Then, for EVERY preference row on this
      // order with extra_price > 0 (item, piece, AND order level — including
      // the pre-existing item/piece writes above, untouched), write a mirror
      // org_order_charges_dtl fact row (charge_type=PREFERENCE, charge_source_id
      // = the preference row's id). This closes the live reconciliation gap:
      // ORDER_PIECES_MATCH_CHARGES / ORDER_PREFERENCES_MATCH_CHARGES /
      // ORDER_CHARGES_MATCH_SNAPSHOT previously always failed for any order
      // with a non-zero preference extra_price, since org_order_charges_dtl
      // never received any rows at all (confirmed via live DB: 0 rows across
      // all orders despite 171 items/pieces/preferences with extra_price > 0).
      if (orderServicePrefs && orderServicePrefs.length > 0) {
        await tx.org_order_preferences_dtl.createMany({
          data: orderServicePrefs.map((pref, idx) => ({
            tenant_org_id: tenantId,
            order_id: order.id,
            prefs_no: idx + 1,
            prefs_level: 'ORDER',
            preference_code: pref.preference_code,
            preference_content: pref.preference_code,
            preference_sys_kind: 'service_prefs',
            prefs_source: pref.source ?? 'ORDER_CREATE',
            extra_price: pref.extra_price ?? 0,
            branch_id: branchId ?? null,
            created_by: userId,
            ...(pref.preferenceCfId ? { preference_id: pref.preferenceCfId } : {}),
          })),
        });
      }

      const chargeablePreferences = await tx.org_order_preferences_dtl.findMany({
        where: {
          tenant_org_id: tenantId,
          order_id: order.id,
          extra_price: { gt: 0 },
        },
        select: { id: true, extra_price: true, preference_code: true },
      });
      if (chargeablePreferences.length > 0) {
        await tx.org_order_charges_dtl.createMany({
          data: chargeablePreferences.map((pref, idx) => ({
            tenant_org_id: tenantId,
            order_id: order.id,
            charge_type: 'PREFERENCE',
            charge_source_id: pref.id,
            label: pref.preference_code,
            amount: pref.extra_price,
            currency_code: order.currency_code,
            applied_seq: idx + 1,
            created_by: userId,
          })),
        });
      }

      if (isRetailOnlyOrder) {
        const audit = params.stockDeductionAudit ?? {};
        await tx.$executeRaw(
          Prisma.sql`SELECT deduct_retail_stock_for_order(
            ${order.id}::uuid,
            ${tenantId}::uuid,
            ${order.branch_id}::uuid,
            ${audit.referenceType ?? 'ORDER'},
            ${audit.referenceId ?? order.id}::uuid,
            ${audit.referenceNo ?? order.order_no},
            ${params.userId ?? null}::uuid,
            ${params.userName ?? null},
            ${audit.userInfo ?? null},
            ${audit.userAgent ?? null},
            ${audit.userDevice ?? null},
            ${audit.userBrowser ?? null},
            ${audit.userOs ?? null},
            ${audit.userIp ?? null},
            ${audit.reason ?? 'Order sale deduction'}
          )`
        );
      }
    }

    return {
      success: true,
      order: {
        id: order.id,
        orderNo: order.order_no,
        currentStatus: order.current_status ?? v_orderStatus,
        readyByAt: '',
      },
    };
  }

  /**
   * Estimate ready-by date based on items and priority
   * PRD-010: Calculate SLA based on service categories and express mode
   */
  static async estimateReadyBy(params: EstimateReadyByParams): Promise<EstimateReadyByResult> {
    try {
      const supabase = await createClient();
      const { items, isQuickDrop, express } = params;

      // If Quick Drop with no items, use default turnaround
      if (isQuickDrop && items.length === 0) {
        const defaultHours = 24; // Default 24 hours for Quick Drop
        const readyByAt = new Date(Date.now() + defaultHours * 60 * 60 * 1000);
        return {
          success: true,
          readyByAt: readyByAt.toISOString(),
        };
      }

      // Get max turnaround from service categories
      let maxTurnaround = 0;
      for (const item of items) {
        const { data: category } = await supabase
          .from('sys_service_category_cd')
          .select('turnaround_hh, turnaround_hh_express')
          .eq('service_category_code', item.serviceCategoryCode)
          .single();

        if (category) {
          const turnaround = express ? category.turnaround_hh_express : category.turnaround_hh;
          maxTurnaround = Math.max(maxTurnaround, turnaround || 0);
        }
      }

      // Fallback to default if no category found
      if (maxTurnaround === 0) {
        maxTurnaround = express ? 12 : 24;
      }

      // Add extra minutes from service preferences (SLA adjustment, migration 0139)
      let extraMinutes = 0;
      const prefCodes = [...new Set(items.flatMap((i) => i.servicePrefs?.map((p) => p.preference_code) ?? []))];
      if (prefCodes.length > 0) {
        const { data: prefs } = await supabase
          .from('sys_service_preference_cd')
          .select('code, extra_turnaround_minutes')
          .in('code', prefCodes);
        extraMinutes = (prefs ?? []).reduce((sum, p) => {
          const itemCount = items.filter((i) => i.servicePrefs?.some((sp) => sp.preference_code === p.code)).length;
          return sum + (p.extra_turnaround_minutes ?? 0) * Math.max(1, itemCount);
        }, 0);
      }

      // Apply priority multiplier if express
      const multiplier = express ? 0.5 : 1.0;
      const finalTurnaround = maxTurnaround * multiplier;

      // Calculate ready-by date (base hours + extra minutes from prefs)
      const readyByAt = new Date(Date.now() + finalTurnaround * 60 * 60 * 1000 + extraMinutes * 60 * 1000);

      return {
        success: true,
        readyByAt: readyByAt.toISOString(),
      };
    } catch (error) {
      console.error('OrderService.estimateReadyBy error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Split order into suborder
   * PRD-010: Create suborder with specific items
   */
  static async splitOrder(
    orderId: string,
    tenantId: string,
    itemIds: string[],
    reason: string,
    userId: string,
    userName: string
  ): Promise<any> {
    try {
      const supabase = await createClient();

      // Get parent order
      const { data: parentOrder, error: orderError } = await supabase
        .from('org_orders_mst')
        .select('*')
        .eq('id', orderId)
        .eq('tenant_org_id', tenantId)
        .single();

      if (orderError || !parentOrder) {
        return {
          success: false,
          error: 'Parent order not found',
        };
      }

      // Get items to move
      const { data: items, error: itemsError } = await supabase
        .from('org_order_items_dtl')
        .select('*')
        .in('id', itemIds)
        .eq('order_id', orderId)
        .eq('tenant_org_id', tenantId);

      if (itemsError || !items || items.length === 0) {
        return {
          success: false,
          error: 'Items not found or already moved',
        };
      }

      // Generate suborder number
      const { data: orderNoData, error: orderNoError } = await supabase.rpc(
        'generate_order_number',
        { p_tenant_org_id: tenantId }
      );

      if (orderNoError || !orderNoData) {
        return {
          success: false,
          error: 'Failed to generate suborder number',
        };
      }

      // Create suborder
      const { data: suborder, error: suborderError } = await supabase
        .from('org_orders_mst')
        .insert({
          tenant_org_id: tenantId,
          branch_id: parentOrder.branch_id,
          customer_id: parentOrder.customer_id,
          order_type_id: parentOrder.order_type_id,
          order_no: orderNoData,
          status: 'intake',
          current_status: parentOrder.current_status,
          current_stage: parentOrder.current_stage,
          priority: parentOrder.priority,
          priority_multiplier: parentOrder.priority_multiplier,
          total_items: items.length,
          subtotal: items.reduce((sum, item) => sum + item.total_price, 0),
          discount: 0,
          tax: 0,
          total: items.reduce((sum, item) => sum + item.total_price, 0),
          workflow_template_id: parentOrder.workflow_template_id,
          parent_order_id: orderId,
          order_subtype: 'split_child',
          customer_notes: `Split from ${parentOrder.order_no}: ${reason}`,
          internal_notes: `Split order created - reason: ${reason}`,
        })
        .select()
        .single();

      if (suborderError || !suborder) {
        return {
          success: false,
          error: 'Failed to create suborder',
        };
      }

      // Move items to suborder
      const { error: moveError } = await supabase
        .from('org_order_items_dtl')
        .update({ order_id: suborder.id })
        .in('id', itemIds);

      if (moveError) {
        return {
          success: false,
          error: 'Failed to move items to suborder',
        };
      }

      // Update parent order
      await supabase
        .from('org_orders_mst')
        .update({
          has_split: true,
          total_items: parentOrder.total_items - items.length,
        })
        .eq('id', orderId);

      // Log to history
      await supabase.rpc('log_order_action', {
        p_tenant_org_id: tenantId,
        p_order_id: orderId,
        p_action_type: 'SPLIT',
        p_from_value: null,
        p_to_value: suborder.id,
        p_done_by: userId,
        p_payload: {
          reason,
          suborder_no: suborder.order_no,
          items_moved: items.length,
        },
      });

      return {
        success: true,
        suborder: {
          id: suborder.id,
          orderNo: suborder.order_no,
        },
      };
    } catch (error) {
      console.error('OrderService.splitOrder error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Recompute org_orders_mst.has_issue from open rows in org_order_issues.
   * Report ≠ Reject — never touches is_rejected flags.
   */
  static async recomputeOrderHasIssue(
    orderId: string,
    tenantId: string,
    supabase?: SupabaseClient
  ): Promise<void> {
    const client = supabase ?? (await createClient());
    const { data: openRows } = await client
      .from('org_order_issues')
      .select('id')
      .eq('tenant_org_id', tenantId)
      .eq('order_id', orderId)
      .eq('status', ORDER_ISSUE_STATUS.OPEN)
      .limit(1);

    await client
      .from('org_orders_mst')
      .update({ has_issue: Boolean(openRows && openRows.length > 0) })
      .eq('id', orderId)
      .eq('tenant_org_id', tenantId);
  }

  /**
   * Derive scope when client omits scopeLevel (legacy body support).
   */
  static deriveIssueScope(
    scopeLevel: OrderIssueScope | undefined,
    orderItemId: string | null | undefined,
    orderItemPieceId: string | null | undefined
  ): OrderIssueScope {
    if (scopeLevel) return scopeLevel;
    if (orderItemPieceId) return ORDER_ISSUE_SCOPE.PIECE;
    if (orderItemId) return ORDER_ISSUE_SCOPE.ITEM;
    return ORDER_ISSUE_SCOPE.ORDER;
  }

  /**
   * Create issue at ORDER / ITEM / PIECE scope.
   * Does not set reject flags (Report ≠ Reject).
   */
  static async createIssue(params: {
    orderId: string;
    tenantId: string;
    userId: string;
    issueCode: string;
    issueText: string;
    scopeLevel?: OrderIssueScope;
    orderItemId?: string | null;
    orderItemPieceId?: string | null;
    photoUrl?: string;
    priority?: string;
    /** QA reject path only — Report Issue must leave this false/undefined */
    alsoReject?: boolean;
  }): Promise<{
    success: boolean;
    issue?: Record<string, unknown>;
    error?: string;
    errorCode?: string;
  }> {
    const {
      orderId,
      tenantId,
      userId,
      issueCode,
      issueText,
      photoUrl,
      priority = DEFAULT_PRIORITY,
    } = params;
    const orderItemId = params.orderItemId ?? null;
    const orderItemPieceId = params.orderItemPieceId ?? null;
    const scopeLevel = OrderService.deriveIssueScope(
      params.scopeLevel,
      orderItemId,
      orderItemPieceId
    );

    try {
      const supabase = await createClient();

      const normalizedCode = issueCode.trim();
      const typeOk = await isActiveIssueType(normalizedCode, supabase);
      if (!typeOk) {
        return {
          success: false,
          error: 'Invalid or inactive issue type',
          errorCode: ORDER_ISSUE_ERROR.INVALID_TYPE,
        };
      }

      const priorityOk = await isActivePriority(priority, supabase);
      if (!priorityOk) {
        return {
          success: false,
          error: 'Invalid or inactive priority',
          errorCode: ORDER_ISSUE_ERROR.INVALID_PRIORITY,
        };
      }

      if (scopeLevel === ORDER_ISSUE_SCOPE.ORDER) {
        if (orderItemId || orderItemPieceId) {
          return {
            success: false,
            error: 'ORDER scope must not include item or piece',
            errorCode: ORDER_ISSUE_ERROR.SCOPE_INVALID,
          };
        }
      }

      if (scopeLevel === ORDER_ISSUE_SCOPE.ITEM) {
        if (!orderItemId || orderItemPieceId) {
          return {
            success: false,
            error: 'ITEM scope requires orderItemId only',
            errorCode: ORDER_ISSUE_ERROR.SCOPE_INVALID,
          };
        }
        const { data: item } = await supabase
          .from('org_order_items_dtl')
          .select('id')
          .eq('id', orderItemId)
          .eq('order_id', orderId)
          .eq('tenant_org_id', tenantId)
          .maybeSingle();
        if (!item) {
          return {
            success: false,
            error: 'Order item not found on this order',
            errorCode: ORDER_ISSUE_ERROR.HIERARCHY_MISMATCH,
          };
        }
      }

      if (scopeLevel === ORDER_ISSUE_SCOPE.PIECE) {
        if (!orderItemId || !orderItemPieceId) {
          return {
            success: false,
            error: 'PIECE scope requires orderItemId and orderItemPieceId',
            errorCode: ORDER_ISSUE_ERROR.SCOPE_INVALID,
          };
        }
        const { data: piece } = await supabase
          .from('org_order_item_pieces_dtl')
          .select('id, order_item_id')
          .eq('id', orderItemPieceId)
          .eq('order_id', orderId)
          .eq('tenant_org_id', tenantId)
          .maybeSingle();
        if (!piece || piece.order_item_id !== orderItemId) {
          return {
            success: false,
            error: 'Piece does not belong to the given item/order',
            errorCode: ORDER_ISSUE_ERROR.HIERARCHY_MISMATCH,
          };
        }
      }

      const { data: issue, error: issueError } = await supabase
        .from('org_order_issues')
        .insert({
          tenant_org_id: tenantId,
          order_id: orderId,
          scope_level: scopeLevel,
          order_item_id: orderItemId,
          order_item_piece_id: orderItemPieceId,
          issue_code: normalizedCode,
          issue_text: issueText,
          photo_url: photoUrl,
          priority,
          status: ORDER_ISSUE_STATUS.OPEN,
          created_by: userId,
        })
        .select()
        .single();

      if (issueError || !issue) {
        console.error('OrderService.createIssue insert error:', issueError);
        return {
          success: false,
          error: 'Failed to create issue',
          errorCode: ORDER_ISSUE_ERROR.CREATE_FAILED,
        };
      }

      // Latest-open pointers only — never set reject flags
      if (scopeLevel === ORDER_ISSUE_SCOPE.ORDER) {
        await supabase
          .from('org_orders_mst')
          .update({ issue_id: issue.id })
          .eq('id', orderId)
          .eq('tenant_org_id', tenantId);
      }
      if (orderItemId) {
        await supabase
          .from('org_order_items_dtl')
          .update({ item_issue_id: issue.id })
          .eq('id', orderItemId)
          .eq('tenant_org_id', tenantId);
      }
      if (orderItemPieceId) {
        await supabase
          .from('org_order_item_pieces_dtl')
          .update({ issue_id: issue.id })
          .eq('id', orderItemPieceId)
          .eq('tenant_org_id', tenantId);
      }

      await OrderService.recomputeOrderHasIssue(orderId, tenantId, supabase);

      // Explicit reject (QA) — never implied by report alone
      if (params.alsoReject) {
        if (orderItemId) {
          await supabase
            .from('org_order_items_dtl')
            .update({ item_is_rejected: true })
            .eq('id', orderItemId)
            .eq('tenant_org_id', tenantId);
        }
        if (orderItemPieceId) {
          await supabase
            .from('org_order_item_pieces_dtl')
            .update({ is_rejected: true })
            .eq('id', orderItemPieceId)
            .eq('tenant_org_id', tenantId);
        }
        await supabase
          .from('org_orders_mst')
          .update({ is_rejected: true })
          .eq('id', orderId)
          .eq('tenant_org_id', tenantId);
      }

      await supabase.rpc('log_order_action', {
        p_tenant_org_id: tenantId,
        p_order_id: orderId,
        p_action_type: 'ISSUE_CREATED',
        p_from_value: null,
        p_to_value: normalizedCode,
        p_done_by: userId,
        p_payload: {
          issue_id: issue.id,
          issue_text: issueText,
          priority,
          scope_level: scopeLevel,
          order_item_id: orderItemId,
          order_item_piece_id: orderItemPieceId,
          also_reject: Boolean(params.alsoReject),
        },
      });

      return { success: true, issue };
    } catch (error) {
      console.error('OrderService.createIssue error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        errorCode: ORDER_ISSUE_ERROR.CREATE_FAILED,
      };
    }
  }

  /**
   * List issues for an order with optional scope filters and counts.
   */
  static async listIssues(params: {
    orderId: string;
    tenantId: string;
    orderItemId?: string | null;
    orderItemPieceId?: string | null;
    status?: 'open' | 'solved' | 'all';
    includeChildren?: boolean;
    /** this = opener narrowing; order|item|piece|all = order-wide by scope_level */
    scopeFilter?: 'this' | 'order' | 'item' | 'piece' | 'all';
  }): Promise<{
    success: boolean;
    issues: Record<string, unknown>[];
    openCount: number;
    totalCount: number;
    error?: string;
  }> {
    try {
      const supabase = await createClient();
      const status = params.status ?? 'all';
      const scopeFilter = params.scopeFilter ?? 'this';
      const includeChildren = params.includeChildren !== false;
      const pieceId = params.orderItemPieceId ?? null;
      const itemId = params.orderItemId ?? null;

      let query = supabase
        .from('org_order_issues')
        .select('*')
        .eq('tenant_org_id', params.tenantId)
        .eq('order_id', params.orderId)
        .order('created_at', { ascending: false });

      if (scopeFilter === 'order') {
        query = query.eq('scope_level', ORDER_ISSUE_SCOPE.ORDER);
      } else if (scopeFilter === 'item') {
        query = query.eq('scope_level', ORDER_ISSUE_SCOPE.ITEM);
      } else if (scopeFilter === 'piece') {
        query = query.eq('scope_level', ORDER_ISSUE_SCOPE.PIECE);
      } else if (scopeFilter === 'all') {
        // no scope narrowing
      } else if (pieceId) {
        query = query.eq('order_item_piece_id', pieceId);
      } else if (itemId) {
        if (includeChildren) {
          query = query.eq('order_item_id', itemId);
        } else {
          query = query
            .eq('order_item_id', itemId)
            .eq('scope_level', ORDER_ISSUE_SCOPE.ITEM);
        }
      } else if (!includeChildren) {
        query = query.eq('scope_level', ORDER_ISSUE_SCOPE.ORDER);
      }

      if (status === 'open') {
        query = query.eq('status', ORDER_ISSUE_STATUS.OPEN);
      } else if (status === 'solved') {
        query = query.eq('status', ORDER_ISSUE_STATUS.SOLVED);
      }

      const { data, error } = await query;
      if (error) {
        console.error('OrderService.listIssues error:', error);
        return {
          success: false,
          issues: [],
          openCount: 0,
          totalCount: 0,
          error: error.message,
        };
      }

      const issues = (data ?? []) as Record<string, unknown>[];
      const enriched = await OrderService.enrichIssueRows(
        params.tenantId,
        issues
      );

      const openCount = enriched.filter(
        (i) => i.status === ORDER_ISSUE_STATUS.OPEN
      ).length;
      return {
        success: true,
        issues: enriched,
        openCount,
        totalCount: enriched.length,
      };
    } catch (error) {
      console.error('OrderService.listIssues error:', error);
      return {
        success: false,
        issues: [],
        openCount: 0,
        totalCount: 0,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Enrich issue rows with actor names + type/priority catalog labels.
   */
  static async enrichIssueRows(
    tenantId: string,
    issues: Record<string, unknown>[]
  ): Promise<Record<string, unknown>[]> {
    if (issues.length === 0) return issues;
    const supabase = await createClient();

    const actorIds = issues.flatMap((row) =>
      [row.created_by, row.solved_by].filter(
        (id): id is string => typeof id === 'string' && id.length > 0
      )
    );
    let nameById: Record<string, string> = {};
    try {
      const actors = await lookupAuditActors(tenantId, actorIds);
      nameById = Object.fromEntries(
        actors.map((a) => [
          a.id,
          a.displayName || a.email || a.phone || a.id.slice(0, 8),
        ])
      );
    } catch (actorError) {
      console.error('OrderService.enrichIssueRows actor lookup:', actorError);
    }

    const typeCodes = [
      ...new Set(
        issues
          .map((r) => r.issue_code)
          .filter((c): c is string => typeof c === 'string' && c.length > 0)
      ),
    ];
    const priorityCodes = [
      ...new Set(
        issues
          .map((r) => r.priority)
          .filter((c): c is string => typeof c === 'string' && c.length > 0)
      ),
    ];

    const typeByCode: Record<
      string,
      { name: string | null; name2: string | null; color: string | null }
    > = {};
    if (typeCodes.length > 0) {
      const typesResult = await getIssueTypesByCodes(typeCodes, supabase);
      Object.assign(typeByCode, typesResult.data ?? {});
    }

    const priorityByCode: Record<
      string,
      {
        name: string | null;
        name2: string | null;
        color: string | null;
        display_order: number | null;
      }
    > = {};
    if (priorityCodes.length > 0) {
      const prioritiesResult = await getPrioritiesByCodes(
        priorityCodes,
        supabase
      );
      Object.assign(priorityByCode, prioritiesResult.data ?? {});
    }

    return issues
      .map((row): Record<string, unknown> => {
        const code =
          typeof row.issue_code === 'string' ? row.issue_code : null;
        const pri = typeof row.priority === 'string' ? row.priority : null;
        const typeMeta = code ? typeByCode[code] : undefined;
        const priMeta = pri ? priorityByCode[pri] : undefined;
        return {
          ...row,
          created_by_name:
            typeof row.created_by === 'string'
              ? nameById[row.created_by] ?? null
              : null,
          solved_by_name:
            typeof row.solved_by === 'string'
              ? nameById[row.solved_by] ?? null
              : null,
          issue_type_name: typeMeta?.name ?? null,
          issue_type_name2: typeMeta?.name2 ?? null,
          issue_type_color: typeMeta?.color ?? null,
          priority_name: priMeta?.name ?? null,
          priority_name2: priMeta?.name2 ?? null,
          priority_color: priMeta?.color ?? null,
          priority_display_order: priMeta?.display_order ?? 99,
        };
      })
      .sort((a, b) => {
        const ao = Number(a.priority_display_order ?? 99);
        const bo = Number(b.priority_display_order ?? 99);
        if (ao !== bo) return ao - bo;
        const at = String(a.created_at ?? '');
        const bt = String(b.created_at ?? '');
        return bt.localeCompare(at);
      });
  }

  /**
   * Open/total counts for order + per item + per piece (badge wiring).
   */
  static async getIssueSummary(
    orderId: string,
    tenantId: string
  ): Promise<{
    success: boolean;
    order: { open: number; total: number };
    byItem: Record<string, { open: number; total: number }>;
    byPiece: Record<string, { open: number; total: number }>;
    error?: string;
  }> {
    const empty = {
      success: false as const,
      order: { open: 0, total: 0 },
      byItem: {} as Record<string, { open: number; total: number }>,
      byPiece: {} as Record<string, { open: number; total: number }>,
    };
    try {
      const supabase = await createClient();
      const { data, error } = await supabase
        .from('org_order_issues')
        .select('id, order_item_id, order_item_piece_id, status, solved_at, scope_level')
        .eq('tenant_org_id', tenantId)
        .eq('order_id', orderId);

      if (error) {
        return { ...empty, error: error.message };
      }

      const rows = data ?? [];
      const byItem: Record<string, { open: number; total: number }> = {};
      const byPiece: Record<string, { open: number; total: number }> = {};
      let orderScopedOpen = 0;
      let orderScopedTotal = 0;

      for (const row of rows) {
        const isOpen = row.status === ORDER_ISSUE_STATUS.OPEN;

        // Piece-scoped issues count only under the piece (not double-counted on item).
        if (row.order_item_piece_id) {
          const cur = byPiece[row.order_item_piece_id] ?? { open: 0, total: 0 };
          cur.total += 1;
          if (isOpen) cur.open += 1;
          byPiece[row.order_item_piece_id] = cur;
        } else if (row.order_item_id) {
          const cur = byItem[row.order_item_id] ?? { open: 0, total: 0 };
          cur.total += 1;
          if (isOpen) cur.open += 1;
          byItem[row.order_item_id] = cur;
        } else {
          orderScopedTotal += 1;
          if (isOpen) orderScopedOpen += 1;
        }
      }

      return {
        success: true,
        order: { open: orderScopedOpen, total: orderScopedTotal },
        byItem,
        byPiece,
      };
    } catch (error) {
      return {
        ...empty,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Resolve issue — sets solved_at / solved_by / solved_notes.
   */
  static async resolveIssue(
    issueId: string,
    tenantId: string,
    solvedNotes: string,
    userId: string,
    orderId?: string
  ): Promise<{
    success: boolean;
    issue?: Record<string, unknown>;
    error?: string;
    errorCode?: string;
  }> {
    try {
      const supabase = await createClient();

      let lookup = supabase
        .from('org_order_issues')
        .select('*')
        .eq('id', issueId)
        .eq('tenant_org_id', tenantId);
      if (orderId) {
        lookup = lookup.eq('order_id', orderId);
      }
      const { data: existing, error: lookupError } = await lookup.maybeSingle();

      if (lookupError || !existing) {
        return {
          success: false,
          error: 'Issue not found',
          errorCode: ORDER_ISSUE_ERROR.NOT_FOUND,
        };
      }

      if (existing.status === ORDER_ISSUE_STATUS.SOLVED || existing.solved_at) {
        return {
          success: false,
          issue: existing,
          error: 'Issue already solved',
          errorCode: ORDER_ISSUE_ERROR.ALREADY_SOLVED,
        };
      }

      const { data: issue, error: issueError } = await supabase
        .from('org_order_issues')
        .update({
          status: ORDER_ISSUE_STATUS.SOLVED,
          solved_at: new Date().toISOString(),
          solved_by: userId,
          solved_notes: solvedNotes,
        })
        .eq('id', issueId)
        .eq('tenant_org_id', tenantId)
        .select()
        .single();

      if (issueError || !issue) {
        return {
          success: false,
          error: 'Failed to resolve issue',
          errorCode: ORDER_ISSUE_ERROR.RESOLVE_FAILED,
        };
      }

      await OrderService.recomputeOrderHasIssue(
        issue.order_id as string,
        tenantId,
        supabase
      );

      // Clear pointers when no open issues remain for that entity
      if (issue.order_item_piece_id) {
        const { data: openPiece } = await supabase
          .from('org_order_issues')
          .select('id')
          .eq('tenant_org_id', tenantId)
          .eq('order_item_piece_id', issue.order_item_piece_id)
          .eq('status', ORDER_ISSUE_STATUS.OPEN)
          .limit(1);
        if (!openPiece?.length) {
          await supabase
            .from('org_order_item_pieces_dtl')
            .update({ issue_id: null })
            .eq('id', issue.order_item_piece_id)
            .eq('tenant_org_id', tenantId);
        }
      }
      if (issue.order_item_id) {
        const { data: openItem } = await supabase
          .from('org_order_issues')
          .select('id')
          .eq('tenant_org_id', tenantId)
          .eq('order_item_id', issue.order_item_id)
          .eq('status', ORDER_ISSUE_STATUS.OPEN)
          .limit(1);
        if (!openItem?.length) {
          await supabase
            .from('org_order_items_dtl')
            .update({ item_issue_id: null })
            .eq('id', issue.order_item_id)
            .eq('tenant_org_id', tenantId);
        }
      }
      const { data: openOrderScoped } = await supabase
        .from('org_order_issues')
        .select('id')
        .eq('tenant_org_id', tenantId)
        .eq('order_id', issue.order_id)
        .eq('scope_level', ORDER_ISSUE_SCOPE.ORDER)
        .eq('status', ORDER_ISSUE_STATUS.OPEN)
        .limit(1);
      if (!openOrderScoped?.length) {
        await supabase
          .from('org_orders_mst')
          .update({ issue_id: null })
          .eq('id', issue.order_id)
          .eq('tenant_org_id', tenantId);
      }

      await supabase.rpc('log_order_action', {
        p_tenant_org_id: tenantId,
        p_order_id: issue.order_id,
        p_action_type: 'ISSUE_SOLVED',
        p_from_value: issue.issue_code,
        p_to_value: 'resolved',
        p_done_by: userId,
        p_payload: {
          issue_id: issueId,
          solved_notes: solvedNotes,
          scope_level: issue.scope_level,
        },
      });

      return { success: true, issue };
    } catch (error) {
      console.error('OrderService.resolveIssue error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        errorCode: ORDER_ISSUE_ERROR.RESOLVE_FAILED,
      };
    }
  }

  /**
   * Get order history timeline
   * PRD-010: Complete audit trail
   */
  static async getOrderHistory(orderId: string, tenantId: string): Promise<any[]> {
    try {
      const supabase = await createClient();

      const { data, error } = await supabase
        .from('org_order_history')
        .select('*')
        .eq('order_id', orderId)
        .eq('tenant_org_id', tenantId)
        .order('done_at', { ascending: false });

      if (error) {
        console.error('Failed to fetch order history:', error);
        return [];
      }

      return (data || []) as any[];
    } catch (error) {
      console.error('OrderService.getOrderHistory error:', error);
      return [];
    }
  }

  /**
   * Split order by pieces (NEW)
   * Creates a new sub-order with selected pieces from items
   * PRD-010: Piece-level splitting for processing modal
   */
  static async splitOrderByPieces(
    orderId: string,
    tenantId: string,
    pieceIds: string[],
    reason: string,
    userId: string,
    userName: string
  ): Promise<any> {
    try {
      const supabase = await createClient();

      // Parse piece IDs to extract itemId and pieceNumber
      // Format: "{itemId}-piece-{pieceNumber}"
      const pieceMap = new Map<string, number[]>();

      pieceIds.forEach(pieceId => {
        const match = pieceId.match(/^(.+)-piece-(\d+)$/);
        if (match) {
          const itemId = match[1];
          const pieceNumber = parseInt(match[2], 10);
          const existing = pieceMap.get(itemId) || [];
          existing.push(pieceNumber);
          pieceMap.set(itemId, existing);
        }
      });

      if (pieceMap.size === 0) {
        return {
          success: false,
          error: 'No valid piece IDs found',
        };
      }

      // Get original order
      const { data: originalOrder, error: orderError } = await supabase
        .from('org_orders_mst')
        .select('*')
        .eq('id', orderId)
        .eq('tenant_org_id', tenantId)
        .single();

      if (orderError || !originalOrder) {
        return {
          success: false,
          error: 'Order not found or access denied',
        };
      }

      // Get items that have pieces being split
      const itemIds = Array.from(pieceMap.keys());
      const { data: items, error: itemsError } = await supabase
        .from('org_order_items_dtl')
        .select('*')
        .in('id', itemIds)
        .eq('tenant_org_id', tenantId);

      if (itemsError || !items || items.length === 0) {
        return {
          success: false,
          error: 'Items not found',
        };
      }

      // Generate new order number
      const timestamp = Date.now().toString().slice(-6);
      const newOrderNo = `${originalOrder.order_no}-S${timestamp}`;

      // Create sub-order
      const { data: suborder, error: createError } = await supabase
        .from('org_orders_mst')
        .insert({
          tenant_org_id: tenantId,
          order_no: newOrderNo,
          customer_id: originalOrder.customer_id,
          branch_id: originalOrder.branch_id,
          service_category_code: originalOrder.service_category_code,
          status: 'processing',
          current_status: 'processing',
          parent_order_id: orderId,
          order_subtype: 'split',
          priority: originalOrder.priority,
          payment_status: 'pending',
          subtotal: 0,
          total: 0,
          received_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (createError || !suborder) {
        return {
          success: false,
          error: 'Failed to create sub-order',
        };
      }

      // Create items in sub-order and update original items
      let movedPieces = 0;
      for (const item of items) {
        const piecesToMove = pieceMap.get(item.id) || [];
        const movingQuantity = piecesToMove.length;

        if (movingQuantity === 0) continue;

        // Create new item in suborder with the moving quantity
        await supabase
          .from('org_order_items_dtl')
          .insert({
            tenant_org_id: tenantId,
            order_id: suborder.id,
            branch_id: (item as any).branch_id ?? suborder.branch_id ?? null,
            product_id: item.product_id,
            service_category_code: item.service_category_code,
            product_name: item.product_name,
            product_name2: item.product_name2,
            quantity: movingQuantity,
            quantity_ready: 0,
            price_per_unit: item.price_per_unit,
            total_price: item.price_per_unit * movingQuantity,
            status: item.status,
            created_at: new Date().toISOString(),
          });

        // Update original item quantity
        const newQuantity = item.quantity - movingQuantity;
        await supabase
          .from('org_order_items_dtl')
          .update({
            quantity: newQuantity,
            updated_at: new Date().toISOString(),
          })
          .eq('id', item.id)
          .eq('tenant_org_id', tenantId);

        movedPieces += movingQuantity;
      }

      // Mark original order as having split
      await supabase
        .from('org_orders_mst')
        .update({
          has_split: true,
          updated_at: new Date().toISOString(),
        })
        .eq('id', orderId)
        .eq('tenant_org_id', tenantId);

      // Log history
      await supabase
        .from('org_order_history')
        .insert({
          tenant_org_id: tenantId,
          order_id: orderId,
          action_type: 'SPLIT',
          from_value: orderId,
          to_value: suborder.id,
          done_by: userId,
          done_at: new Date().toISOString(),
          payload: {
            reason,
            pieces_moved: movedPieces,
            new_order_no: newOrderNo,
            piece_ids: pieceIds,
          },
        });

      return {
        success: true,
        suborder,
      };
    } catch (error) {
      console.error('OrderService.splitOrderByPieces error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Update an existing order
   * PRD: Edit Order Feature - Backend Service
   *
   * Validates editability, manages locks, updates items/pieces, recalculates totals,
   * creates audit trail
   */
  static async updateOrder(params: UpdateOrderParams): Promise<UpdateOrderResult> {
    const {
      orderId,
      tenantId,
      userId,
      userName,
      ipAddress,
      userAgent,
      customerId,
      branchId,
      notes,
      customerNotes,
      paymentNotes,
      readyByAt,
      express,
      items,
      customerName,
      customerMobile,
      customerEmail,
      isDefaultCustomer,
      customerDetails,
      recalculate = false,
      expectedUpdatedAt,
      isQuickDrop,
      quickDropQuantity,
      editReason,
      idempotencyKey,
    } = params;

    try {
      // 1. Fetch existing order with items (use Prisma for consistency with GET - bypasses Supabase RLS)
      const orderFromDb = await getOrderById(tenantId, orderId);
      if (!orderFromDb) {
        return {
          success: false,
          error: 'Order not found',
        };
      }

      // Map to shape expected by rest of updateOrder (snake_case, items with product_id)
      const existingOrder = {
        ...orderFromDb,
        items: (orderFromDb.items ?? []).map((item: { id: string; product_id?: string; quantity?: number; price_per_unit?: unknown; total_price?: unknown; notes?: string; has_stain?: boolean; has_damage?: boolean }) => ({
          id: item.id,
          product_id: item.product_id,
          quantity: item.quantity,
          price_per_unit: item.price_per_unit,
          total_price: item.total_price,
          notes: item.notes,
          has_stain: item.has_stain,
          has_damage: item.has_damage,
        })),
        ready_by_at: (orderFromDb as { ready_by?: Date; ready_by_at_new?: Date }).ready_by_at_new ?? (orderFromDb as { ready_by?: Date }).ready_by ?? null,
      };

      // 2. Validate editability
      const editabilityCheck = isOrderEditable(existingOrder);
      if (!editabilityCheck.canEdit) {
        return {
          success: false,
          error: editabilityCheck.reason || 'Order cannot be edited',
        };
      }

      // 3. Check for active lock
      const lockStatus = await checkOrderLock(orderId, tenantId);
      if (lockStatus.isLocked && lockStatus.lock?.lockedBy !== userId) {
        return {
          success: false,
          error: `Order is locked by ${lockStatus.lock?.lockedByName || 'another user'}`,
        };
      }

      // 4. Optimistic locking check
      if (expectedUpdatedAt) {
        const existingUpdatedAt = new Date(existingOrder.updated_at);
        const expectedDate = new Date(expectedUpdatedAt);
        if (existingUpdatedAt.getTime() !== expectedDate.getTime()) {
          return {
            success: false,
            error: 'Order has been modified by another user. Please refresh and try again.',
          };
        }
      }

      const snapshotBeforeFinancial = readCanonicalOrderFinancialSnapshot(
        existingOrder as Record<string, unknown>,
      );

      // 5. Create snapshot_before
      const snapshotBefore = {
        order: {
          id: existingOrder.id,
          orderNo: existingOrder.order_no,
          customerId: existingOrder.customer_id,
          branchId: existingOrder.branch_id,
          notes: existingOrder.internal_notes,
          customerNotes: existingOrder.customer_notes,
          paymentNotes: existingOrder.payment_notes,
          readyByAt: existingOrder.ready_by_at,
          express: existingOrder.priority_multiplier === 0.5,
          subtotal: snapshotBeforeFinancial.subtotalAmount,
          discount: snapshotBeforeFinancial.totalDiscountAmount,
          tax: snapshotBeforeFinancial.totalTaxAmount,
          total: snapshotBeforeFinancial.totalAmount,
          customerName: existingOrder.customer_name,
          customerMobile: existingOrder.customer_mobile_number,
          customerEmail: existingOrder.customer_email,
          isQuickDrop: existingOrder.is_order_quick_drop,
          quickDropQuantity: existingOrder.quick_drop_quantity,
        },
        items: existingOrder.items?.map((item: any) => ({
          id: item.id,
          productId: item.product_id,
          productName: item.product_name ?? item.productName ?? null,
          quantity: item.quantity,
          pricePerUnit: item.price_per_unit,
          totalPrice: item.total_price,
          notes: item.notes ?? null,
          hasStain: item.has_stain ?? null,
          hasDamage: item.has_damage ?? null,
          stainNotes: item.stain_notes ?? null,
          damageNotes: item.damage_notes ?? null,
        })) || [],
      };

      // 5b. B12 — governed-amendment gate. Only item-list replacements are in
      // scope (matches the doc's "item add/remove/qty/price-override" scope);
      // notes-only/express-only/recalculate-only edits never reach this branch.
      // Runs entirely BEFORE the transaction opens: a dry-run reprice (same
      // canonical-engine call the real repricing below makes, side-effect-free)
      // tells us the prospective delta so reason/permission/idempotency can
      // fail fast with zero partial writes.
      let amendmentGate: {
        delta: AmendmentDeltaResult;
        payloadHash: string;
      } | null = null;
      let idempotentReplayEditHistoryId: string | null = null;

      if (items && items.length > 0) {
        const totalPaidAmount = Number((existingOrder as any).total_paid_amount ?? 0);
        const governedFlagEnabled = await canAccess(tenantId, 'order_fin_governed_amendments');

        if (governedFlagEnabled && totalPaidAmount > 0) {
          const dryRunResult = await calculateOrderTotals({
            tenantId,
            branchId: branchId ?? existingOrder.branch_id,
            items: items.map((item) => ({
              productId: item.productId,
              quantity: item.quantity,
              servicePrefCharge: item.servicePrefCharge ?? 0,
              packingPrefCharge: item.packingPrefCharge ?? 0,
            })),
            customerId: customerId ?? existingOrder.customer_id,
            isExpress: express ?? existingOrder.priority_multiplier === 0.5,
            userId,
          });

          const delta = computeAmendmentDelta({
            previousTotal: snapshotBeforeFinancial.totalAmount,
            newTotal: dryRunResult.saleTotal,
            totalPaidAmount,
            governedFlagEnabled,
          });

          if (delta.isGoverned) {
            await assertGovernedAmendmentAllowed({ tenantId, userId, editReason });
            const staked = await stakeAmendmentIdempotency(
              tenantId,
              orderId,
              idempotencyKey,
              { items, express, customerId, branchId },
            );
            if (staked.editHistoryId) {
              // Replay: a prior call with this exact key+payload already
              // completed. Short-circuit — no re-edit, no duplicate audit row.
              idempotentReplayEditHistoryId = staked.editHistoryId;
            } else {
              amendmentGate = { delta, payloadHash: staked.payloadHash };
            }
          }
        }
      }

      if (idempotentReplayEditHistoryId) {
        const replayed = await prisma.org_order_edit_history.findFirst({
          where: { id: idempotentReplayEditHistoryId, tenant_org_id: tenantId, order_id: orderId },
        });
        const currentOrder = await prisma.org_orders_mst.findUnique({
          where: { id: orderId, tenant_org_id: tenantId },
        });
        return {
          success: true,
          order: currentOrder && {
            ...currentOrder,
            // state_version is BIGINT in the DB — see migration 0439.
            state_version:
              typeof currentOrder.state_version === 'bigint'
                ? Number(currentOrder.state_version)
                : currentOrder.state_version,
          },
          idempotentReplay: true,
          editHistoryId: idempotentReplayEditHistoryId,
          requiresSettlement: replayed ? !replayed.payment_adjusted : false,
          ...(replayed?.payment_adjustment_amount != null && {
            financialDelta: {
              previousTotal: snapshotBeforeFinancial.totalAmount,
              newTotal: snapshotBeforeFinancial.totalAmount + Number(replayed.payment_adjustment_amount) * (replayed.payment_adjustment_type === 'REFUND' ? -1 : 1),
              deltaAmount: Number(replayed.payment_adjustment_amount) * (replayed.payment_adjustment_type === 'REFUND' ? -1 : 1),
              isGoverned: true,
            },
          }),
        };
      }

      // 6. Use Prisma transaction for atomic updates
      const result = await prisma.$transaction(async (tx) => {
        // 7. Delete old items/pieces if items array provided
        if (items && items.length >= 0) {
          // Delete all pieces first
          await tx.org_order_item_pieces_dtl.deleteMany({
            where: {
              order_id: orderId,
              tenant_org_id: tenantId,
            },
          });

          // Delete all items
          await tx.org_order_items_dtl.deleteMany({
            where: {
              order_id: orderId,
              tenant_org_id: tenantId,
            },
          });
        }

        // 8. Recalculate totals if items changed or recalculate flag set
        let subtotal = snapshotBeforeFinancial.subtotalAmount;
        let discount = snapshotBeforeFinancial.totalDiscountAmount;
        let tax = snapshotBeforeFinancial.totalTaxAmount;
        let total = snapshotBeforeFinancial.totalAmount;
        let vatRate = (existingOrder as any).vat_rate;
        // B17: preserve the already-persisted adjustment unless a recalc runs —
        // a non-recalculating edit (e.g. notes-only) must never zero it out.
        let roundingAdjustment = Number((existingOrder as any).rounding_adjustment_amount ?? 0);

        const shouldRecalculateTotals = Boolean((items && items.length > 0) || recalculate || express !== undefined);

        if (shouldRecalculateTotals) {
          const calculationItems = items && items.length > 0
            ? items.map((item) => ({
                productId: item.productId,
                quantity: item.quantity,
                servicePrefCharge: item.servicePrefCharge ?? 0,
                packingPrefCharge: item.packingPrefCharge ?? 0,
              }))
            : (await tx.org_order_items_dtl.findMany({
                where: {
                  order_id: orderId,
                  tenant_org_id: tenantId,
                },
                select: {
                  product_id: true,
                  quantity: true,
                  service_pref_charge: true,
                },
              })).map((item) => ({
                productId: item.product_id,
                quantity: item.quantity,
                servicePrefCharge: Number(item.service_pref_charge ?? 0),
                packingPrefCharge: 0,
              }));

          const calculationResult = await calculateOrderTotals({
            tenantId,
            branchId: branchId ?? existingOrder.branch_id,
            items: calculationItems,
            customerId: customerId ?? existingOrder.customer_id,
            isExpress: express ?? existingOrder.priority_multiplier === 0.5,
            userId,
          });

          subtotal = calculationResult.subtotal;
          discount = calculationResult.manualDiscount + calculationResult.promoDiscount;
          tax = calculationResult.taxAmount;
          total = calculationResult.saleTotal;
          vatRate = calculationResult.taxRate;
          roundingAdjustment = calculationResult.roundingAdjustmentAmount;
        }

        // 9. Create new items/pieces
        if (items && items.length > 0) {
          const orderNo = existingOrder.order_no;
          const v_initialStatus = existingOrder.current_status || 'processing';
          const v_transitionFrom = existingOrder.current_stage || 'intake';

          const packingPriceMapOrderEdit = await fetchOrgPackingExtraPriceByCodesPrismaTx(
            tx,
            tenantId,
            collectPackingPrefCodesFromOrderPayload(items)
          );

          for (let index = 0; index < items.length; index++) {
            const item = items[index];

            // Create item (omit undefined - Prisma rejects undefined for optional fields)
            const createdItem = await tx.org_order_items_dtl.create({
              data: {
                order_id: orderId,
                tenant_org_id: tenantId,
                branch_id: branchId ?? existingOrder.branch_id ?? null,
                service_category_code: item.serviceCategoryCode || 'GENERAL',
                order_item_srno: `${orderNo}-${index + 1}`,
                product_id: item.productId,
                quantity: item.quantity,
                price_per_unit: item.pricePerUnit,
                total_price: item.totalPrice,
                status: 'pending',
                item_status: v_initialStatus,
                item_stage: v_transitionFrom,
                created_by: userId,
                rec_status: 1,
                ...(item.notes != null && { notes: item.notes }),
                ...(item.hasStain != null && { has_stain: item.hasStain }),
                ...(item.hasDamage != null && { has_damage: item.hasDamage }),
                ...(item.stainNotes != null && { stain_notes: item.stainNotes }),
                ...(item.damageNotes != null && { damage_notes: item.damageNotes }),
              },
            });

            // Create pieces for item
            const piecesData = item.pieces && item.pieces.length > 0
              ? item.pieces.map((piece, idx) => ({
                pieceSeq: piece.pieceSeq || idx + 1,
                color: piece.color,
                colorCodes: piece.colorCodes,
                colorCfIds: piece.colorCfIds,
                brand: piece.brand,
                hasStain: piece.hasStain ?? item.hasStain,
                hasDamage: piece.hasDamage ?? item.hasDamage,
                notes: piece.notes || item.notes,
                rackLocation: piece.rackLocation,
                metadata: piece.metadata || {},
                packingPrefCode: piece.packingPrefCode,
                packingCfId: piece.packingCfId,
                servicePrefs: piece.servicePrefs,
                conditions: piece.conditions,
              }))
              : undefined;

            // Use the tx-aware method: runs entirely within the Prisma transaction
            // so all writes are atomic and visible to each other without isolation gaps.
            await OrderPieceService.createPiecesForItemWithTx(
              tx,
              tenantId,
              orderId,
              createdItem.id,
              item.quantity,
              {
                serviceCategoryCode: item.serviceCategoryCode || 'GENERAL',
                productId: item.productId,
                pricePerUnit: item.pricePerUnit,
                totalPrice: item.totalPrice,
                hasStain: item.hasStain,
                hasDamage: item.hasDamage,
                notes: item.notes,
                metadata: {},
              },
              piecesData,
              branchId ?? existingOrder.branch_id ?? undefined,
              packingPriceMapOrderEdit,
              'ORDER_EDIT'
            );
          }
        }

        // 10. Update order master fields
        const updateData: any = {
          updated_at: new Date(),
          updated_by: userId,
        };

        if (customerId !== undefined) updateData.customer_id = customerId;
        if (branchId !== undefined) updateData.branch_id = branchId;
        if (notes !== undefined) updateData.internal_notes = notes;
        if (customerNotes !== undefined) updateData.customer_notes = customerNotes;
        if (paymentNotes !== undefined) updateData.payment_notes = paymentNotes;
        if (readyByAt !== undefined) {
          updateData.ready_by = readyByAt;
          updateData.ready_by_at_new = readyByAt;
        }
        if (express !== undefined) updateData.priority_multiplier = express ? 0.5 : 1.0;
        if (customerName !== undefined) updateData.customer_name = customerName;
        if (customerMobile !== undefined) updateData.customer_mobile_number = customerMobile;
        if (customerEmail !== undefined) updateData.customer_email = customerEmail;
        if (isDefaultCustomer !== undefined) updateData.is_default_customer = isDefaultCustomer;
        if (customerDetails !== undefined) updateData.customer_details = customerDetails;
        if (isQuickDrop !== undefined) updateData.is_order_quick_drop = isQuickDrop;
        if (quickDropQuantity !== undefined) updateData.quick_drop_quantity = quickDropQuantity;

        // Update totals if changed
        if (items && items.length >= 0) {
          updateData.subtotal_amount = subtotal;
          updateData.items_base_amount = subtotal;
          updateData.total_discount_amount = discount;
          updateData.total_tax_amount = tax;
          updateData.total_amount = total;
          updateData.vat_rate = vatRate;
          updateData.rounding_adjustment_amount = roundingAdjustment;
          // B12 Design decision #5: outstanding_amount is no longer set here.
          // Setting it to `total` ignored total_paid_amount entirely (a paid
          // order's outstanding would read as the full new total for one
          // write) — recalculateOrderFinancialSnapshotTx below is the single
          // canonical writer of outstanding_amount, matching every other
          // financially-governed path in the codebase.
          updateData.total_items = items.length;
        }

        const updatedOrder = await tx.org_orders_mst.update({
          where: {
            id: orderId,
            tenant_org_id: tenantId,
          },
          data: updateData,
        });

        if (shouldRecalculateTotals) {
          await recalculateOrderFinancialSnapshotTx(tx, tenantId, orderId);
        }

        return updatedOrder;
      });

      // 11. Fetch updated order with items for snapshot_after (use Prisma)
      const updatedOrderWithItems = await prisma.org_orders_mst.findUnique({
        where: { id: orderId, tenant_org_id: tenantId },
        include: { org_order_items_dtl: { orderBy: { created_at: 'asc' } } },
      });

      if (!updatedOrderWithItems) {
        logger.error('[updateOrder] Order not found after update', undefined, {
          feature: 'orders',
          action: 'update_order',
          orderId,
          tenantId,
        });
        return {
          success: false,
          error: 'Order not found',
        };
      }

      const readyByAtVal = updatedOrderWithItems.ready_by_at_new ?? updatedOrderWithItems.ready_by ?? null;

      // 12. Create snapshot_after
      // Build product name lookup from input items (DB re-fetch doesn't join product names)
      const inputItemNameMap = new Map<string, string>(
        (items ?? []).map((i) => [i.productId, i.productName ?? i.productId.slice(0, 8)])
      );
      const snapshotAfterFinancial = readCanonicalOrderFinancialSnapshot(
        updatedOrderWithItems as unknown as Record<string, unknown>,
      );

      const snapshotAfter = {
        order: {
          id: updatedOrderWithItems.id,
          orderNo: updatedOrderWithItems.order_no,
          customerId: updatedOrderWithItems.customer_id,
          branchId: updatedOrderWithItems.branch_id,
          notes: updatedOrderWithItems.internal_notes,
          customerNotes: updatedOrderWithItems.customer_notes,
          paymentNotes: updatedOrderWithItems.payment_notes,
          readyByAt: readyByAtVal,
          express: Number(updatedOrderWithItems.priority_multiplier) === 0.5,
          subtotal: snapshotAfterFinancial.subtotalAmount,
          discount: snapshotAfterFinancial.totalDiscountAmount,
          tax: snapshotAfterFinancial.totalTaxAmount,
          total: snapshotAfterFinancial.totalAmount,
          customerName: updatedOrderWithItems.customer_name,
          customerMobile: updatedOrderWithItems.customer_mobile_number,
          customerEmail: updatedOrderWithItems.customer_email,
          isQuickDrop: updatedOrderWithItems.is_order_quick_drop,
          quickDropQuantity: updatedOrderWithItems.quick_drop_quantity,
        },
        items: (updatedOrderWithItems.org_order_items_dtl ?? []).map((item) => {
          const inputItem = (items ?? []).find((i) => i.productId === item.product_id);
          return {
            id: item.id,
            productId: item.product_id,
            productName: inputItemNameMap.get(item.product_id ?? '') ?? (item as any).product_name ?? null,
            quantity: item.quantity,
            pricePerUnit: item.price_per_unit,
            totalPrice: item.total_price,
            notes: item.notes ?? null,
            hasStain: item.has_stain ?? null,
            hasDamage: item.has_damage ?? null,
            stainNotes: inputItem?.stainNotes ?? (item as any).stain_notes ?? null,
            damageNotes: inputItem?.damageNotes ?? (item as any).damage_notes ?? null,
          };
        }),
      };

      // 13. Create audit entry. payment_adjusted stays false at this point even
      // for a governed edit — the delta is known, but settlement (collect-
      // additional / overpayment-resolution) is a separate cashier-driven step
      // the caller completes afterward via recordAmendmentSettlement (B12).
      const auditEntry = await createEditAudit({
        tenantId,
        orderId,
        orderNo: existingOrder.order_no,
        editedBy: userId,
        editedByName: userName,
        ipAddress,
        userAgent,
        snapshotBefore,
        snapshotAfter,
        paymentAdjusted: false,
        paymentAdjustmentAmount: undefined,
        paymentAdjustmentType: undefined,
        editReason: amendmentGate ? editReason : undefined,
      });

      if (amendmentGate && idempotencyKey) {
        await completeAmendmentIdempotency(tenantId, idempotencyKey, amendmentGate.payloadHash, auditEntry.id);
      }

      // 14. Unlock order
      try {
        await unlockOrder({
          orderId,
          tenantId,
          userId,
        });
      } catch (unlockError) {
        // Log but don't fail - lock will expire anyway
        logger.warn('[updateOrder] Failed to unlock order', {
          feature: 'orders',
          action: 'update_order',
          orderId,
          error: unlockError instanceof Error ? unlockError.message : 'Unknown error',
        });
      }

      logger.info('[updateOrder] Order updated successfully', {
        feature: 'orders',
        action: 'update_order',
        orderId,
        userId,
        itemsChanged: items ? items.length : 0,
      });

      return {
        success: true,
        order: {
          ...updatedOrderWithItems,
          // state_version is BIGINT in the DB (workflow-engine optimistic
          // concurrency token); Prisma returns it as a native bigint, which
          // JSON.stringify cannot serialize (see migration 0439).
          state_version:
            typeof updatedOrderWithItems.state_version === 'bigint'
              ? Number(updatedOrderWithItems.state_version)
              : updatedOrderWithItems.state_version,
        },
        ...(amendmentGate && {
          financialDelta: amendmentGate.delta,
          editHistoryId: auditEntry.id,
          requiresSettlement: true,
        }),
      };
    } catch (error) {
      logger.error('[updateOrder] Failed to update order', error as Error, {
        feature: 'orders',
        action: 'update_order',
        orderId,
        userId,
      });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update order',
        ...(error instanceof AmendmentGovernanceError && { errorCode: error.code }),
      };
    }
  }
}

// Re-export lock service functions for convenience
export { lockOrderForEdit, unlockOrder, checkOrderLock } from '@/lib/services/order-lock.service';
