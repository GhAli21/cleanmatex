/**
 * CANONICAL ORDER SUBMISSION ORCHESTRATOR
 *
 * All business logic for order creation + payment settlement lives here.
 * The submit-order route is a thin shell that delegates to submitOrder().
 *
 * Voucher creation, BVM wiring, and settlement run in the same transaction
 * so submit-order cannot commit an order without its finance facts.
 */

import 'server-only';

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { withTenantContext } from '@/lib/db/tenant-context';
import { OrderService } from '@/lib/services/order-service';
import { calculateOrderTotals } from '@/lib/services/order-calculation.service';
import { createArInvoiceFromOrders } from '@/lib/services/ar-invoice.service';
import { applyPromoCodeTx } from '@/lib/services/discount-service';
import { applyStoredValueDebitTx } from '@/lib/services/order-credit-application.service';
import { settleOrderTx } from '@/lib/services/order-settlement.service';
import { maybeIssueTaxDocumentTx } from '@/lib/services/tax-document-issuance.service';
import { TAX_DOCUMENT_TRIGGER_EVENTS } from '@/lib/constants/order-financial';
import { checkCreditLimit, assertCreditWithinPolicy } from '@/lib/services/credit-limit.service';
import { createBizVoucher } from '@/lib/services/voucher-biz.service';
import { addVoucherLine } from '@/lib/services/voucher-line.service';
import { resolveVoucherCashChangeReturned } from '@/lib/payments/resolve-voucher-cash-change';
import { postAndWireBizVoucher, getVoucherLinkedEffects } from '@/lib/services/voucher-wiring.service';
import { buildSettlementPlan, validateSettlementPlan } from '@/lib/services/order-settlement-planner.service';
import { validateOverpaymentResolution } from '@/lib/services/overpayment-resolution-validator.service';
import { executeOverpaymentDispositionTx } from '@/lib/services/overpayment-disposition.service';
import {
  executeAllocationPreviewTx,
  extractAllocationPreviewId,
  getDispositionLinesExcludingAllocation,
  resolutionIncludesAllocation,
} from '@/lib/services/customer-receipt-excess-executor.service';
import { listEffectivePaymentMethodConfigs } from '@/lib/services/payment-config.service';
import { resolveCashDrawerSessionId } from '@/lib/services/cash-drawer.service';
import {
  assertOpenPosSessionForFinanceTx,
  autoLinkDrawerTx,
} from '@/lib/services/pos-session.service';
import { PAYMENT_METHODS, getPaymentTypeFromMethod } from '@/lib/constants/order-types';
import { getPaymentTypeFromOutstandingPolicy } from '@/lib/constants/payment';
import {
  TAX_TYPES,
  CREDIT_APPLICATION_TYPES,
  PAYMENT_NATURE,
  STORED_VALUE_SUB_IDEMPOTENCY_CODE,
} from '@/lib/constants/order-financial';
import type { CreditApplicationType } from '@/lib/constants/order-financial';
import { LINE_ROLE, LINE_TYPE, VOUCHER_TYPE } from '@/lib/constants/voucher';
import { logger } from '@/lib/utils/logger';
import { sumMoney } from '@/lib/utils/money';
import { Decimal } from '@prisma/client/runtime/library';
import type { AmountMismatchDifferences, PaymentMethodCode } from '@/lib/types/payment';
import type {
  OutstandingPolicy,
  PaymentLeg,
  SubmitOrderRequest,
} from '@/lib/validations/new-order-payment-schemas';
import type {
  FinancialBreakdownSnapshot,
  ResolvedSettlementLeg,
  TaxLineItem,
  DiscountLineInput as FinancialDiscountLineInput,
  SettlementOption,
} from '@/lib/types/order-financial';
import type { PostAndWireResult } from '@/lib/types/voucher-wiring';
import type { RequestAuditContext } from '@/lib/utils/request-audit';

const TOLERANCE = 0.001;

/**
 * Compares two monetary values using the orchestrator tolerance to avoid false mismatches.
 *
 * @param a First amount to compare.
 * @param b Second amount to compare.
 * @returns `true` when the values are close enough to be treated as equal.
 */
function withinTolerance(a: number, b: number): boolean {
  return Math.abs(a - b) <= TOLERANCE;
}

/**
 * Normalizes nullable Prisma decimals into plain numbers for calculation helpers.
 *
 * @param d Prisma decimal value from persistence.
 * @returns Numeric amount or zero when the value is absent.
 */
function toNum(d: Decimal | null | undefined): number {
  return d ? Number(d) : 0;
}

function buildDifferences(
  client: { subtotal: number; manualDiscount?: number; promoDiscount?: number; vatValue: number; saleTotal: number },
  server: { subtotal: number; manualDiscount: number; promoDiscount: number; vatValue: number; saleTotal: number }
): AmountMismatchDifferences {
  const diff: AmountMismatchDifferences = {};
  if (!withinTolerance(client.subtotal, server.subtotal))
    diff.subtotal = { client: client.subtotal, server: server.subtotal };
  if (!withinTolerance(client.manualDiscount ?? 0, server.manualDiscount))
    diff.manualDiscount = { client: client.manualDiscount ?? 0, server: server.manualDiscount };
  if (!withinTolerance(client.promoDiscount ?? 0, server.promoDiscount))
    diff.promoDiscount = { client: client.promoDiscount ?? 0, server: server.promoDiscount };
  if (!withinTolerance(client.vatValue, server.vatValue))
    diff.vatValue = { client: client.vatValue, server: server.vatValue };
  if (!withinTolerance(client.saleTotal, server.saleTotal))
    diff.saleTotal = { client: client.saleTotal, server: server.saleTotal };
  return diff;
}

function normalizeOutstandingPolicy(
  inputPolicy: OutstandingPolicy | undefined,
  unpaidAmount: number,
  fallbackMethod: string
): OutstandingPolicy {
  if (unpaidAmount <= TOLERANCE) {
    return 'NONE';
  }

  if (inputPolicy && inputPolicy !== 'NONE') {
    return inputPolicy;
  }

  if (fallbackMethod === PAYMENT_METHODS.INVOICE) {
    return 'CREDIT_INVOICE';
  }

  return 'PAY_ON_COLLECTION';
}

// ── Public types ──────────────────────────────────────────────────────────────

/**
 * Input contract for the canonical order submission orchestrator.
 */
export interface SubmitOrderParams {
  tenantId:     string;
  userId:       string;
  userName:     string;
  branchId?:    string;
  input:        SubmitOrderRequest;
  requestAudit: RequestAuditContext;
}

/**
 * Output contract returned after order creation, settlement, and optional voucher wiring.
 */
export interface SubmitOrderResult {
  order: {
    id:                       string;
    orderNo:                  string;
    currentStatus:            string;
    totalAmount:              string;
    totalPaidAmount:          string;
    totalCreditAppliedAmount: string;
    outstandingAmount:        string;
    paymentStatus:            string;
    paymentTypeCode:          string;
  };
  voucher?: {
    id:           string;
    voucherNo:    string;
    status:       string;
    wiringStatus: 'WIRED' | 'PARTIALLY_WIRED';
  };
  effects: {
    orderPayments:      Array<{ id: string; amount: unknown; paymentMethodCode: string; paymentStatus: string }>;
    creditApplications: Array<{ id: string; amount: unknown; creditType: string }>;
    cashMovements:      Array<{ id: string; amount: unknown; sessionId: string | null }>;
  };
  warnings: string[];
}

// ── Branch resolution ─────────────────────────────────────────────────────────

/**
 * Resolves the effective branch for an order submission.
 *
 * Resolution order:
 *  1. Use branchId if it is a valid UUID and exists in org_branches_mst for the tenant.
 *  2. Fall back to the tenant's main branch (is_main=true).
 *  3. Return undefined when no branch can be resolved (order proceeds branch-less).
 *
 * Invalid UUIDs (empty string, non-UUID strings) are treated as absent rather than
 * rejected, so callers do not need to pre-validate the branch ID format.
 *
 * @param tenantId  Tenant organisation ID — used to scope the branch lookup.
 * @param branchId  Optional client-supplied branch UUID. Falsy or non-UUID values
 *                  are silently ignored and the main-branch fallback is used.
 * @returns Resolved branch UUID, or undefined when no branch is available.
 *
 * @example
 * const branchId = await resolveOrderBranch(tenantId, input.branchId ?? undefined);
 * // Returns main branch ID when input.branchId is absent or invalid.
 */
export async function resolveOrderBranch(
  tenantId: string,
  branchId?: string
): Promise<string | undefined> {
  const UUID_REGEX = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/i;

  let resolved: string | undefined = branchId;
  if (resolved && !UUID_REGEX.test(resolved.trim())) resolved = undefined;

  if (resolved) {
    const branch = await prisma.org_branches_mst.findFirst({
      where: { id: resolved, tenant_org_id: tenantId },
      select: { id: true },
    });
    if (!branch) resolved = undefined;
  }

  if (!resolved) {
    const mainBranch = await prisma.org_branches_mst.findFirst({
      where: { tenant_org_id: tenantId, is_main: true },
      select: { id: true },
    });
    resolved = mainBranch?.id ?? undefined;
  }

  return resolved;
}

// ── Orchestrator ──────────────────────────────────────────────────────────────

/**
 * Submits an order with payment settlement, optionally wiring a receipt voucher.
 *
 * This function is idempotency-unaware by design (D11). The route handler owns
 * the full idempotency lifecycle: it checks for an existing order by idempotencyKey
 * before calling this function, and writes the key back to the order row after
 * success. This keeps the orchestrator stateless and testable without key management.
 *
 * Flow:
 *  1. Calculate server-side totals + validate against client
 *  2. Validate payment legs (deferred rules, credit limit, check fields)
 *  3. tx1 — create order + invoice + promo/gift redemptions
 *  4. Resolve org_payment_methods_cf with D9 COALESCE config
 *  5. Build + validate settlement plan (fail-fast before any voucher creation)
 *  6. Create receipt voucher + lines + post+wire (when plan.shouldCreateReceiptVoucher)
 *  7. settleOrderTx(wiringMode) — skips payment fact rows when wiring ran
 *  8. Return SubmitOrderResult (order snapshot + voucher + effects + warnings)
 *
 * @param params Submission context containing tenant scope, actor identity, input payload, and request audit data.
 * @returns SubmitOrderResult containing order snapshot, optional voucher summary,
 *          linked BVM effects, and non-fatal warnings (e.g. GATEWAY_PAYMENT_PROCESSING).
 * @throws Error('AMOUNT_MISMATCH')               — server totals differ from client totals.
 * @throws Error('PRODUCT_NOT_FOUND')             — a line item product does not exist for this tenant.
 * @throws Error('B2B_CREDIT_HOLD')               — customer has a credit hold; order blocked.
 * @throws Error('B2B_CREDIT_EXCEEDED')           — order would exceed credit limit (with creditLimit/available attached). Hard-denied for everyone since Phase 0B; `input.creditLimitOverride` is inert.
 * @throws Error('SPLIT_AMOUNT_MISMATCH')         — sum of multi-leg amounts ≠ order total.
 * @throws Error('DEFERRED_LEG_NOT_ALONE')        — deferred method mixed with other legs in a split.
 * @throws Error('CHECK_NUMBER_REQUIRED')         — CHECK leg missing a non-empty checkNumber.
 * @throws Error('CASH_DRAWER_SESSION_REQUIRED')  — CASH leg needs a drawer session but none supplied or found.
 * @throws Error('CASH_DRAWER_SESSION_CLOSED')    — referenced drawer session is not in OPEN status.
 * @throws Error('CASH_TENDERED_LESS_THAN_AMOUNT') — tendered cash is below the leg amount.
 * @throws Error('GATEWAY_NOT_CONFIGURED')        — gateway leg has no active org_payment_gateway_cf row.
 * @throws Error('PAYMENT_REFERENCE_REQUIRED')    — requiresReference=true leg has no reference field.
 *
 * @example
 * const result = await submitOrder({
 *   tenantId:     'org_uuid',
 *   userId:       'user_uuid',
 *   userName:     'Ali',
 *   branchId:     'branch_uuid',
 *   input:        parsedInput,
 *   requestAudit: getRequestAuditContext(request),
 * });
 * // result.order.id  → created order UUID
 * // result.voucher   → receipt voucher summary (when real/credit legs exist)
 * // result.warnings  → ['GATEWAY_PAYMENT_PROCESSING'] etc.
 */
export async function submitOrder(params: SubmitOrderParams): Promise<SubmitOrderResult> {
  const { tenantId, userId, userName, branchId, input, requestAudit } = params;
  const { clientTotals } = input;

  // ── 1. Server-side totals ────────────────────────────────────────────────────
  const serverTotals = await calculateOrderTotals({
    tenantId,
    branchId,
    userId,
    items: input.items.map((i) => ({
      productId:        i.productId,
      quantity:         i.quantity,
      priceOverride:    i.priceOverride ?? null,
      servicePrefCharge: i.servicePrefCharge ?? 0,
      packingPrefCharge: i.packingPrefCharge ?? 0,
    })),
    customerId:          input.customerId,
    isExpress:           input.express ?? false,
    percentDiscount:     input.percentDiscount ?? 0,
    amountDiscount:      input.amountDiscount ?? 0,
    promoCode:           input.promoCode,
    promoCodeId:         input.promoCodeId,
    giftCardNumber:      input.giftCardNumber,
    giftCardAmount:      input.giftCardAmount,
    giftCardId:          input.giftCardId,
    serviceCategories:   Array.from(new Set(input.items.map((item) => item.serviceCategoryCode).filter(Boolean))),
    taxProfileIds:       input.taxProfileIds,
    orderCharges: (input.orderServicePrefs ?? []).map((p) => ({
      label: p.preference_code,
      amount: p.extra_price,
    })),
  });
  const clientSaleTotal = clientTotals.saleTotal;
  const serverSaleTotal = serverTotals.saleTotal;

  const differences = buildDifferences(
    {
      subtotal:       clientTotals.subtotal,
      manualDiscount: clientTotals.manualDiscount,
      promoDiscount:  clientTotals.promoDiscount,
      vatValue:       clientTotals.vatValue,
      saleTotal:      clientSaleTotal,
    },
    {
      subtotal:       serverTotals.subtotal,
      manualDiscount: serverTotals.manualDiscount,
      promoDiscount:  serverTotals.promoDiscount,
      vatValue:       serverTotals.vatValue,
      saleTotal:      serverSaleTotal,
    }
  );

  if (Object.keys(differences).length > 0) {
    const err = new Error('AMOUNT_MISMATCH');
    (err as Error & { differences: unknown }).differences = differences;
    throw err;
  }

  // ── 2. Payment leg resolution + validation ───────────────────────────────────
  const DEFERRED_METHODS = new Set<string>([PAYMENT_METHODS.PAY_ON_COLLECTION, PAYMENT_METHODS.INVOICE]);

  const paymentLegs: PaymentLeg[] = (input.paymentLegs && input.paymentLegs.length > 0)
    ? input.paymentLegs
    : [
        {
          method:      input.paymentMethod as PaymentLeg['method'],
          amount:      input.amountToCharge ?? clientSaleTotal,
          checkNumber: input.checkNumber,
          checkBank:   input.checkBank,
          checkDate:   input.checkDate,
        },
      ];

  const isDeferredOnly = paymentLegs.every((leg) => DEFERRED_METHODS.has(leg.method));
  const hasDeferredLeg = paymentLegs.some((leg) => DEFERRED_METHODS.has(leg.method));
  const hasImmediatePayment = paymentLegs.some((leg) => !DEFERRED_METHODS.has(leg.method));
  // sumMoney avoids float drift across multi-leg totals (e.g. CASH 33.333 + CARD 66.667).
  const amountToCharge = sumMoney(
    paymentLegs.filter((leg) => !DEFERRED_METHODS.has(leg.method)).map((leg) => leg.amount)
  ).toNumber();
  // Gift-card credit is synthesized into settlementLegs after this check; subtract it here
  // so outstandingPolicy NONE is valid when legs + gift cover the sale total.
  const giftApplied =
    input.giftCardId && serverTotals.giftCardApplied > 0 ? serverTotals.giftCardApplied : 0;
  const unpaidBalance = Math.max(0, serverSaleTotal - amountToCharge - giftApplied);
 
  if (input.outstandingPolicy === 'NONE' && unpaidBalance > TOLERANCE) {
    throw new Error('OUTSTANDING_POLICY_REQUIRED');
  }

  const effectiveOutstandingPolicy = normalizeOutstandingPolicy(
    input.outstandingPolicy,
    unpaidBalance,
    input.paymentMethod
  );
  const paymentTypeCodeForOrder = getPaymentTypeFromOutstandingPolicy(
    effectiveOutstandingPolicy
  );

  if (effectiveOutstandingPolicy === 'CREDIT_INVOICE') {
    // Phase 0B (accounting safety, 2026-07-09): exceeding the credit limit is
    // hard-denied for everyone — `input.creditLimitOverride` is deliberately
    // inert. The gate takes no override input by design; see
    // `assertCreditWithinPolicy` and Deferred_Backend_Tasks.md for the future
    // gated re-enable (enablement policy + permission, BOTH required).
    // Check the RECEIVABLE actually created (`unpaidBalance`), NOT the full
    // sale total: the credit limit caps outstanding balance, so any amount paid
    // now (cash/card/gift) reduces exposure. Checking the full total wrongly
    // rejected orders the customer partially paid down to fit their available
    // credit (2026-07-11 fix).
    const creditCheck = await checkCreditLimit(input.customerId, unpaidBalance);
    assertCreditWithinPolicy(creditCheck);
  }

  if (!Number.isFinite(amountToCharge) || amountToCharge < 0)
    throw new Error('AMOUNT_OUT_OF_RANGE');
  if (hasImmediatePayment && amountToCharge <= 0)
    throw new Error('AMOUNT_OUT_OF_RANGE');

  if (paymentLegs.length > 1) {
    // Split validation: sum legs via sumMoney so 33.333 + 33.333 + 33.334 = 100.000 exactly.
    const legSum = sumMoney(paymentLegs.map((l) => l.amount)).toNumber();
    const expectedLegSum = input.amountToCharge ?? amountToCharge;
    if (Math.abs(legSum - expectedLegSum) > TOLERANCE)
      throw new Error('SPLIT_AMOUNT_MISMATCH');
  }

  if (paymentLegs.length > 1 && hasDeferredLeg)
    throw new Error('DEFERRED_LEG_NOT_ALONE');

  if (isDeferredOnly && input.outstandingPolicy === 'NONE') {
    throw new Error('OUTSTANDING_POLICY_REQUIRED');
  }

  for (const leg of paymentLegs) {
    if (leg.method === PAYMENT_METHODS.CHECK && !leg.checkNumber?.trim())
      throw new Error('CHECK_NUMBER_REQUIRED');
  }

  // ── 3. Resolve payment method config + build + validate settlement plan ─────────
  // Must happen BEFORE tx1 so infrastructure errors (drawer closed, gateway missing,
  // payment method not configured) abort before any DB writes are committed.
  const methodCodes = [...new Set(paymentLegs.map((l) => l.method))];
  const methodRows = await listEffectivePaymentMethodConfigs({
    tenantId,
    branchId,
    methodCodes,
  });

  const settlementLegs: ResolvedSettlementLeg[] = paymentLegs.map((leg) => {
    const row = methodRows.find((r) => {
      if (r.payment_method_code !== leg.method) return false;
      if (leg.method !== PAYMENT_METHODS.PAYMENT_GATEWAY) return true;
      return (r.gateway_code ?? null) === (leg.gateway_code ?? null);
    });
    if (!row) throw new Error(`Payment method config not found for code: ${leg.method}`);

    const settlementOption: SettlementOption = {
      id:                    row.id,
      paymentMethodCode:     row.payment_method_code,
      paymentNature:         row.payment_nature as SettlementOption['paymentNature'],
      gatewayCode:           row.gateway_code,
      displayName:           row.display_name,
      displayName2:          row.display_name2,
      settlementTypeCode:    row.settlement_type_code as SettlementOption['settlementTypeCode'],
      creditApplicationType: row.credit_application_type as SettlementOption['creditApplicationType'],
      requiresCashDrawer:    row.requires_cash_drawer,
      requiresTerminal:      row.requires_terminal,
      supportsOverpayment:   row.supports_overpayment,
      supportsChangeReturn:  row.supports_change_return,
      minAmount:             row.min_amount,
      maxAmount:             row.max_amount,
      minOrderAmount:        row.min_order_amount,
      maxOrderAmount:        row.max_order_amount,
      isPlatformDisabled:    row.is_platform_disabled,
      isGloballyDisabled:    row.is_globally_disabled,
      defaultCreationStatus: row.default_creation_status ?? 'PENDING',
      allowStatusOverride:   row.allow_status_override ?? false,
      requiresReference:     row.requires_reference ?? false,
      isUserIdRequired:      row.is_user_id_required ?? false,
      allowedInPos:          row.allowed_in_pos ?? true,
    };

    return {
      settlementOption,
      amount:           leg.amount,
      cashTendered:     leg.cashTendered,
      reference:        leg.bank_reference ?? leg.gateway_reference,
      terminalId:       leg.terminalId ?? undefined,
      creditReferenceId: leg.creditReferenceId ?? undefined,
      // BVM Phase 6 Sub-item 6: forward the explicit per-leg payment status.
      paymentStatus:    leg.paymentStatus,
    };
  });

  // Phase 3 (BVM Wiring) — gift-card-by-id as ORDER_CREDIT_APPLICATION voucher line.
  //
  // Why: pre-Phase-3, gift-card-by-id was debited at tx1 directly via
  // `redeemGiftCardTx`, with no voucher backlink (voucher hadn't been created
  // yet). Now we synthesize a CREDIT_APPLICATION settlement leg here so the
  // planner classifies it like wallet/advance/credit-note/loyalty, and the
  // existing tx2 voucher loop produces the ORDER_CREDIT_APPLICATION line +
  // calls applyStoredValueDebitTx with voucherId/voucherLineId populated.
  //
  // The synthetic leg is added ONLY to `settlementLegs` — NOT `paymentLegs` —
  // so it doesn't leak into `amountToCharge` (which sums real-payment legs).
  // The planner zips `paymentLegs[i]` defensively (optional chains on every
  // field), so the undefined orig leg at this index is safe for the
  // CREDIT_APPLICATION branch which only reads `leg.creditReferenceId`.
  if (input.giftCardId && serverTotals.giftCardApplied > 0) {
    const gcMethodRows = await listEffectivePaymentMethodConfigs({
      tenantId,
      branchId,
      methodCodes: ['GIFT_CARD'],
    });
    const row = gcMethodRows[0];
    if (!row || row.credit_application_type !== CREDIT_APPLICATION_TYPES.GIFT_CARD) {
      throw new Error('GIFT_CARD_PAYMENT_METHOD_NOT_CONFIGURED');
    }

    const gcOption: SettlementOption = {
      id:                    row.id,
      paymentMethodCode:     row.payment_method_code,
      paymentNature:         row.payment_nature as SettlementOption['paymentNature'],
      gatewayCode:           row.gateway_code,
      displayName:           row.display_name,
      displayName2:          row.display_name2,
      settlementTypeCode:    row.settlement_type_code as SettlementOption['settlementTypeCode'],
      creditApplicationType: row.credit_application_type as SettlementOption['creditApplicationType'],
      requiresCashDrawer:    row.requires_cash_drawer,
      requiresTerminal:      row.requires_terminal,
      supportsOverpayment:   row.supports_overpayment,
      supportsChangeReturn:  row.supports_change_return,
      minAmount:             row.min_amount,
      maxAmount:             row.max_amount,
      minOrderAmount:        row.min_order_amount,
      maxOrderAmount:        row.max_order_amount,
      isPlatformDisabled:    row.is_platform_disabled,
      isGloballyDisabled:    row.is_globally_disabled,
      defaultCreationStatus: row.default_creation_status ?? 'PENDING',
      allowStatusOverride:   row.allow_status_override ?? false,
      requiresReference:     row.requires_reference ?? false,
      isUserIdRequired:      row.is_user_id_required ?? false,
      allowedInPos:          row.allowed_in_pos ?? true,
    };

    settlementLegs.push({
      settlementOption:  gcOption,
      amount:            serverTotals.giftCardApplied,
      cashTendered:      undefined,
      reference:         undefined,
      terminalId:        undefined,
      creditReferenceId: input.giftCardId,
    });
  }

  // Respect an explicitly chosen session first; only auto-resolve when the
  // checkout payload omitted it and there is exactly one OPEN session in scope.
  const cashDrawerSessionId = settlementLegs.some(
    ({ settlementOption }) => settlementOption.requiresCashDrawer
  )
    ? await resolveCashDrawerSessionId(
        tenantId,
        branchId,
        input.cashDrawerSessionId ?? undefined
      )
    : undefined;

  // orderId placeholder — plan is built before the atomic submit transaction;
  // voucher lines use the created orderId inside that transaction.
  const plan = buildSettlementPlan(
    '',
    serverSaleTotal,
    serverTotals.currencyCode,
    settlementLegs,
    paymentLegs,
    paymentTypeCodeForOrder,
    cashDrawerSessionId
  );

  await validateSettlementPlan(plan, tenantId);

  await validateOverpaymentResolution(
    plan,
    input.overpaymentResolution ?? input.overpaymentDisposition,
    { paymentLegs, customerId: input.customerId ?? null, tenantId }
  );

  const warnings: string[] = [];
  for (const leg of plan.realPaymentLegs) {
    if (leg.resolvedPaymentStatus === 'PENDING')    warnings.push(`${leg.paymentMethodCode}_PENDING_CONFIRMATION`);
    if (leg.resolvedPaymentStatus === 'PROCESSING') warnings.push('GATEWAY_PAYMENT_PROCESSING');
  }

  // ── 4. tx1 — create order + invoice + promo/gift (idempotency-unaware) ────────
  // All pre-flight checks above passed — safe to commit order rows now.
  const createOrderParams = {
    tenantId,
    userId,
    userName,
    customerId:   input.customerId,
    branchId,
    orderTypeId:  input.orderTypeId,
    items: input.items.map((i) => ({
      ...i,
      productName:  i.productName ?? null,
      productName2: i.productName2 ?? null,
    })),
    isQuickDrop:       input.isQuickDrop,
    quickDropQuantity: input.quickDropQuantity,
    express:           input.express,
    customerNotes:     input.customerNotes,
    paymentNotes:      input.paymentNotes,
    readyByAt:         input.readyByAt,
    paymentMethod:     input.paymentMethod,
    idempotencyKey:    input.idempotencyKey,
    /** B18 — order-level preferences; written as prefs_level=ORDER rows + PREFERENCE charge facts. */
    orderServicePrefs: input.orderServicePrefs,
    totals: {
      subtotal:  serverTotals.subtotal,
      discount:  serverTotals.manualDiscount + serverTotals.autoRuleDiscount + serverTotals.promoDiscount,
      tax:       serverTotals.additionalTaxAmount ?? 0,
      total:     serverSaleTotal,
      vatRate:   serverTotals.vatTaxPercent,
      vatAmount: serverTotals.vatValue,
      // Only a single CUSTOM profile line maps to one unambiguous rate; with
      // none (or several stacked) there is no single rate to report.
      taxRate:   serverTotals.taxBreakdown.filter((line) => line.taxType === TAX_TYPES.CUSTOM).length === 1
        ? serverTotals.taxBreakdown.find((line) => line.taxType === TAX_TYPES.CUSTOM)?.rate
        : undefined,
      roundingAdjustment: serverTotals.roundingAdjustmentAmount,
      chargesTotal: serverTotals.chargesTotal,
    },
    discountRate:           input.percentDiscount ?? 0,
    promoCodeId:            input.promoCodeId,
    giftCardId:             input.giftCardId,
    promoDiscountAmount:    serverTotals.promoDiscount,
    giftCardDiscountAmount: serverTotals.giftCardApplied,
    paymentTypeCode:        paymentTypeCodeForOrder ?? getPaymentTypeFromMethod(input.paymentMethod),
    currencyCode:           serverTotals.currencyCode,
    // Preserve the validated operator-selected channel for reporting and downstream integration routing.
    orderSourceCode:        input.orderSourceCode,
    useOldWfCodeOrNew:      false,
    stockDeductionAudit: {
      referenceType: 'ORDER',
      userId,
      userName,
      userAgent: requestAudit.userAgent,
      userIp:    requestAudit.userIp,
      reason:    'Order sale deduction',
    },
    ...(input.customerMobile   != null && { customerMobile:   input.customerMobile }),
    ...(input.customerEmail    != null && input.customerEmail !== '' && { customerEmail: input.customerEmail }),
    ...(input.customerName     != null && { customerName:     input.customerName }),
    ...(input.isDefaultCustomer != null && { isDefaultCustomer: input.isDefaultCustomer }),
    ...(input.customerDetails  != null && { customerDetails:  input.customerDetails }),
    ...(input.b2bContractId    != null && { b2bContractId:    input.b2bContractId }),
    ...(input.costCenterCode   != null && input.costCenterCode !== '' && { costCenterCode: input.costCenterCode }),
    ...(input.poNumber         != null && input.poNumber !== '' && { poNumber: input.poNumber }),
    // creditLimitOverrideBy/At stamping removed with Phase 0B: the client
    // override flag is inert, so nothing is ever overridden. The gated path
    // (Deferred_Backend_Tasks.md) reintroduces the stamp when override returns.
  };

  // Gift-card redemption is stored-value settlement, not a pricing discount.
  // `serverSaleTotal` is the full sale total after commercial
  // discounts and tax only, while `plan.creditAppliedAmount` covers every
  // settlement credit leg (gift-card, wallet, advance, customer credit,
  // loyalty). `correctedOutstanding` is the post-settlement receivable. Used by:
  //  (a) the `shouldCreateArInvoice` zero-outstanding gate
  //  (b) the AR writer's `expected_total_amount` input
  //  (c) `breakdown.outstanding` snapshot persisted by settleOrder
  const correctedOutstanding = Math.max(
    0,
    serverSaleTotal - plan.realPaymentAmount - plan.creditAppliedAmount
  );

  // ADR_ar_invoice_is_receivable_only.md — `org_invoice_mst` rows represent
  // AR receivables only. Fully-paid cash/card/gateway orders and PAY_ON_COLLECTION
  // orders do NOT produce an AR invoice row at submit time. CREDIT_INVOICE / B2B
  // orders DO. The voucher receipt print serves as the cash-sale fiscal artifact
  // (Tax Documents Module replaces this dual role in a future feature).
  //
  // ADR_no_ar_invoice_when_zero_outstanding.md (Phase 3 Round 2):
  // also require a non-zero receivable. A CREDIT_INVOICE order whose cash +
  // credit-application legs fully cover the sale produces ONLY a voucher.
  const shouldCreateArInvoice =
    effectiveOutstandingPolicy === 'CREDIT_INVOICE'
    && correctedOutstanding > TOLERANCE;

  const discountTotal = serverTotals.manualDiscount + serverTotals.autoRuleDiscount + serverTotals.promoDiscount;
  // No tax profile configured: the TENANT_VAT_RATE fallback is the only tax
  // line possible here — `additionalTaxAmount` is derived from CUSTOM *profile*
  // lines, which by definition do not exist when taxBreakdown is empty.
  const taxLines: TaxLineItem[] = serverTotals.taxBreakdown.length > 0
    ? serverTotals.taxBreakdown
    : serverTotals.vatValue > 0
      ? [{
          taxType:    TAX_TYPES.VAT,
          label:      'VAT',
          label2:     'ضريبة القيمة المضافة',
          rate:       serverTotals.vatTaxPercent,
          isCompound: false,
          baseAmount: serverTotals.afterDiscounts,
          taxAmount:  serverTotals.vatValue,
        }]
      : [];
  const taxTotal = taxLines.reduce((sum, line) => sum + line.taxAmount, 0);

  const breakdown: FinancialBreakdownSnapshot = {
    subtotal:         serverTotals.subtotal,
    chargesTotal:     0,
    grossTotal:       serverTotals.subtotal,
    discountTotal,
    netBeforeTax:     serverTotals.afterDiscounts,
    taxBreakdown:     taxLines,
    taxTotal,
    grandTotal:       serverSaleTotal,
    // creditsTotal is informational: total balance debited via voucher
    // CREDIT_APPLICATION lines (gift-card + wallet + advance + cn + loyalty).
    creditsTotal:     plan.creditAppliedAmount,
    // netReceivable: full sale total minus settlement-time credits.
    netReceivable:    Math.max(0, serverSaleTotal - plan.creditAppliedAmount),
    paymentLegsTotal: amountToCharge,
    changeReturned:   0,
    outstanding:      correctedOutstanding,
    currencyCode:     serverTotals.currencyCode,
    decimalPlaces:    serverTotals.decimalPlaces,
  };

  const financialDiscountLines: FinancialDiscountLineInput[] = serverTotals.discountLines.map((d) => ({
    sourceType:     d.sourceType,
    sourceId:       d.sourceId ?? null,
    sourceName:     d.sourceName,
    sourceName2:    d.sourceName2 ?? null,
    discountType:   d.discountType,
    discountRate:   d.discountRate ?? null,
    discountAmount: d.discountAmount,
  }));

  const result = await withTenantContext(tenantId, async () =>
    prisma.$transaction(async (tx) => {
      const orderResult = await OrderService.createOrderInTransaction(tx, createOrderParams);
      if (!orderResult.success || !orderResult.order)
        throw new Error(orderResult.error ?? 'Order creation failed');

      const { id: orderId, orderNo, currentStatus } = orderResult.order;

      let invoiceId: string | null = null;
      if (shouldCreateArInvoice) {
        // Phase 3 (BVM Wiring): canonical AR writer replaces the deprecated
        // `createInvoice` adapter. `issueImmediately: true` mirrors the legacy
        // OPEN-with-ledger-debit semantics atomically inside this same tx.
        // The `${orderId}_ar` idempotency key collapses replays onto the same
        // invoice row via `withIdempotency` (24h TTL).
        // `expected_total_amount = correctedOutstanding` sizes the invoice to
        // the post-settlement receivable (full sale total minus real payments
        // minus stored-value / credit-application legs).
        const invoiceDetail = await createArInvoiceFromOrders(
          {
            order_ids:                [orderId],
            customer_id:              input.customerId,
            currency_code:            serverTotals.currencyCode,
            gift_card_applied_amount: serverTotals.giftCardApplied,
            expected_total_amount:    correctedOutstanding,
            issueImmediately:         true,
            idempotency_key:          `${orderId}_ar`,
            allocation_policy:        'REMAINING_ONLY',
          },
          { tenantId, userId },
          tx,
        );
        invoiceId = invoiceDetail.invoice.id;
        // No reverse backlink on org_orders_mst — the link is unidirectional
        // via org_invoice_mst.order_id (set by createArInvoiceFromOrders at
        // the invoice header). `getInvoicesForOrder(orderId)` queries that.
      }

      if (input.promoCodeId && serverTotals.promoDiscount > 0) {
        await applyPromoCodeTx(tx, {
          promoCodeId:       input.promoCodeId,
          orderId,
          invoiceId:         invoiceId ?? undefined,
          tenantOrgId:       tenantId,
          customerId:        input.customerId ?? undefined,
          discountAmount:    serverTotals.promoDiscount,
          orderTotalBefore:  serverTotals.afterDiscounts + serverTotals.promoDiscount,
          appliedBy:         userId,
        });
      }

      // Phase 3 (BVM Wiring): gift-card debit is synthesized as an
      // ORDER_CREDIT_APPLICATION leg above the buildSettlementPlan call. The
      // voucher loop produces the voucher line + `applyStoredValueDebitTx`
      // debit in the same submit transaction, and the resulting ledger row carries
      // `fin_voucher_id` + `fin_voucher_trx_line_id` backlinks (migration
      // 0329 FKs). No tx1 gift-card debit remains.
      //
      // Legacy `input.giftCardNumber` (string-only) path: not in the current
      // submit-order request schema; if reintroduced, add a `findFirst` on
      // org_gift_cards_mst to resolve to `giftCardId` BEFORE the Step 4
      // synthesis block above (not here).

      // ── 5. Voucher creation + lines + stored-value debits + post & wire ──────
      //
      // The voucher flow intentionally stays inside this same submit-order
      // transaction. If wiring or stored-value redemption fails, the order row
      // created above rolls back with it instead of leaving a user-visible order
      // without finance facts.
      let voucherPostResult: PostAndWireResult | null = null;
      const overpaymentResolution =
        input.overpaymentResolution ?? input.overpaymentDisposition;

      if (plan.shouldCreateReceiptVoucher) {
        const voucher = await createBizVoucher(
          tenantId,
          {
            voucher_type:    VOUCHER_TYPE.RECEIPT,
            direction:       'IN',
            party_type:      'CUSTOMER',
            customer_id:     input.customerId ?? undefined,
            order_id:        orderId,
            source_module:   'ORDERS',
            source_ref_type: 'ORDER',
            source_ref_id:   orderId,
            currency_code:   serverTotals.currencyCode,
            total_amount:    plan.immediateSettlementAmount,
            branch_id:       branchId,
            // P3 Fix A (B6 RESUME doc): sub-keys are prefixed with
            // orderId so a fresh retry order produces fresh
            // sub-keys (no cross-order leak via the unique constraint).
            idempotency_key: `${orderId}_vch`,
          },
          userId,
          tx,
        );

        if (input.posSessionId) {
          await assertOpenPosSessionForFinanceTx(tx, {
            tenantId,
            userId,
            posSessionId: input.posSessionId,
            branchId,
          });
        }

        // 5.1 Real-payment lines (cash, card, gateway, check, bank transfer)
        for (const leg of plan.realPaymentLegs) {
          const changeReturned = resolveVoucherCashChangeReturned(
            leg,
            paymentLegs,
            overpaymentResolution ?? undefined
          );
          await addVoucherLine(
            tenantId,
            voucher.id,
            {
              line_type:              LINE_TYPE.RECEIPT,
              line_role:              LINE_ROLE.ORDER_PAYMENT,
              direction:              'IN',
              target_type:            'ORDER',
              target_id:              orderId,
              order_id:               orderId,
              customer_id:            input.customerId ?? undefined,
              branch_id:              branchId,
              payment_method_code:    leg.paymentMethodCode,
              payment_status:         leg.resolvedPaymentStatus,
              org_payment_method_id:  leg.orgPaymentMethodId,
              amount:                 leg.amount,
              currency_code:          leg.currencyCode,
              cash_drawer_session_id: leg.cashDrawerSessionId,
              tendered_amount:        leg.tenderedAmount,
              ...(changeReturned !== undefined && { change_returned_amount: changeReturned }),
              gateway_code:           leg.gatewayCode,
              gateway_transaction_id: leg.gatewayTransactionId,
              gateway_reference:      leg.gatewayReference,
              bank_reference:         leg.bankReference,
              check_number:           leg.checkNumber,
              check_bank:             leg.checkBank,
              check_date:             leg.checkDate,
              payment_terminal_id:    leg.terminalId,
              pos_session_id:         input.posSessionId,
              card_brand_code:        leg.cardBrandCode,
              card_last4:             leg.cardLast4,
              auth_code:              leg.authCode,
              idempotency_key:        `${orderId}_vl_rp_${leg.legIndex}`,
            },
            userId,
            undefined,
            tx,
          );

          await autoLinkDrawerTx(tx, {
            tenantId,
            userId,
            posSessionId: input.posSessionId,
            branchId,
            cashDrawerSessionId: leg.cashDrawerSessionId,
            idempotencyKey: `${orderId}_pos_link_${leg.legIndex}`,
            sourceChannel: 'submit_order',
          });
        }

        // 5.2 Credit-application legs: voucher line + matching stored-value
        // debit. Iteration order follows STORED_VALUE_LOCK_ORDER (planner
        // sort) so concurrent submits take row locks in the same sequence.
        for (const leg of plan.creditApplicationLegs) {
          const line = await addVoucherLine(
            tenantId,
            voucher.id,
            {
              line_type:               LINE_TYPE.CREDIT_APPLICATION,
              line_role:               LINE_ROLE.ORDER_CREDIT_APPLICATION,
              direction:               'NEUTRAL',
              target_type:             'ORDER',
              target_id:               orderId,
              order_id:                orderId,
              customer_id:             input.customerId ?? undefined,
              branch_id:               branchId,
              amount:                  leg.amount,
              currency_code:           leg.currencyCode,
              credit_application_type: leg.creditType,
              pos_session_id:          input.posSessionId,
              idempotency_key:         `${orderId}_vl_ca_${leg.legIndex}`,
            },
            userId,
            undefined,
            tx,
          );

          if (!input.customerId) {
            // Credit-application legs require a customer. The planner already
            // validates this upstream, but the type system can't see that —
            // throw rather than passing `undefined` into the dispatcher.
            throw new Error('CUSTOMER_ID_REQUIRED_FOR_CREDIT_APPLICATION');
          }

          await applyStoredValueDebitTx(tx, {
            tenantId,
            orderId,
            customerId:        input.customerId,
            creditType:        leg.creditType,
            amount:             leg.amount,
            creditReferenceId: leg.creditReferenceId,
            appliedBy:         userId,
            currencyCode:      leg.currencyCode,
            idempotencyKey:    `${orderId}_sv_${STORED_VALUE_SUB_IDEMPOTENCY_CODE[leg.creditType]}_${leg.legIndex}`,
            voucherId:         voucher.id,
            voucherLineId:     line.id,
            skipCreditAppRow:  true,
          });
        }

        // 5.3 Post + wire — joins the same tx so a wiring failure rolls back
        // the order, voucher, lines, and every stored-value debit atomically.
        voucherPostResult = await postAndWireBizVoucher(
          tenantId,
          voucher.id,
          userId,
          `${orderId}_vch_post`,
          tx,
        );
      }

      if (overpaymentResolution && overpaymentResolution.excessAmount > TOLERANCE) {
        const dispositionOnly = resolutionIncludesAllocation(overpaymentResolution)
          ? getDispositionLinesExcludingAllocation(overpaymentResolution)
          : overpaymentResolution;

        if (dispositionOnly.lines.length > 0) {
          await executeOverpaymentDispositionTx({
            tx,
            tenantId,
            userId,
            orderId,
            branchId: branchId ?? null,
            customerId: input.customerId ?? null,
            currencyCode: serverTotals.currencyCode,
            voucherId: plan.shouldCreateReceiptVoucher ? voucherPostResult?.voucherId ?? null : null,
            resolution: dispositionOnly,
            idempotencyKey: input.idempotencyKey,
          });
        }

        const previewId = extractAllocationPreviewId(overpaymentResolution);
        if (previewId && input.customerId) {
          const primaryMethod =
            paymentLegs?.[0]?.method ?? plan.realPaymentLegs[0]?.paymentMethodCode ?? 'CASH';
          await executeAllocationPreviewTx({
            tx,
            tenantId,
            userId,
            customerId: input.customerId,
            sourceOrderId: orderId,
            currencyCode: serverTotals.currencyCode,
            voucherId: plan.shouldCreateReceiptVoucher ? voucherPostResult?.voucherId ?? null : null,
            previewId,
            idempotencyKey: input.idempotencyKey,
            paymentMethodCode: primaryMethod,
          });
        }
      }

      // ── 6. settleOrderTx — same transaction as order + voucher wiring ───────
      // wiringMode tells settlement to skip payment fact-row direct writes
      // because BVM wiring already wrote those rows earlier in this transaction.
      await settleOrderTx(tx, {
        orderId,
        tenantId,
        breakdown,
        chargeLines:         [],
        taxLines,
        discountLines:       financialDiscountLines,
        settlementLegs,
        cashDrawerSessionId,
        settledBy:           userId,
        posSessionId:        input.posSessionId,
        wiringMode:          plan.shouldCreateReceiptVoucher,
      });

      // B14 — tax-document issuance trigger. Non-blocking by design: a new
      // fiscal side-effect must never be able to take down order submission
      // itself (D007 failure-coupling — same posture as the ERP-Lite auto-
      // post dispatch elsewhere in this flow). No-ops for every tenant today
      // (dormant: no org_tax_doc_triggers_cfg rows are enabled anywhere yet).
      try {
        await maybeIssueTaxDocumentTx(tx, {
          tenantId,
          orderId,
          branchId: branchId ?? null,
          triggerEvent: TAX_DOCUMENT_TRIGGER_EVENTS.ON_ORDER_SUBMIT,
          orderStatus: currentStatus,
          issuedBy: userId,
        });
      } catch (taxDocError) {
        logger.error('[submitOrder] Tax-document issuance failed (non-blocking)', taxDocError as Error, {
          feature: 'orders',
          action: 'submit_order_tax_document',
          orderId,
          tenantId,
        });
      }

      return { orderId, orderNo, invoiceId, currentStatus, voucherPostResult };
    }, { maxWait: 10000, timeout: 30000 })
  );
  const voucherPostResult = result.voucherPostResult;

  // ── 8. Legacy AR payment tracking — REMOVED in Phase 3 Round 2 ───────────────
  //
  // Why removed: with `expected_total_amount = plan.outstandingAmount` the AR
  // invoice is sized to the receivable AFTER cash + every credit-application
  // leg has been recorded on the voucher. There is nothing left to allocate
  // against the invoice at submit time — the cash and gift-card / wallet /
  // advance / etc. are already accounted for by the voucher (RV-*) and its
  // trx lines. Future B2B payments on this invoice will allocate via the
  // existing AR collection flow (POST /api/v1/ar/invoices/[id]/payments).
  //
  // The previous block called `recordPaymentTransaction` with
  // `skipReceiptVoucher: true` which left `the legacy payments ledger.voucher_id`
  // NULL and violated `chk_payments_voucher_required`. It also duplicated
  // payment facts already captured by BVM wiring's voucher in tx2.
  //
  // ADR_ar_invoice_is_receivable_only.md remains authoritative on the
  // receivable-only semantic.

  // ── 9. Build response ─────────────────────────────────────────────────────────
  const finalOrder = await withTenantContext(tenantId, () =>
    prisma.org_orders_mst.findFirstOrThrow({
      where:  { id: result.orderId, tenant_org_id: tenantId },
      select: {
        id: true, order_no: true, current_status: true,
        total_amount: true, total_paid_amount: true,
        total_credit_applied_amount: true, outstanding_amount: true,
        payment_status: true, payment_type_code: true,
      },
    })
  );

  const linkedEffects = voucherPostResult
    ? await withTenantContext(tenantId, () =>
        getVoucherLinkedEffects(tenantId, voucherPostResult!.voucherId)
      )
    : null;

  const wiringLinesTotal = voucherPostResult
    ? (voucherPostResult.wiring.linesWired ?? 0) + (voucherPostResult.wiring.linesSkipped ?? 0)
    : 0;

  return {
    order: {
      id:                       finalOrder.id,
      orderNo:                  finalOrder.order_no,
      currentStatus:            finalOrder.current_status,
      totalAmount:              String(finalOrder.total_amount ?? 0),
      totalPaidAmount:          String(finalOrder.total_paid_amount ?? 0),
      totalCreditAppliedAmount: String(finalOrder.total_credit_applied_amount ?? 0),
      outstandingAmount:        String(finalOrder.outstanding_amount ?? 0),
      paymentStatus:            finalOrder.payment_status ?? '',
      paymentTypeCode:          finalOrder.payment_type_code ?? '',
    },
    ...(voucherPostResult && {
      voucher: {
        id:           voucherPostResult.voucherId,
        voucherNo:    voucherPostResult.voucher_no,
        status:       voucherPostResult.voucher_status,
        wiringStatus: (voucherPostResult.wiring.linesWired ?? 0) === wiringLinesTotal
          ? 'WIRED' as const
          : 'PARTIALLY_WIRED' as const,
      },
    }),
    effects: {
      orderPayments: (linkedEffects?.orderPayments ?? []).map((p) => ({
        id:                p.id,
        amount:            p.amount,
        paymentMethodCode: p.payment_method_code ?? '',
        paymentStatus:     p.payment_status ?? '',
      })),
      creditApplications: (linkedEffects?.creditApplications ?? []).map((c) => ({
        id:         c.id,
        amount:     c.amount,
        creditType: c.credit_type ?? '',
      })),
      cashMovements: (linkedEffects?.cashDrawerMovements ?? []).map((m) => ({
        id:        m.id,
        amount:    m.amount,
        sessionId: m.session_id,
      })),
    },
    warnings,
  };
}
