/**
 * Payment Form Schema
 * Zod validation schemas for payment processing
 */

import { z } from 'zod';
import { PAYMENT_METHODS } from '@/lib/constants/order-types';
import { NEW_ORDER_PROMO_GIFT_DISABLED } from '@/lib/constants/order-checkout-flags';
import { OUTSTANDING_POLICIES, outstandingPolicySchema } from '@/lib/validations/new-order-payment-schemas';

/**
 * Payment method schema
 * Includes all payment methods used in the payment modal
 */
// GIFT_CARD and PROMO_CODE are kept as string literals here because this legacy modal
// is being replaced by the multi-leg checkout in Phase 9. They are no longer in
// PAYMENT_METHODS (GIFT_CARD = credit application, PROMO_CODE = discount source only).
const paymentMethodSchema = z.enum([
  PAYMENT_METHODS.CASH,
  PAYMENT_METHODS.CARD,
  PAYMENT_METHODS.CHECK,
  'GIFT_CARD',
  'PROMO_CODE',
  PAYMENT_METHODS.PAY_ON_COLLECTION,
  PAYMENT_METHODS.PAY_ON_DELIVERY,
  PAYMENT_METHODS.BANK_TRANSFER,
  PAYMENT_METHODS.MOBILE_PAYMENT,
  PAYMENT_METHODS.PAYMENT_GATEWAY,
  PAYMENT_METHODS.INVOICE,
]);

/**
 * Payment form schema
 */
// Helper to normalize empty strings to undefined
const emptyStringToUndefined = z.preprocess(
  (val) => (val === '' || (typeof val === 'string' && val.trim() === '') ? undefined : val),
  z.string().optional()
).optional();

const paymentFormBaseSchema = z.object({
  paymentMethod: paymentMethodSchema,
  checkNumber: z.string().optional(),
  checkBank: z.string().optional(),
  checkDate: z.string().optional(), // ISO date string from input[type="date"]
  percentDiscount: z.number().min(0).max(100).default(0),
  amountDiscount: z.number().nonnegative().default(0),
  promoCode: emptyStringToUndefined,
  promoCodeId: z.string().uuid().optional().or(z.literal('')),
  promoDiscount: z.number().nonnegative().optional(),
  giftCardNumber: emptyStringToUndefined,
  giftCardAmount: z.number().nonnegative().optional(),
  giftCardId: z.string().uuid().optional().or(z.literal('')),
  payAllOrders: z.boolean().default(false),
  paymentNotes: z.string().max(1000).optional(),
  outstandingPolicy: outstandingPolicySchema.default(OUTSTANDING_POLICIES.PAY_ON_COLLECTION),
  /** B2B: Contract, cost center, PO (when customer is B2B) */
  b2bContractId: z.string().uuid().optional().or(z.literal('')),
  costCenterCode: z.string().max(50).optional().or(z.literal('')),
  poNumber: z.string().max(100).optional().or(z.literal('')),
});

/**
 * Base schema (no subtotal-dependent validation).
 * Use getPaymentFormSchema(subtotal) when subtotal is available for discount validation.
 */
export const paymentFormSchema = paymentFormBaseSchema
  .refine(
    (data) => {
      if (data.paymentMethod === PAYMENT_METHODS.CHECK) {
        return !!data.checkNumber && data.checkNumber.trim().length > 0;
      }
      return true;
    },
    {
      message: 'Check number is required when payment method is check',
      path: ['checkNumber'],
    }
  )
  .refine(
    (data) => {
      // Promo on new order: disabled until gifts/promotions ship (order-checkout-flags.ts)
      if (NEW_ORDER_PROMO_GIFT_DISABLED) return true;
      const hasPromoCode = data.promoCode && data.promoCode.trim().length > 0;
      if (hasPromoCode && !data.promoCodeId) {
        return false;
      }
      return true;
    },
    {
      message: 'Promo code ID is required when promo code is provided',
      path: ['promoCodeId'],
    }
  )
  .refine(
    (data) => {
      if (NEW_ORDER_PROMO_GIFT_DISABLED) return true;
      const hasGiftCard = data.giftCardNumber && data.giftCardNumber.trim().length > 0;
      if (hasGiftCard && !data.giftCardAmount) {
        return false;
      }
      return true;
    },
    {
      message: 'Gift card amount is required when gift card number is provided',
      path: ['giftCardAmount'],
    }
  );

/**
 * Payment form schema with discount validation against subtotal.
 * Use this when subtotal is available (e.g. in payment modal).
 * @param subtotal Order subtotal (before discount)
 * @param message Optional i18n message (default: "Discount cannot exceed order total")
 */
export function getPaymentFormSchema(
  subtotal: number,
  message = 'Discount cannot exceed order total'
) {
  return paymentFormSchema.refine(
    (data) => {
      const effectiveDiscount =
        data.percentDiscount > 0
          ? (subtotal * data.percentDiscount) / 100
          : data.amountDiscount;
      return effectiveDiscount <= Math.max(0, subtotal);
    },
    {
      message,
      path: ['amountDiscount'],
    }
  );
}

/**
 * Type inference for payment form
 */
export type PaymentFormData = z.infer<typeof paymentFormSchema>;

