/**
 * New Order Reducer
 * Handles all state mutations for the new order feature
 */

import type { NewOrderState, NewOrderAction, PreSubmissionPiece } from '../../model/new-order-types';
import { NEW_ORDER_DEFAULT_SOURCE_CODE } from '@/lib/constants/order-sources';
import { ORDER_TYPE_IDS } from '@/lib/constants/order-types';

/**
 * Base line (qty × unit) plus service prefs charge and packing surcharge (catalog extra_price; per line, not × qty).
 * @param item
 * @param item.quantity
 * @param item.pricePerUnit
 * @param item.servicePrefCharge
 * @param item.packingPrefCharge
 */
function itemLineBasePlusPrefCharges(item: {
  quantity: number;
  pricePerUnit: number;
  servicePrefCharge?: number;
  packingPrefCharge?: number;
}): number {
  return (
    item.quantity * item.pricePerUnit +
    (item.servicePrefCharge ?? 0) +
    (item.packingPrefCharge ?? 0)
  );
}

/**
 * Initial state
 */
/**
 * Check if all items are retail (RETAIL_ITEMS)
 * @param items
 */
function isRetailOnlyItems(items: { serviceCategoryCode?: string }[]): boolean {
  return items.length > 0 && items.every((i) => i.serviceCategoryCode === 'RETAIL_ITEMS');
}

export const initialState: NewOrderState = {
  // Customer
  customer: null,
  customerName: '',
  customerMobile: '',
  customerEmail: '',
  customerNameSnapshot: '',
  isDefaultCustomer: false,
  customerSnapshotOverride: null,
  customerNotes: '',
  paymentNotes: '',

  // Order Items
  items: [],

  // B18 — order-level preferences
  orderServicePrefs: [],

  // Order Settings
  branchId: null,
  // Counter entry is the safe staff default; reset restores it rather than carrying context to a new sale.
  orderTypeId: ORDER_TYPE_IDS.POS,
  orderSourceCode: NEW_ORDER_DEFAULT_SOURCE_CODE,
  isQuickDrop: false,
  quickDropQuantity: 0,
  express: false,
  notes: '',
  readyByAt: '',
  bags: 0,

  // UI State
  loading: false,
  createdOrderId: null,
  createdOrderStatus: null,

  // Modal States
  modals: {
    customerPicker: false,
    customerEdit: false,
    payment: false,
    customItem: false,
    photoCapture: false,
    readyBy: false,
    priceOverride: false,
  },
  priceOverrideItemId: null,

  // Data
  categories: [],
  products: [],
  selectedCategory: '',

  // Loading States
  isInitialLoading: true,
  categoriesLoading: true,
  productsLoading: false,

  // Edit Mode State
  isEditMode: false,
  editingOrderId: null,
  editingOrderNo: null,
  originalOrderData: null,
  lockInfo: null,
  expectedUpdatedAt: null,

  // Customer/Order/Item/Pieces Preferences
  selectedPieceId: null,
};

/**
 * Applies draft changes while retaining the explicit creation context until the order resets.
 *
 * @param state - Current in-memory New Order draft.
 * @param action - A validated UI intent, including workflow type or source selection.
 * @returns The next immutable draft state.
 */
export function newOrderReducer(
  state: NewOrderState,
  action: NewOrderAction
): NewOrderState {
  switch (action.type) {
    case 'SET_CUSTOMER': {
      const { customer, customerName, customerMobile, customerEmail, customerNameSnapshot, isDefaultCustomer } =
        action.payload;
      const displayName = customerNameSnapshot ?? customerName;
      return {
        ...state,
        customer,
        customerName: customerName ?? displayName ?? '',
        customerMobile: customerMobile ?? customer?.phone ?? '',
        customerEmail: customerEmail ?? customer?.email ?? '',
        customerNameSnapshot: displayName ?? customer?.displayName ?? customer?.name ?? '',
        isDefaultCustomer: isDefaultCustomer ?? false,
        customerSnapshotOverride: null,
      };
    }

    case 'SET_CUSTOMER_SNAPSHOT_OVERRIDE':
      return {
        ...state,
        customerSnapshotOverride: action.payload,
      };

    case 'SET_BRANCH_ID':
      if (state.branchId === action.payload) {
        return state;
      }
      return {
        ...state,
        branchId: action.payload,
      };

    // These remain independent: fulfillment selects workflow behavior, while source records origin.
    case 'SET_ORDER_TYPE_ID':
      return {
        ...state,
        orderTypeId: action.payload,
      };

    case 'SET_ORDER_SOURCE_CODE':
      return {
        ...state,
        orderSourceCode: action.payload,
      };

    case 'SET_ITEMS': {
      const newItems = action.payload;
      const retailReadyBy =
        isRetailOnlyItems(newItems) && !state.readyByAt
          ? new Date().toISOString()
          : state.readyByAt;
      return {
        ...state,
        items: newItems,
        readyByAt: retailReadyBy,
      };
    }

    case 'ADD_ITEM': {
      const existingItem = state.items.find(
        (item) => item.productId === action.payload.productId
      );

      let newItems: typeof state.items;
      if (existingItem) {
        newItems = state.items.map((item) =>
          item.productId === action.payload.productId
            ? {
                ...item,
                quantity: item.quantity + 1,
                totalPrice: itemLineBasePlusPrefCharges({
                  quantity: item.quantity + 1,
                  pricePerUnit: item.pricePerUnit,
                  servicePrefCharge: item.servicePrefCharge,
                  packingPrefCharge: item.packingPrefCharge,
                }),
                pieces: action.payload.pieces || item.pieces,
              }
            : item
        );
      } else {
        newItems = [...state.items, action.payload];
      }

      const retailReadyBy =
        isRetailOnlyItems(newItems) && !state.readyByAt
          ? new Date().toISOString()
          : state.readyByAt;

      return {
        ...state,
        items: newItems,
        readyByAt: retailReadyBy,
      };
    }

    case 'REMOVE_ITEM':
      return {
        ...state,
        items: state.items.filter((item) => item.productId !== action.payload),
      };

    case 'UPDATE_ITEM_QUANTITY': {
      const { productId, quantity } = action.payload;

      if (quantity === 0) {
        return {
          ...state,
          items: state.items.filter((item) => item.productId !== productId),
        };
      }

      return {
        ...state,
        items: state.items.map((item) => {
          if (item.productId !== productId) {
            return item;
          }

          let pieces: PreSubmissionPiece[] | undefined = item.pieces;

          if (pieces && pieces.length > 0) {
            if (quantity > pieces.length) {
              const toAdd = quantity - pieces.length;
              const lastSeq =
                pieces.length > 0
                  ? Math.max(...pieces.map((piece) => piece.pieceSeq))
                  : 0;
              const newPieces = [...pieces];
              for (let addIndex = 1; addIndex <= toAdd; addIndex += 1) {
                newPieces.push({
                  id: `temp-${item.productId}-${lastSeq + addIndex}`,
                  itemId: item.productId,
                  pieceSeq: lastSeq + addIndex,
                });
              }
              pieces = newPieces;
            } else if (quantity < pieces.length) {
              const trimmed = pieces.slice(0, quantity);
              pieces = trimmed.map((piece, index) => ({
                ...piece,
                pieceSeq: index + 1,
              }));
            }
          }

          return {
            ...item,
            quantity,
            totalPrice: itemLineBasePlusPrefCharges({
              quantity,
              pricePerUnit: item.pricePerUnit,
              servicePrefCharge: item.servicePrefCharge,
              packingPrefCharge: item.packingPrefCharge,
            }),
            pieces,
          };
        }),
      };
    }

    case 'UPDATE_ITEM_PIECES':
      return {
        ...state,
        items: state.items.map((item) => {
          if (item.productId !== action.payload.productId) {
            return item;
          }

          const pieces = action.payload.pieces;
          const quantity =
            pieces && pieces.length > 0 ? pieces.length : item.quantity;

          return {
            ...item,
            pieces,
            quantity,
            totalPrice: itemLineBasePlusPrefCharges({
              quantity,
              pricePerUnit: item.pricePerUnit,
              servicePrefCharge: item.servicePrefCharge,
              packingPrefCharge: item.packingPrefCharge,
            }),
          };
        }),
      };

    case 'UPDATE_ITEM_SERVICE_PREFS': {
      const { productId, servicePrefs, servicePrefCharge } = action.payload;
      return {
        ...state,
        items: state.items.map((item) =>
          item.productId === productId
            ? {
                ...item,
                servicePrefs,
                servicePrefCharge,
                totalPrice: itemLineBasePlusPrefCharges({
                  quantity: item.quantity,
                  pricePerUnit: item.pricePerUnit,
                  servicePrefCharge,
                  packingPrefCharge: item.packingPrefCharge,
                }),
              }
            : item
        ),
      };
    }

    case 'UPDATE_ORDER_SERVICE_PREFS': {
      const { servicePrefs } = action.payload;
      return {
        ...state,
        orderServicePrefs: servicePrefs,
      };
    }

    case 'UPDATE_ITEM_PACKING_PREF': {
      const {
        productId,
        packingPrefCode,
        packingPrefIsOverride,
        packingPrefSource,
        packingCfId,
        packingPrefCharge: packingChargePayload,
      } = action.payload;
      const normalizedCode =
        packingPrefCode != null && String(packingPrefCode).trim() !== ''
          ? String(packingPrefCode).trim()
          : undefined;
      return {
        ...state,
        items: state.items.map((item) => {
          if (item.productId !== productId) return item;
          const nextPk =
            normalizedCode === undefined
              ? undefined
              : Math.max(0, Number(packingChargePayload ?? 0));
          return {
            ...item,
            packingPrefCode: normalizedCode,
            packingPrefIsOverride: packingPrefIsOverride ?? false,
            packingPrefSource: packingPrefSource ?? 'manual',
            ...(normalizedCode
              ? { packingCfId: packingCfId ?? null, packingPrefCharge: nextPk }
              : {
                  packingCfId: undefined,
                  packingPrefCharge: undefined,
                }),
            totalPrice: itemLineBasePlusPrefCharges({
              quantity: item.quantity,
              pricePerUnit: item.pricePerUnit,
              servicePrefCharge: item.servicePrefCharge,
              packingPrefCharge:
                normalizedCode === undefined ? 0 : (nextPk ?? 0),
            }),
          };
        }),
      };
    }

    case 'ADJUST_ITEM_PACKING_PREF_CHARGE': {
      const { productId, packingPrefCharge } = action.payload;
      const pk = Math.max(0, Number(packingPrefCharge ?? 0));
      return {
        ...state,
        items: state.items.map((item) =>
          item.productId === productId
            ? {
                ...item,
                packingPrefCharge: pk,
                totalPrice: itemLineBasePlusPrefCharges({
                  quantity: item.quantity,
                  pricePerUnit: item.pricePerUnit,
                  servicePrefCharge: item.servicePrefCharge,
                  packingPrefCharge: pk,
                }),
              }
            : item
        ),
      };
    }

    case 'UPDATE_ITEM_NOTES':
      return {
        ...state,
        items: state.items.map((item) =>
          item.productId === action.payload.productId
            ? { ...item, notes: action.payload.notes }
            : item
        ),
      };

    case 'UPDATE_ITEM_PRICE_OVERRIDE': {
      const { productId, priceOverride, overrideReason, overrideBy } = action.payload;
      return {
        ...state,
        items: state.items.map((item) => {
          if (item.productId !== productId) {
            return item;
          }
          const effectivePrice = priceOverride !== null ? priceOverride : item.pricePerUnit;
          return {
            ...item,
            priceOverride,
            overrideReason,
            overrideBy,
            pricePerUnit: effectivePrice,
            totalPrice: itemLineBasePlusPrefCharges({
              quantity: item.quantity,
              pricePerUnit: effectivePrice,
              servicePrefCharge: item.servicePrefCharge,
              packingPrefCharge: item.packingPrefCharge,
            }),
          };
        }),
      };
    }

    case 'SET_QUICK_DROP':
      return {
        ...state,
        isQuickDrop: action.payload,
      };

    case 'SET_QUICK_DROP_QUANTITY':
      return {
        ...state,
        quickDropQuantity: action.payload,
      };

    case 'SET_EXPRESS':
      return {
        ...state,
        express: action.payload,
        // Recalculate prices when express changes
        items: state.items.map((item) => {
          const newPricePerUnit =
            action.payload && item.defaultExpressSellPrice
              ? item.defaultExpressSellPrice
              : item.defaultSellPrice || item.pricePerUnit;

          return {
            ...item,
            pricePerUnit: newPricePerUnit,
            totalPrice: itemLineBasePlusPrefCharges({
              quantity: item.quantity,
              pricePerUnit: newPricePerUnit,
              servicePrefCharge: item.servicePrefCharge,
              packingPrefCharge: item.packingPrefCharge,
            }),
          };
        }),
      };

    case 'SET_BAGS':
      return {
        ...state,
        bags: action.payload,
      };

    case 'SET_NOTES':
      return {
        ...state,
        notes: action.payload,
      };

    case 'SET_CUSTOMER_NOTES':
      return {
        ...state,
        customerNotes: action.payload,
      };

    case 'SET_PAYMENT_NOTES':
      return {
        ...state,
        paymentNotes: action.payload,
      };

    case 'SET_READY_BY_AT':
      return {
        ...state,
        readyByAt: action.payload,
      };

    case 'SET_LOADING':
      if (state.loading === action.payload) {
        return state;
      }
      return {
        ...state,
        loading: action.payload,
      };

    case 'SET_CREATED_ORDER':
      return {
        ...state,
        createdOrderId: action.payload.orderId,
        createdOrderStatus: action.payload.status,
      };

    case 'OPEN_MODAL':
      return {
        ...state,
        modals: {
          ...state.modals,
          [action.payload]: true,
        },
      };

    case 'CLOSE_MODAL':
      return {
        ...state,
        modals: {
          ...state.modals,
          [action.payload]: false,
        },
        // Clear price override itemId when closing price override modal
        priceOverrideItemId: action.payload === 'priceOverride' ? null : state.priceOverrideItemId,
      };

    case 'OPEN_PRICE_OVERRIDE_MODAL':
      return {
        ...state,
        modals: {
          ...state.modals,
          priceOverride: true,
        },
        priceOverrideItemId: action.payload,
      };

    case 'SET_CATEGORIES':
      if (state.categories === action.payload) {
        return state;
      }
      return {
        ...state,
        categories: action.payload,
      };

    case 'SET_PRODUCTS':
      if (state.products === action.payload) {
        return state;
      }
      return {
        ...state,
        products: action.payload,
      };

    case 'SET_SELECTED_CATEGORY':
      if (state.selectedCategory === action.payload) {
        return state;
      }
      return {
        ...state,
        selectedCategory: action.payload,
      };

    case 'SET_CATEGORIES_LOADING':
      if (state.categoriesLoading === action.payload) {
        return state;
      }
      return {
        ...state,
        categoriesLoading: action.payload,
      };

    case 'SET_PRODUCTS_LOADING':
      if (state.productsLoading === action.payload) {
        return state;
      }
      return {
        ...state,
        productsLoading: action.payload,
      };

    case 'SET_INITIAL_LOADING':
      if (state.isInitialLoading === action.payload) {
        return state;
      }
      return {
        ...state,
        isInitialLoading: action.payload,
      };

    case 'RESET_ORDER':
      return {
        ...initialState,
        branchId: state.branchId,
        categories: state.categories,
        products: state.products,
        selectedCategory: state.selectedCategory,
        isInitialLoading: false,
        categoriesLoading: false,
        productsLoading: false,
        selectedPieceId: null,
      };

    case 'ENTER_EDIT_MODE':
      return {
        ...state,
        isEditMode: true,
        editingOrderId: action.payload.orderId,
        editingOrderNo: action.payload.orderNo,
      };

    case 'LOAD_ORDER_FOR_EDIT': {
      const {
        orderId,
        orderNo,
        customer,
        customerName,
        customerMobile,
        customerEmail,
        branchId,
        items,
        express,
        notes,
        customerNotes,
        paymentNotes,
        readyByAt,
        originalData,
        expectedUpdatedAt,
      } = action.payload;

      return {
        ...state,
        isEditMode: true,
        editingOrderId: orderId,
        editingOrderNo: orderNo,
        originalOrderData: originalData,
        expectedUpdatedAt,
        // Load order data into form
        customer,
        customerName,
        customerMobile,
        customerEmail,
        customerNameSnapshot: customerName,
        branchId,
        items,
        express,
        notes,
        customerNotes: customerNotes ?? '',
        paymentNotes: paymentNotes ?? '',
        readyByAt,
      };
    }

    case 'EXIT_EDIT_MODE':
      return {
        ...state,
        isEditMode: false,
        editingOrderId: null,
        editingOrderNo: null,
        originalOrderData: null,
        lockInfo: null,
        expectedUpdatedAt: null,
      };

    case 'SET_LOCK_INFO':
      return {
        ...state,
        lockInfo: action.payload,
      };

    case 'UPDATE_ORIGINAL_ORDER_DATA':
      return {
        ...state,
        originalOrderData: action.payload,
      };

    case 'SET_EXPECTED_UPDATED_AT':
      return {
        ...state,
        expectedUpdatedAt: action.payload,
      };

    case 'SET_SELECTED_PIECE':
      return {
        ...state,
        selectedPieceId: action.payload,
      };

    case 'UPDATE_PIECE_CONDITIONS': {
      const { pieceId, conditions } = action.payload;
      return {
        ...state,
        items: state.items.map((item) => {
          const match = pieceId.startsWith(`temp-${item.productId}-`);
          if (!match) return item;
          let pieces = item.pieces;
          if (!pieces || pieces.length === 0) {
            pieces = Array.from({ length: item.quantity }, (_, i) => ({
              id: `temp-${item.productId}-${i + 1}`,
              itemId: item.productId,
              pieceSeq: i + 1,
            }));
          }
          const hasPiece = pieces.some((p) => p.id === pieceId);
          if (!hasPiece) return item;
          return {
            ...item,
            pieces: pieces.map((p) =>
              p.id === pieceId ? { ...p, conditions: [...conditions] } : p
            ),
          };
        }),
      };
    }

    case 'UPDATE_PIECE_COLOR': {
      const { pieceId, color, colorCodes, colorCfIds } = action.payload;
      const resolved =
        colorCodes != null && colorCodes.length > 0
          ? {
              codes: colorCodes,
              cf: colorCodes.map((_, i) => (colorCfIds?.[i] != null ? colorCfIds[i]! : null)),
            }
          : color != null && color !== ''
            ? { codes: [color], cf: [colorCfIds?.[0] != null ? colorCfIds[0]! : null] }
            : { codes: [] as string[], cf: [] as (string | null)[] };
      return {
        ...state,
        items: state.items.map((item) => {
          if (!item.pieces?.some((p) => p.id === pieceId)) return item;
          return {
            ...item,
            pieces: item.pieces.map((p) =>
              p.id === pieceId
                ? {
                    ...p,
                    color: resolved.codes[0],
                    ...(resolved.codes.length > 0
                      ? { colorCodes: resolved.codes, colorCfIds: resolved.cf }
                      : { colorCodes: undefined, colorCfIds: undefined, color: undefined }),
                  }
                : p
            ),
          };
        }),
      };
    }

    default:
      return state;
  }
}

