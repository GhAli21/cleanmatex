/**
 * Order Details Section
 * Tab 2: Detailed view of all items in the current new order
 */

'use client';

import { Fragment, useMemo, useState, useCallback } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Trash2, Minus, Plus, ChevronDown, ChevronUp } from 'lucide-react';
import { useRTL } from '@/lib/hooks/useRTL';
import { useBilingual } from '@/lib/utils/bilingual';
import { useNewOrderStateWithDispatch } from '../hooks/use-new-order-state';
import { useOrderTotals } from '../hooks/use-order-totals';
import { usePreferenceCatalog } from '../hooks/use-preference-catalog';
import { PackingPreferenceSelector } from './preferences/PackingPreferenceSelector';
import { PreferencesTabsSection } from './preferences/PreferencesTabsSection';
import type { PreSubmissionPiece } from '../model/new-order-types';
import { calculateItemTotal } from '@/lib/utils/order-item-helpers';
import { orderItemLinePackingCharge, packingPreferencePriceMap } from '@/lib/utils/order-packing-charges';
import { useTenantCurrency } from '@/lib/context/tenant-currency-context';
import { formatMoneyAmountWithCode } from '@/lib/money/format-money';

const VIRTUALIZED_ITEM_LIMIT = 1000;

interface OrderDetailsSectionProps {
  trackByPiece: boolean;
  /** Tenant currency code (e.g. OMR, SAR) for price display */
  currencyCode?: string;
  /** When true, show packing and service pref selectors per piece (Enterprise) */
  packingPerPieceEnabled?: boolean;
  /** Gate Care Packages (Growth+) */
  bundlesEnabled?: boolean;
  /** Gate Repeat Last Order (Starter+) */
  repeatLastOrderEnabled?: boolean;
  /** Gate Smart Suggestions (Growth+) */
  smartSuggestionsEnabled?: boolean;
  /** Block incompatible prefs (SERVICE_PREF_ENFORCE_COMPATIBILITY) */
  enforcePrefCompatibility?: boolean;
}

/**
 *
 * @param root0
 * @param root0.trackByPiece
 * @param root0.currencyCode
 * @param root0.packingPerPieceEnabled
 * @param root0.bundlesEnabled
 * @param root0.repeatLastOrderEnabled
 * @param root0.smartSuggestionsEnabled
 * @param root0.enforcePrefCompatibility
 */
export function OrderDetailsSection({
  trackByPiece,
  currencyCode = '',
  packingPerPieceEnabled = true, // for testing
  bundlesEnabled = false,
  repeatLastOrderEnabled = true,
  smartSuggestionsEnabled = false,
  enforcePrefCompatibility = false,
}: OrderDetailsSectionProps) {
  const locale = useLocale();
  const { decimalPlaces } = useTenantCurrency();
  const moneyLocale = locale === 'ar' ? 'ar' : 'en';
  const fmtMoney = (amount: number) =>
    formatMoneyAmountWithCode(amount, {
      currencyCode: currencyCode as string,
      decimalPlaces,
      locale: moneyLocale,
    });
  const {
    state,
    updateItemQuantity,
    updateItemNotes,
    updateItemPieces,
    updateItemPackingPref,
    adjustItemPackingCharge,
    removeItem,
  } = useNewOrderStateWithDispatch();
  const { packingPrefs, hasServicePrefs, hasPackingPrefs } =
    usePreferenceCatalog(state.branchId);
  const packingPriceByCode = useMemo(() => packingPreferencePriceMap(packingPrefs), [packingPrefs]);
  const totals = useOrderTotals();
  const isRTL = useRTL();
  const tNewOrder = useTranslations('newOrder');
  const tItems = useTranslations('newOrder.itemsGrid');
  const tPieces = useTranslations('newOrder.pieces');
  const tCommon = useTranslations('common');
  const getBilingual = useBilingual();

  const categoryNameMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const c of state.categories) {
      map.set(c.service_category_code, getBilingual(c.ctg_name, c.ctg_name2) || c.service_category_code);
    }
    return map;
  }, [state.categories, getBilingual]);

  const [expandedPiecesItems, setExpandedPiecesItems] = useState<Set<string>>(
    () => new Set(),
  );
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);

  const handleSelectPiece = useCallback((pieceId: string) => {
    setSelectedPieceId((prev) => (prev === pieceId ? null : pieceId));
  }, []);

  const hasItems = state.items.length > 0;

  const { visibleItems, hiddenCount } = useMemo(() => {
    if (state.items.length <= VIRTUALIZED_ITEM_LIMIT) {
      return { visibleItems: state.items, hiddenCount: 0 };
    }

    return {
      visibleItems: state.items.slice(0, VIRTUALIZED_ITEM_LIMIT),
      hiddenCount: state.items.length - VIRTUALIZED_ITEM_LIMIT,
    };
  }, [state.items]);

  const totalPieces = useMemo(
    () =>
      state.items.reduce(
        (sum, item) => sum + (item.pieces ? item.pieces.length : 0),
        0,
      ),
    [state.items],
  );

  const totalQuantity = useMemo(
    () => state.items.reduce((sum, item) => sum + item.quantity, 0),
    [state.items],
  );

  const handlePieceUpdate = (
    productId: string,
    pieceId: string,
    updates: Partial<PreSubmissionPiece>,
  ) => {
    const item = state.items.find((candidate) => candidate.productId === productId);
    if (!item) return;

    const existingPieces: PreSubmissionPiece[] = item.pieces ?? [];
    const updatedPieces = existingPieces.map((piece) =>
      piece.id === pieceId ? { ...piece, ...updates } : piece,
    );

    updateItemPieces(productId, updatedPieces);
  };

  const handleAddPiece = (productId: string) => {
    const item = state.items.find((candidate) => candidate.productId === productId);
    if (!item) return;

    const existingPieces: PreSubmissionPiece[] = item.pieces ?? [];
    const nextSeq =
      existingPieces.length > 0
        ? Math.max(...existingPieces.map((piece) => piece.pieceSeq)) + 1
        : 1;

    const newPiece: PreSubmissionPiece = {
      id: `temp-${productId}-${nextSeq}`,
      itemId: productId,
      pieceSeq: nextSeq,
    };

    updateItemPieces(productId, [...existingPieces, newPiece]);
  };

  const handleRemovePiece = (productId: string, pieceId: string) => {
    const item = state.items.find((candidate) => candidate.productId === productId);
    if (!item) return;

    const existingPieces: PreSubmissionPiece[] = item.pieces ?? [];
    const filteredPieces = existingPieces.filter((piece) => piece.id !== pieceId);
    const resequenced = filteredPieces.map((piece, index) => ({
      ...piece,
      pieceSeq: index + 1,
    }));

    updateItemPieces(productId, resequenced);
  };

  if (!hasItems) {
    return (
      <div className="bg-white rounded-lg border border-dashed border-gray-300 p-6 text-center text-gray-500">
        <p className="font-medium">
          {tItems('noItemsAdded') ||
            'No items added yet. Start from the Select Items tab.'}
        </p>
        <p className="text-sm mt-1">
          {tItems('selectItemsFromGrid') ||
            'Select items from the grid in the Select Items tab to start.'}
        </p>
      </div>
    );
  }

  return (
    <section
      aria-label={tNewOrder('itemsGrid.orderItems') || 'Order items details'}
      className="bg-white rounded-lg border border-gray-200 shadow-sm"
    >
      <div
        className={`px-4 py-3 border-b border-gray-200 flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''
          }`}
      >
        <div className={isRTL ? 'text-right' : 'text-left'}>
          <h2 className="text-base sm:text-lg font-semibold text-gray-900">
            {tItems('orderItems') || 'Order Items'}
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            {trackByPiece
              ? `${totalPieces} ${tPieces('totalPieces') || 'total pieces'}`
              : `${totalQuantity} ${tItems('pieces') || 'items'}`}
          </p>
        </div>
        <div className={isRTL ? 'text-left' : 'text-right'}>
          {totals.servicePrefCharge > 0 ? (
            <div className="space-y-1">
              <div className={`flex justify-between gap-4 text-xs ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-500">{tItems('itemsSubtotal') || 'Items'}</span>
                <span>{fmtMoney(totals.subtotal - totals.servicePrefCharge)}</span>
              </div>
              <div className={`flex justify-between gap-4 text-xs ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-500">{tItems('additionalServices') || 'Additional Services'}</span>
                <span>{fmtMoney(totals.servicePrefCharge)}</span>
              </div>
              <div className={`flex justify-between gap-4 text-sm font-bold pt-1 border-t border-gray-200 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>{tItems('total') || 'Total'}</span>
                <span>{fmtMoney(totals.subtotal)}</span>
              </div>
            </div>
          ) : (
            <>
              <p className="text-xs text-gray-500">
                {tItems('total') || 'Total'}
              </p>
              <p className="text-lg font-bold text-gray-900">
                {fmtMoney(totals.subtotal)}
              </p>
            </>
          )}
        </div>
      </div>

      <PreferencesTabsSection
        trackByPiece={trackByPiece}
        packingPerPieceEnabled={packingPerPieceEnabled}
        bundlesEnabled={bundlesEnabled}
        repeatLastOrderEnabled={repeatLastOrderEnabled}
        smartSuggestionsEnabled={smartSuggestionsEnabled}
        enforcePrefCompatibility={enforcePrefCompatibility}
        hasServicePrefs={hasServicePrefs}
      />

      <div className="overflow-x-auto max-h-[60vh]">
        <table className="min-w-full text-xs">
          <thead className="bg-gray-50 text-gray-600">
            <tr
              className={isRTL ? 'text-right' : 'text-left'}
            >
              <th className="px-3 py-2 font-semibold">
                {tItems('itemName') || tItems('addItem') || 'Item'}
              </th>
              <th className="px-3 py-2 font-semibold">
                {tItems('serviceCategory') || 'Service Category'}
              </th>
              <th className="px-3 py-2 font-semibold">
                {tItems('qtyLabel') || 'Qty'}
              </th>
              <th className="px-3 py-2 font-semibold">
                {tItems('priceLabel') || 'Price'}
              </th>
              <th className="px-3 py-2 font-semibold">
                {tItems('total') || 'Total'}
              </th>
              <th className="px-3 py-2 font-semibold">
                {tItems('note') || 'Note'}
              </th>
              {(hasServicePrefs || hasPackingPrefs) && (
                <th className="px-3 py-2 font-semibold">
                  {tItems('preferences') || 'Preferences'}
                </th>
              )}
              <th className="px-3 py-2 font-semibold text-center">
                {tItems('actions') || 'Actions'}
              </th>
            </tr>
          </thead>
          <tbody>
            {visibleItems.map((item) => (
              <Fragment key={item.productId}>
                {/* Parent item row */}
                <tr className="border-t border-gray-100 hover:bg-gray-50">
                  <td className="px-3 py-2 align-top">
                    <div
                      className={`text-sm font-medium text-gray-900 ${isRTL ? 'text-right' : 'text-left'
                        }`}
                    >
                      {item.productName || tItems('unknownProduct') || 'Item'}
                    </div>
                    {item.productName2 && (
                      <div
                        className={`text-xs text-gray-500 ${isRTL ? 'text-right' : 'text-left'
                          }`}
                      >
                        {item.productName2}
                      </div>
                    )}
                    {trackByPiece && (
                      <button
                        type="button"
                        onClick={() => {
                          setExpandedPiecesItems((previous) => {
                            // Allow only one item expanded at a time
                            const isExpanded = previous.has(item.productId);
                            if (isExpanded) {
                              return new Set<string>();
                            }
                            return new Set<string>([item.productId]);
                          });
                        }}
                        className={`mt-1 inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] text-gray-700 ${isRTL ? 'flex-row-reverse' : ''
                          } ${expandedPiecesItems.has(item.productId)
                            ? 'border-blue-500 bg-blue-50 text-blue-700'
                            : 'border-gray-300 bg-white hover:bg-gray-100'
                          }`}
                        aria-label={`${tPieces('pieces') || 'Pieces'} (${item.productName || ''
                          })`}
                      >
                        <span>
                          {tPieces('pieces') || 'Pieces'} (
                          {item.pieces?.length ?? 0})
                        </span>
                        {expandedPiecesItems.has(item.productId) ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    )}
                  </td>
                  <td className="px-3 py-2 align-top">
                    <div
                      className={`text-xs text-gray-700 ${isRTL ? 'text-right' : 'text-left'
                        }`}
                    >
                      {item.serviceCategoryCode
                        ? categoryNameMap.get(item.serviceCategoryCode) ||
                          item.serviceCategoryCode
                        : '—'}
                    </div>
                  </td>
                  <td className="px-3 py-2 align-top">
                    <div
                      className={`inline-flex items-center rounded-full border border-gray-300 bg-white text-xs ${isRTL ? 'flex-row-reverse' : ''
                        }`}
                    >
                      <button
                        type="button"
                        aria-label={tItems('decreaseQuantity') || 'Decrease'}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-l-full disabled:opacity-40 disabled:cursor-not-allowed"
                        disabled={item.quantity <= 1}
                        onClick={() =>
                          updateItemQuantity(
                            item.productId,
                            Math.max(1, item.quantity - 1),
                          )
                        }
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 min-w-[2rem] text-center text-sm font-medium">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        aria-label={tItems('increaseQuantity') || 'Increase'}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-r-full"
                        onClick={() =>
                          updateItemQuantity(item.productId, item.quantity + 1)
                        }
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </td>
                  <td className="px-3 py-2 align-top">
                    <div
                      className={`text-sm text-gray-900 ${isRTL ? 'text-right' : 'text-left'
                        }`}
                    >
                      {fmtMoney(item.pricePerUnit + (item.servicePrefCharge ?? 0) / item.quantity)}
                    </div>
                  </td>
                  <td className="px-3 py-2 align-top">
                    <div
                      className={`text-sm font-semibold text-gray-900 ${isRTL ? 'text-right' : 'text-left'
                        }`}
                    >
                      {fmtMoney(calculateItemTotal(item))}
                    </div>
                  </td>
                  <td className="px-3 py-2 align-top">
                    <input
                      type="text"
                      value={item.notes ?? ''}
                      onChange={(event) =>
                        updateItemNotes(item.productId, event.target.value)
                      }
                      placeholder={tItems('note') || 'Add note'}
                      className={`w-full px-2 py-1.5 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${isRTL ? 'text-right' : 'text-left'
                        }`}
                    />
                  </td>
                  {(hasServicePrefs || hasPackingPrefs) && (
                    <td className="px-3 py-2 align-top">
                      <div className="flex flex-col gap-2 min-w-[140px]">
                        {hasPackingPrefs && (
                          <>
                            <PackingPreferenceSelector
                              value={item.packingPrefCode}
                              availablePrefs={packingPrefs}
                              onChange={(code, packingCfId) =>
                                updateItemPackingPref(
                                  item.productId,
                                  code ?? '',
                                  undefined,
                                  undefined,
                                  packingCfId,
                                  code ? packingPriceByCode.get(code) ?? 0 : 0
                                )
                              }
                            />
                            {packingPerPieceEnabled && trackByPiece && (item.pieces?.length ?? 0) > 0 && item.packingPrefCode && (
                              <button
                                type="button"
                                onClick={() => {
                                  const code = item.packingPrefCode!;
                                  const cf = item.packingCfId ?? null;
                                  const updatedPieces = (item.pieces ?? []).map((p) => ({
                                    ...p,
                                    packingPrefCode: code,
                                    packingCfId: cf ?? undefined,
                                  }));
                                  updateItemPieces(item.productId, updatedPieces);
                                  adjustItemPackingCharge(
                                    item.productId,
                                    orderItemLinePackingCharge({ ...item, pieces: updatedPieces }, packingPriceByCode)
                                  );
                                }}
                                className="text-[10px] text-blue-600 hover:underline"
                              >
                                {tItems('applyToAllPieces') || 'Apply to all pieces'}
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  )}
                  <td className="px-3 py-2 align-top text-center">
                    <button
                      type="button"
                      onClick={() => removeItem(item.productId)}
                      className="inline-flex items-center justify-center p-1.5 text-red-600 hover:bg-red-50 rounded-full focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1"
                      aria-label={
                        tItems('removeItem') || 'Remove item from order'
                      }
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>

                {/* Child rows: pieces — selectable rows */}
                {trackByPiece &&
                  expandedPiecesItems.has(item.productId) &&
                  (item.pieces ?? []).map((piece) => {
                    const isPieceSelected = selectedPieceId === piece.id;
                    return (
                      <tr
                        key={piece.id}
                        onClick={() => handleSelectPiece(piece.id)}
                        className={`border-t border-gray-100 cursor-pointer transition-colors ${
                          isPieceSelected
                            ? 'bg-blue-50 outline outline-2 outline-blue-400 outline-offset-[-2px]'
                            : 'bg-gray-50 hover:bg-blue-50/40'
                        }`}
                      >
                        {/* Piece label */}
                        <td className={`px-6 py-2 align-middle ${isRTL ? 'text-right' : 'text-left'}`}>
                          <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                            <span className={`text-xs font-semibold ${isPieceSelected ? 'text-blue-700' : 'text-gray-600'}`}>
                              {tPieces('pieceNumber', { number: piece.pieceSeq })}
                            </span>
                            {piece.color && /^#[0-9A-Fa-f]{3,8}$/.test(piece.color) && (
                              <span className="w-3 h-3 rounded-full shrink-0 border border-gray-300" style={{ backgroundColor: piece.color }} aria-hidden />
                            )}
                            {piece.color && (
                              <span className="text-xs text-gray-500">{piece.color}</span>
                            )}
                          </div>
                        </td>
                        {/* Service category */}
                        <td className="px-3 py-2 align-middle" />
                        {/* Qty placeholder */}
                        <td className="px-3 py-2 align-middle" />
                        {/* Stain / Damage badges */}
                        <td className={`px-3 py-2 align-middle ${isRTL ? 'text-right' : 'text-left'}`} colSpan={2}>
                          <div className={`flex flex-wrap gap-1.5 ${isRTL ? 'flex-row-reverse' : ''}`}>
                            {piece.hasStain && (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-yellow-100 text-yellow-700 text-[10px] font-medium">
                                {tPieces('hasStain')}
                              </span>
                            )}
                            {piece.hasDamage && (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-red-100 text-red-700 text-[10px] font-medium">
                                {tPieces('hasDamage')}
                              </span>
                            )}
                            {piece.rackLocation && (
                              <span className="text-[10px] text-gray-500">{piece.rackLocation}</span>
                            )}
                            {piece.notes && (
                              <span className="text-[10px] text-gray-500 italic">{piece.notes}</span>
                            )}
                          </div>
                        </td>
                        {/* Note */}
                        <td className="px-3 py-2 align-middle" />
                        {/* Preferences placeholder */}
                        {(hasServicePrefs || hasPackingPrefs) && (
                          <td className="px-3 py-2 align-middle" />
                        )}
                        {/* Remove */}
                        <td className="px-3 py-2 align-middle text-center">
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); handleRemovePiece(item.productId, piece.id); }}
                            className="inline-flex items-center justify-center p-1.5 text-red-500 hover:bg-red-50 rounded-full focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1"
                            aria-label={tPieces('removePiece') || 'Remove piece'}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}

                {/* Add piece row */}
                {trackByPiece && expandedPiecesItems.has(item.productId) && (
                  <tr className="bg-gray-50 border-t border-gray-100">
                    <td
                      className="px-6 py-2 text-[11px] text-blue-700 cursor-pointer"
                      colSpan={hasServicePrefs || hasPackingPrefs ? 8 : 7}
                    >
                      <button
                        type="button"
                        onClick={() => handleAddPiece(item.productId)}
                        className={`text-blue-700 hover:underline ${isRTL ? 'text-right' : 'text-left'
                          }`}
                      >
                        + {tPieces('addPiece')}
                      </button>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {hiddenCount > 0 && (
        <div className="px-4 py-2 text-xs text-gray-500 border-t border-gray-100 bg-gray-50">
          {tNewOrder('itemsGrid.more', { count: hiddenCount }) ||
            `+${hiddenCount} more items not shown for performance`}
        </div>
      )}
    </section>
  );
}


