'use client'

/**
 * Price Override Modal
 * Allows authorized users to manually override item prices
 */

import { useState, useEffect } from 'react'
import { useLocale, useTranslations } from 'next-intl'
import { useTenantCurrency } from '@/lib/context/tenant-currency-context'
import { formatMoneyAmountWithCode, roundMoneyAmount } from '@/lib/money/format-money'
import { useRTL } from '@/lib/hooks/useRTL'
import { CmxDialog, CmxDialogContent, CmxDialogHeader, CmxDialogTitle, CmxDialogFooter } from '@ui/overlays'
import { CmxButton, CmxMoneyField } from '@ui/primitives'
import { CmxInput } from '@ui/primitives'
import { CmxTextarea } from '@ui/primitives'
import { CmxKeypad, KEYPAD_NUMERIC_3COL } from '@ui/utilities'
import { parseMoneyDraft, applyKeypadInput } from '@/lib/money/money-draft'
import { AlertCircle, Info } from 'lucide-react'
import { showSuccessToast, showErrorToast } from '@/src/ui/feedback/cmx-toast'

interface PriceOverrideModalProps {
    open: boolean
    onClose: () => void
    item: {
        id: string
        productName: string
        quantity: number
        calculatedPrice: number
        currentPrice?: number
    }
    onSave: (override: { price: number; reason: string }) => void
    hasPermission: boolean
}

/**
 *
 * @param root0
 * @param root0.open
 * @param root0.onClose
 * @param root0.item
 * @param root0.onSave
 * @param root0.hasPermission
 */
export function PriceOverrideModal({
    open,
    onClose,
    item,
    onSave,
    hasPermission,
}: PriceOverrideModalProps) {
    const t = useTranslations('newOrder')
    const isRTL = useRTL()
    const locale = useLocale()
    const { currencyCode, decimalPlaces } = useTenantCurrency()
    const moneyLocale = locale === 'ar' ? 'ar' : 'en'
    const fmt = (n: number) =>
        formatMoneyAmountWithCode(n, { currencyCode, decimalPlaces, locale: moneyLocale })
    const [overridePrice, setOverridePrice] = useState(
        item.currentPrice ? String(item.currentPrice) : String(item.calculatedPrice)
    )
    const [reason, setReason] = useState('')
    const [saving, setSaving] = useState(false)
    const [errors, setErrors] = useState<Record<string, string>>({})

    // Reset form when modal opens/closes or item changes
    useEffect(() => {
        if (open) {
            setOverridePrice(
                item.currentPrice ? String(item.currentPrice) : String(item.calculatedPrice)
            )
            setReason('')
            setErrors({})
        }
    }, [open, item])

    function validate(): boolean {
        const newErrors: Record<string, string> = {}

        const price = parseMoneyDraft(overridePrice)
        if (price < 0) {
            newErrors.price = 'Price must be a valid number >= 0'
        }

        if (!reason.trim()) {
            newErrors.reason = 'Reason is required for price override'
        }

        if (reason.trim().length < 10) {
            newErrors.reason = 'Reason must be at least 10 characters'
        }

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    async function handleSave() {
        if (!validate()) return

        setSaving(true)
        try {
            const price = parseMoneyDraft(overridePrice)
            onSave({
                price,
                reason: reason.trim(),
            })
            showSuccessToast('Price override applied successfully')
            onClose()
        } catch (err: any) {
            showErrorToast(err.message || 'Failed to apply price override')
        } finally {
            setSaving(false)
        }
    }

    if (!hasPermission) {
        return (
            <CmxDialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
                <CmxDialogContent>
                    <CmxDialogHeader>
                        <CmxDialogTitle>Permission Denied</CmxDialogTitle>
                    </CmxDialogHeader>
                    <div className={`flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                            <p className="text-sm font-medium text-red-800">Access Denied</p>
                            <p className="text-sm text-red-700 mt-1">
                                You do not have permission to override prices. Please contact your administrator.
                            </p>
                        </div>
                    </div>
                    <CmxDialogFooter>
                        <CmxButton variant="outline" onClick={onClose}>
                            Close
                        </CmxButton>
                    </CmxDialogFooter>
                </CmxDialogContent>
            </CmxDialog>
        )
    }

    const priceDiff = parseMoneyDraft(overridePrice) - item.calculatedPrice
    const priceDiffPercent = item.calculatedPrice > 0
        ? ((priceDiff / item.calculatedPrice) * 100).toFixed(1)
        : '0'

    return (
        <CmxDialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
            <CmxDialogContent className="max-w-2xl">
                <CmxDialogHeader>
                    <CmxDialogTitle>Override Price</CmxDialogTitle>
                </CmxDialogHeader>

                <div className="space-y-4">
                    {/* Item Info */}
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                        <p className="text-sm font-medium text-gray-900 mb-2">{item.productName}</p>
                        <div className={`flex items-center gap-4 text-sm text-gray-600 ${isRTL ? 'flex-row-reverse' : ''}`}>
                            <span>Quantity: {item.quantity}</span>
                            <span>Calculated Price: {fmt(item.calculatedPrice)}</span>
                        </div>
                    </div>

                    {/* Current Calculated Price (Read-only) */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Calculated Price (Read-only)
                        </label>
                        <CmxInput
                            value={String(roundMoneyAmount(item.calculatedPrice, decimalPlaces))}
                            disabled
                            className="bg-gray-50"
                        />
                    </div>

                    {/* Override Price */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Override Price ({currencyCode}) *
                        </label>
                        <CmxMoneyField
                            value={parseMoneyDraft(overridePrice) || null}
                            draftValue={overridePrice}
                            decimalPlaces={decimalPlaces}
                            min={0}
                            showZero
                            onValueChange={(_, d) => setOverridePrice(d)}
                            placeholder={fmt(0)}
                        />
                        {errors.price && (
                            <p className="mt-1 text-sm text-red-600">{errors.price}</p>
                        )}
                        {!errors.price && priceDiff !== 0 && (
                            <p className={`mt-1 text-sm ${priceDiff > 0 ? 'text-red-600' : 'text-green-600'}`}>
                                {priceDiff > 0 ? '+' : ''}{fmt(priceDiff)} ({priceDiffPercent}%)
                                {priceDiff > 0 ? ' increase' : ' decrease'}
                            </p>
                        )}
                        <div className="mt-3">
                            <CmxKeypad
                                keys={KEYPAD_NUMERIC_3COL}
                                columns={3}
                                keyHeight="lg"
                                onKeyPress={(key) => {
                                    const next = applyKeypadInput(overridePrice, key, decimalPlaces)
                                    setOverridePrice(next)
                                }}
                                onKeyLongPress={(k) => { if (k === 'backspace') setOverridePrice('') }}
                                getKeyClassName={(k) => k === 'backspace' ? undefined : 'bg-white'}
                            />
                        </div>
                    </div>

                    {/* Reason */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Reason for Override *
                        </label>
                        <CmxTextarea
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Explain why you are overriding the calculated price..."
                            rows={4}
                            required
                        />
                        {errors.reason && (
                            <p className="mt-1 text-sm text-red-600">{errors.reason}</p>
                        )}
                        <p className="mt-1 text-xs text-gray-500">
                            Minimum 10 characters. This will be recorded in the audit trail.
                        </p>
                    </div>

                    {/* Info Box */}
                    <div className={`bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1 text-sm text-blue-800">
                            <p className="font-medium mb-1">Price Override Information</p>
                            <ul className={`list-disc list-inside space-y-1 ${isRTL ? 'text-right' : 'text-left'}`}>
                                <li>Price overrides are logged in the audit trail</li>
                                <li>Override applies to this item only</li>
                                <li>Tax will be recalculated based on the override price</li>
                                <li>This action requires pricing:override permission</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <CmxDialogFooter>
                    <CmxButton type="button" variant="outline" onClick={onClose}>
                        Cancel
                    </CmxButton>
                    <CmxButton onClick={handleSave} disabled={saving}>
                        {saving ? 'Saving...' : 'Apply Override'}
                    </CmxButton>
                </CmxDialogFooter>
            </CmxDialogContent>
        </CmxDialog>
    )
}

