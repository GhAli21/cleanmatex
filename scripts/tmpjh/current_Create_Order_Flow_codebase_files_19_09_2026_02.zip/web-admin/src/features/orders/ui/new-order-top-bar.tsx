/**
 * New Order Top Bar
 * Sticky top bar with branch, customer, express and category tabs
 * PRD-010: Advanced Order Management
 */

'use client';

import { memo, type ReactNode } from 'react';
import { useTranslations } from 'next-intl';
import { useRTL } from '@/lib/hooks/useRTL';
import { CategoryTabs } from './category-tabs';
import { CategoryTabsSkeleton } from './loading-skeletons';
import { UserPlus, UserCheck, Edit2, Zap, Settings2 } from 'lucide-react';
import type { BranchOption } from '@/lib/services/inventory-service';
import { CmxSelect } from '@ui/primitives';
import {
  SELECTABLE_NEW_ORDER_SOURCE_CODES,
  type OrderSourceCode,
} from '@/lib/constants/order-sources';
import { ORDER_TYPE_ID_VALUES, type OrderTypeId } from '@/lib/constants/order-types';
import { ORDER_TYPE_I18N_KEYS } from '@/lib/constants/order-type-labels';

interface ServiceCategory {
  service_category_code: string;
  ctg_name: string;
  ctg_name2: string;
  service_category_icon?: string;
  service_category_color1?: string;
}

interface NewOrderTopBarProps {
  branches: BranchOption[];
  branchId: string | null;
  onBranchChange: (id: string | null) => void;
  branchesLoading?: boolean;
  /** Current fulfillment choice; it must remain visible while staff add items. */
  orderTypeId: OrderTypeId;
  onOrderTypeChange: (orderTypeId: OrderTypeId) => void;
  /** Current auditable channel; user-editable only while creating a new order. */
  orderSourceCode: OrderSourceCode;
  onOrderSourceChange: (orderSourceCode: OrderSourceCode) => void;
  /** Hides creation-only fields when the same top bar renders an existing order. */
  showOrderContextSelectors?: boolean;
  customerName: string;
  onSelectCustomer: () => void;
  onEditCustomer?: () => void;
  express: boolean;
  onExpressToggle: (value: boolean) => void;
  categories: ServiceCategory[];
  selectedCategory: string;
  onSelectCategory: (code: string) => void;
  categoriesLoading?: boolean;
  showCategories?: boolean;
  hasBranchDependentData?: boolean;
  sessionSlot?: ReactNode;
  /** Count of order-wide preferences already applied, shown as a badge. Omit/0 hides the badge. */
  orderPrefsCount?: number;
  /** Presence gates whether the order-preferences pill renders at all (tenant may have no service-pref catalog). */
  onOpenOrderPreferences?: () => void;
}

/**
 * Keeps creation context and high-frequency order controls visible above every New Order step.
 *
 * @param props Tenant-aware branches, order context, and interaction callbacks.
 * @returns Sticky bilingual controls and the optional service-category row.
 */
export const NewOrderTopBar = memo(function NewOrderTopBar({
  branches,
  branchId,
  onBranchChange,
  branchesLoading = false,
  orderTypeId,
  onOrderTypeChange,
  orderSourceCode,
  onOrderSourceChange,
  showOrderContextSelectors = true,
  customerName,
  onSelectCustomer,
  onEditCustomer,
  express,
  onExpressToggle,
  categories,
  selectedCategory,
  onSelectCategory,
  categoriesLoading = false,
  showCategories = true,
  hasBranchDependentData = false,
  sessionSlot,
  orderPrefsCount = 0,
  onOpenOrderPreferences,
}: NewOrderTopBarProps) {
  const t = useTranslations('newOrder');
  const tCommon = useTranslations('common');
  const tOrders = useTranslations('orders');
  const isRTL = useRTL();
  const orderTypeOptions = ORDER_TYPE_ID_VALUES.map((code) => ({
    value: code,
    label: tOrders(ORDER_TYPE_I18N_KEYS[code]),
  }));
  const orderSourceOptions = SELECTABLE_NEW_ORDER_SOURCE_CODES.map((code) => ({
    value: code,
    label: t(`topBar.orderSources.${code}`),
  }));

  return (
    <div className="sticky top-0 z-20 bg-white border-b border-gray-200 shadow-sm flex-shrink-0">
      {/* Row 1: Branch + Customer + Express */}
      <div className={`px-4 py-2 flex items-center gap-3 flex-wrap ${isRTL ? 'flex-row-reverse' : ''}`}>
        {/* Branch Selector — only if multiple branches */}
        {branches.length > 1 && (
          <select
            value={branchId ?? ''}
            autoFocus={!branchId}
            onChange={(e) => {
              const newId = e.target.value || null;
              if (hasBranchDependentData && newId && newId !== branchId) {
                const confirmed = window.confirm(
                  t('warnings.changeBranchConfirm') || 'Changing the branch will clear your current order data. Continue?'
                );
                if (!confirmed) return;
              }
              onBranchChange(newId);
            }}
            className={`max-w-[180px] px-3 py-1.5 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent ${!branchId ? 'border-amber-400 bg-amber-50' : 'border-gray-300'} ${isRTL ? 'text-right' : 'text-left'}`}
            dir={isRTL ? 'rtl' : 'ltr'}
            aria-label={tCommon('branch')}
          >
            <option value="">{tCommon('selectBranch')}</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {isRTL ? (b.name2 || b.name) : b.name}
              </option>
            ))}
          </select>
        )}
        {branchesLoading && branches.length === 0 && (
          <span className="text-xs text-gray-400">{tCommon('loading') || 'Loading...'}</span>
        )}

        {/* Customer pill */}
        <button
          type="button"
          onClick={customerName ? (onEditCustomer ?? onSelectCustomer) : onSelectCustomer}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full border-2 text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 ${isRTL ? 'flex-row-reverse' : ''} ${
            customerName
              ? 'border-blue-400 bg-blue-50 text-blue-800'
              : 'border-gray-300 bg-white text-gray-600 hover:border-gray-400'
          }`}
          aria-label={customerName ? (t('orderSummary.editCustomer') || 'Edit customer') : t('selectCustomer')}
        >
          {customerName ? (
            <UserCheck className="w-4 h-4 shrink-0" aria-hidden />
          ) : (
            <UserPlus className="w-4 h-4 shrink-0" aria-hidden />
          )}
          <span className="max-w-[140px] truncate">
            {customerName || t('selectCustomer')}
          </span>
          {customerName && <Edit2 className="w-3 h-3 shrink-0 opacity-60" aria-hidden />}
        </button>

        {/* Express pill toggle */}
        <button
          type="button"
          role="switch"
          aria-checked={express}
          onClick={() => onExpressToggle(!express)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full border-2 text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-1 ${isRTL ? 'flex-row-reverse' : ''} ${
            express
              ? 'bg-orange-500 border-orange-500 text-white'
              : 'bg-white border-gray-300 text-gray-600 hover:border-orange-300'
          }`}
          aria-label={express ? (t('topBar.expressOn') || 'Express On') : (t('topBar.expressOff') || 'Express Off')}
        >
          <Zap className="w-4 h-4 shrink-0" aria-hidden />
          <span>{t('topBar.expressLabel') || t('express.label') || 'Express'}</span>
        </button>

        {/* Order-wide preferences pill — always visible on every step, so staff don't
            need to remember which step/tab holds order-level entry (see B18 redesign). */}
        {onOpenOrderPreferences && (
          <button
            type="button"
            onClick={onOpenOrderPreferences}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full border-2 text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 ${isRTL ? 'flex-row-reverse' : ''} ${
              orderPrefsCount > 0
                ? 'border-blue-400 bg-blue-50 text-blue-800'
                : 'border-gray-300 bg-white text-gray-600 hover:border-gray-400'
            }`}
            aria-label={
              t('topBar.orderPreferencesAria', { count: orderPrefsCount }) ||
              `Order preferences${orderPrefsCount > 0 ? `, ${orderPrefsCount} applied` : ''}`
            }
          >
            <Settings2 className="w-4 h-4 shrink-0" aria-hidden />
            <span>{t('topBar.orderPreferences') || 'Preferences'}</span>
            {orderPrefsCount > 0 && (
              <span
                className={`flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-blue-600 text-white text-xs font-semibold ${isRTL ? 'ms-0.5' : ''}`}
              >
                {orderPrefsCount}
              </span>
            )}
          </button>
        )}

        {/* Context remains above the fold because it changes workflow and audit semantics, not item pricing. */}
        {showOrderContextSelectors && (
          <div className={`flex items-center gap-3 flex-wrap ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <span className="text-xs font-medium text-gray-600 whitespace-nowrap">
                {t('topBar.orderTypeLabel')}
              </span>
              <CmxSelect
                id="new-order-type"
                value={orderTypeId}
                onChange={(event) => onOrderTypeChange(event.currentTarget.value as OrderTypeId)}
                options={orderTypeOptions}
                size="sm"
                fullWidth={false}
                className="min-w-[10.5rem]"
                dir={isRTL ? 'rtl' : 'ltr'}
                aria-label={t('topBar.orderTypeLabel')}
              />
            </div>

            <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <span className="text-xs font-medium text-gray-600 whitespace-nowrap">
                {t('topBar.orderSourceLabel')}
              </span>
              <CmxSelect
                id="new-order-source"
                value={orderSourceCode}
                onChange={(event) => onOrderSourceChange(event.currentTarget.value as OrderSourceCode)}
                options={orderSourceOptions}
                size="sm"
                fullWidth={false}
                className="min-w-[9.5rem]"
                dir={isRTL ? 'rtl' : 'ltr'}
                aria-label={t('topBar.orderSourceLabel')}
              />
            </div>
          </div>
        )}

        {sessionSlot ? (
          <div className="ms-auto flex min-w-0 items-center">
            {sessionSlot}
          </div>
        ) : null}
      </div>

      {/* Row 2: Category Tabs */}
      {showCategories && (
        <div className="px-4 pb-2">
          {categoriesLoading ? (
            <CategoryTabsSkeleton />
          ) : (
            <CategoryTabs
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={onSelectCategory}
              className="py-1 border-0 rounded-none p-0 bg-transparent"
            />
          )}
        </div>
      )}
    </div>
  );
});
