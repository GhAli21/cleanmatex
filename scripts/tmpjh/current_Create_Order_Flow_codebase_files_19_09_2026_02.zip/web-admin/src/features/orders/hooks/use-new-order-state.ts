/**
 * use-new-order-state Hook
 * Context consumer with dispatch helpers
 */

import { useNewOrderContext } from '../ui/context/new-order-context';
import type { NewOrderState, MinimalCustomer, OrderItem, PreSubmissionPiece, OrderItemServicePref, ServiceCategory, Product, CustomerSnapshotOverride } from '../model/new-order-types';
import type { OrderSourceCode } from '@/lib/constants/order-sources';
import type { OrderTypeId } from '@/lib/constants/order-types';

/**
 * Optional snapshot when setting customer (for org_orders_mst columns)
 */
export interface SetCustomerSnapshot {
  customerMobile?: string;
  customerEmail?: string;
  customerNameSnapshot?: string;
  isDefaultCustomer?: boolean;
}

/**
 * Reducer state with the mutation helpers used by New Order surfaces.
 * The context itself owns order type and source so every submission path shares
 * one creation contract.
 */
export interface UseNewOrderStateWithDispatchReturn {
  state: NewOrderState;
  dispatch: ReturnType<typeof useNewOrderContext>['dispatch'];
  setCustomer: (customer: MinimalCustomer | null, customerName: string, snapshot?: SetCustomerSnapshot) => void;
  setCustomerSnapshotOverride: (override: CustomerSnapshotOverride | null) => void;
  setBranchId: (branchId: string | null) => void;
  /** Changes the fulfillment classification before the new order is submitted. */
  setOrderTypeId: (orderTypeId: OrderTypeId) => void;
  /** Changes the auditable sales or integration channel before submission. */
  setOrderSourceCode: (orderSourceCode: OrderSourceCode) => void;
  addItem: (item: OrderItem) => void;
  removeItem: (productId: string) => void;
  updateItemQuantity: (productId: string, quantity: number) => void;
  updateItemPieces: (productId: string, pieces: PreSubmissionPiece[] | undefined) => void;
  updateItemServicePrefs: (productId: string, servicePrefs: OrderItemServicePref[], servicePrefCharge: number) => void;
  updateOrderServicePrefs: (servicePrefs: OrderItemServicePref[]) => void;
  updateItemPackingPref: (
    productId: string,
    packingPrefCode: string,
    packingPrefIsOverride?: boolean,
    packingPrefSource?: string,
    packingCfId?: string | null,
    packingPrefCharge?: number
  ) => void;
  adjustItemPackingCharge: (productId: string, packingPrefCharge: number) => void;
  updateItemNotes: (productId: string, notes: string) => void;
  updateItemPriceOverride: (productId: string, priceOverride: number | null, overrideReason: string, overrideBy: string) => void;
  setQuickDrop: (value: boolean) => void;
  setQuickDropQuantity: (quantity: number) => void;
  setExpress: (value: boolean) => void;
  setBags: (count: number) => void;
  setNotes: (notes: string) => void;
  setCustomerNotes: (notes: string) => void;
  setPaymentNotes: (notes: string) => void;
  setReadyByAt: (readyByAt: string) => void;
  setLoading: (loading: boolean) => void;
  setCreatedOrder: (orderId: string, status: string | null) => void;
  openModal: (modal: keyof NewOrderState['modals']) => void;
  closeModal: (modal: keyof NewOrderState['modals']) => void;
  openPriceOverrideModal: (productId: string) => void;
  setCategories: (categories: ServiceCategory[]) => void;
  setProducts: (products: Product[]) => void;
  setSelectedCategory: (category: string) => void;
  setCategoriesLoading: (loading: boolean) => void;
  setProductsLoading: (loading: boolean) => void;
  setInitialLoading: (loading: boolean) => void;
  resetOrder: () => void;
  setSelectedPiece: (pieceId: string | null) => void;
  updatePieceConditions: (pieceId: string, conditions: string[]) => void;
  updatePieceColor: (pieceId: string, color: string | undefined, colorCodes?: string[], colorCfIds?: (string | null)[]) => void;
}

/**
 * Provides reducer state and stable-looking semantic dispatch helpers for New Order UI.
 *
 * @returns Current draft state and actions, including order type and source setters.
 * @example
 * const { state, setOrderTypeId } = useNewOrderStateWithDispatch();
 * setOrderTypeId('HOME_COLLECTION');
 */
export function useNewOrderStateWithDispatch(): UseNewOrderStateWithDispatchReturn {
  const { state, dispatch } = useNewOrderContext();

  // Helper functions for common actions
  const actions = {
    setCustomer: (customer: typeof state.customer, customerName: string, snapshot?: SetCustomerSnapshot) => {
      dispatch({
        type: 'SET_CUSTOMER',
        payload: {
          customer,
          customerName,
          ...(snapshot && {
            customerMobile: snapshot.customerMobile,
            customerEmail: snapshot.customerEmail,
            customerNameSnapshot: snapshot.customerNameSnapshot,
            isDefaultCustomer: snapshot.isDefaultCustomer,
          }),
        },
      });
    },

    setCustomerSnapshotOverride: (override: CustomerSnapshotOverride | null) => {
      dispatch({ type: 'SET_CUSTOMER_SNAPSHOT_OVERRIDE', payload: override });
    },

    setBranchId: (branchId: string | null) => {
      dispatch({ type: 'SET_BRANCH_ID', payload: branchId });
    },

    setOrderTypeId: (orderTypeId: OrderTypeId) => {
      dispatch({ type: 'SET_ORDER_TYPE_ID', payload: orderTypeId });
    },

    setOrderSourceCode: (orderSourceCode: OrderSourceCode) => {
      dispatch({ type: 'SET_ORDER_SOURCE_CODE', payload: orderSourceCode });
    },

    addItem: (item: typeof state.items[0]) => {
      dispatch({ type: 'ADD_ITEM', payload: item });
    },

    removeItem: (productId: string) => {
      dispatch({ type: 'REMOVE_ITEM', payload: productId });
    },

    updateItemQuantity: (productId: string, quantity: number) => {
      dispatch({
        type: 'UPDATE_ITEM_QUANTITY',
        payload: { productId, quantity },
      });
    },

    updateItemPieces: (productId: string, pieces: PreSubmissionPiece[] | undefined) => {
      dispatch({
        type: 'UPDATE_ITEM_PIECES',
        payload: { productId, pieces: pieces || [] },
      });
    },

    updateItemServicePrefs: (productId: string, servicePrefs: OrderItemServicePref[], servicePrefCharge: number) => {
      dispatch({
        type: 'UPDATE_ITEM_SERVICE_PREFS',
        payload: { productId, servicePrefs, servicePrefCharge },
      });
    },

    updateOrderServicePrefs: (servicePrefs: OrderItemServicePref[]) => {
      dispatch({
        type: 'UPDATE_ORDER_SERVICE_PREFS',
        payload: { servicePrefs },
      });
    },

    updateItemPackingPref: (
      productId: string,
      packingPrefCode: string,
      packingPrefIsOverride?: boolean,
      packingPrefSource?: string,
      packingCfId?: string | null,
      packingPrefCharge?: number
    ) => {
      dispatch({
        type: 'UPDATE_ITEM_PACKING_PREF',
        payload: {
          productId,
          packingPrefCode,
          packingPrefIsOverride,
          packingPrefSource,
          packingCfId,
          packingPrefCharge,
        },
      });
    },

    adjustItemPackingCharge: (productId: string, packingPrefCharge: number) => {
      dispatch({
        type: 'ADJUST_ITEM_PACKING_PREF_CHARGE',
        payload: { productId, packingPrefCharge },
      });
    },

    updateItemNotes: (productId: string, notes: string) => {
      dispatch({
        type: 'UPDATE_ITEM_NOTES',
        payload: { productId, notes },
      });
    },

    updateItemPriceOverride: (productId: string, priceOverride: number | null, overrideReason: string, overrideBy: string) => {
      dispatch({
        type: 'UPDATE_ITEM_PRICE_OVERRIDE',
        payload: { productId, priceOverride, overrideReason, overrideBy },
      });
    },

    setQuickDrop: (value: boolean) => {
      dispatch({ type: 'SET_QUICK_DROP', payload: value });
    },

    setQuickDropQuantity: (quantity: number) => {
      dispatch({ type: 'SET_QUICK_DROP_QUANTITY', payload: quantity });
    },

    setExpress: (value: boolean) => {
      dispatch({ type: 'SET_EXPRESS', payload: value });
    },

    setBags: (count: number) => {
      dispatch({ type: 'SET_BAGS', payload: count });
    },

    setNotes: (notes: string) => {
      dispatch({ type: 'SET_NOTES', payload: notes });
    },

    setCustomerNotes: (notes: string) => {
      dispatch({ type: 'SET_CUSTOMER_NOTES', payload: notes });
    },

    setPaymentNotes: (notes: string) => {
      dispatch({ type: 'SET_PAYMENT_NOTES', payload: notes });
    },

    setReadyByAt: (readyByAt: string) => {
      dispatch({ type: 'SET_READY_BY_AT', payload: readyByAt });
    },

    setLoading: (loading: boolean) => {
      dispatch({ type: 'SET_LOADING', payload: loading });
    },

    setCreatedOrder: (orderId: string, status: string | null) => {
      dispatch({
        type: 'SET_CREATED_ORDER',
        payload: { orderId, status },
      });
    },

    openModal: (modal: keyof typeof state.modals) => {
      dispatch({ type: 'OPEN_MODAL', payload: modal });
    },

    closeModal: (modal: keyof typeof state.modals) => {
      dispatch({ type: 'CLOSE_MODAL', payload: modal });
    },

    openPriceOverrideModal: (productId: string) => {
      dispatch({ type: 'OPEN_PRICE_OVERRIDE_MODAL', payload: productId });
    },

    setCategories: (categories: typeof state.categories) => {
      dispatch({ type: 'SET_CATEGORIES', payload: categories });
    },

    setProducts: (products: typeof state.products) => {
      dispatch({ type: 'SET_PRODUCTS', payload: products });
    },

    setSelectedCategory: (category: string) => {
      dispatch({ type: 'SET_SELECTED_CATEGORY', payload: category });
    },

    setCategoriesLoading: (loading: boolean) => {
      dispatch({ type: 'SET_CATEGORIES_LOADING', payload: loading });
    },

    setProductsLoading: (loading: boolean) => {
      dispatch({ type: 'SET_PRODUCTS_LOADING', payload: loading });
    },

    setInitialLoading: (loading: boolean) => {
      dispatch({ type: 'SET_INITIAL_LOADING', payload: loading });
    },

    resetOrder: () => {
      dispatch({ type: 'RESET_ORDER' });
    },

    setSelectedPiece: (pieceId: string | null) => {
      dispatch({ type: 'SET_SELECTED_PIECE', payload: pieceId });
    },

    updatePieceConditions: (pieceId: string, conditions: string[]) => {
      dispatch({ type: 'UPDATE_PIECE_CONDITIONS', payload: { pieceId, conditions } });
    },

    updatePieceColor: (pieceId: string, color: string | undefined, colorCodes?: string[], colorCfIds?: (string | null)[]) => {
      dispatch({ type: 'UPDATE_PIECE_COLOR', payload: { pieceId, color, colorCodes, colorCfIds } });
    },
  };

  return {
    state,
    dispatch,
    ...actions,
  };
}

// Re-export base hooks for direct use if needed
export { useNewOrderState, useNewOrderDispatch } from '../ui/context/new-order-context';

