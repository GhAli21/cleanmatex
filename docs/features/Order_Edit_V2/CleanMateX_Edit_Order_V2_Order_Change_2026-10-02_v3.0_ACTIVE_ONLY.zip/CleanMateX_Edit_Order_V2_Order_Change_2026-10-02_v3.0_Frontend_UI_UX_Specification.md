# CleanMateX Edit Order V2 — Frontend / UI / UX Specification

**Version:** 3.0  
**Route:** `/dashboard/orders/[id]/edit`

## 1. UX objective

Keep the familiar New Order workspace but make Edit a separate controller/session. The user edits a local projected order, reviews authoritative server Preview, then explicitly Applies one atomic Change.

## 2. Required screen structure

```text
Edit Order Page
  Edit Context Bar
  Shared Customer/Order Header (restricted fields in Edit)
  Shared Product Catalog
  Shared Order Items / Piece / Preference editors
  Shared Order Summary
  Edit-specific Review Changes primary action
  Edit-specific dialogs/sheets:
    Piece Selection
    Review Changes
    Warning/Override/Reason
    Conflict / Reload Latest
    Financial Result / Follow-up
```

## 3. Controller state

EditOrderController owns:

```text
loadStatus: IDLE|LOADING|READY|BLOCKED|ERROR
originalContext
workingState
editStateVersion
wfStateVersion
capabilities/configuration
normalizedPendingOperations
previewStatus: IDLE|DIRTY|LOADING|READY|STALE|ERROR
previewResult/reviewProof
applyStatus: IDLE|SUBMITTING|SUCCEEDED|ERROR
idempotencyKey
conflict
financialFollowUp
```

Shared presentational components receive callbacks/view models; they do not decide API route based on a sprawling `isEditMode` branch.

## 4. Stable client identity

- existing item: persisted item UUID;
- new item: client UUID;
- existing piece: persisted piece UUID;
- new piece: client UUID;
- existing preference: persisted preference row UUID;
- new preference: client UUID.

Never use `productId` as list identity and never replace committed piece identity with `temp-${productId}-${index}`.

## 5. Local visual state

Every visible target may be:

`UNCHANGED`, `ADDED`, `CHANGED`, `REMOVED`.

Persisted removed rows remain visible/faded with Undo until Apply. A locally new row removed before Apply disappears and emits no operation.

## 6. Context bar

Display:

- `Editing Order #<number>`;
- `Revision <editStateVersion>`;
- workflow status;
- unsaved change count;
- Edit blocked/warning indicator where relevant;
- `Discard Changes`.

Do not call navigation-away action “Cancel Order”.

## 7. Field behavior

### Read-only V1

- customer identity;
- branch;
- currency;
- order source/type where identity-defining;
- POS session/create-time construction fields.

### Governed editable

According to capability/configuration:

- items/quantities;
- pieces;
- generic preferences;
- priority;
- service speed;
- ready-by customer commitment override;
- approved order/customer snapshot notes/contact corrections.

## 8. Quantity/piece UX

For piece-tracked committed items, quantity decrease cannot blindly decrement. Open eligible-piece selection and generate `REMOVE_PIECE` operations. Add piece increases quantity. Protected/processed pieces show a reason and cannot be selected if denied.

## 9. Estimated money

During local edits show clearly labelled estimate:

- Current Total;
- Estimated New Total;
- Estimated Change.

Do not label estimated delta as “Pay now”. Server Preview is authoritative.

## 10. Review Changes

Primary action: `Review Changes`.

The review dialog/sheet displays grouped:

- items;
- pieces;
- preferences;
- priority/service speed/ready-by/notes;
- price/discount/tax/charge effects;
- Current Total / New Total / commercial delta;
- financial outcome (outstanding/overpayment);
- warnings;
- required reason;
- override requirement;
- unsupported/fiscal blocking reason.

Apply is available only from a valid current Preview. Any local edit invalidates the Preview/proof.

## 11. Conflict UX

For edit/workflow/review conflict:

- never auto-merge V1;
- show what became stale when safe;
- primary: `Reload Latest Order`;
- secondary: inspect/copy unsaved intent where practical;
- do not silently overwrite latest data.

Network failure after unknown Apply result retries with the **same idempotency key and identical payload**.

## 12. Global edit blocked UI

`TEMPORARILY_BLOCKED`: show reason and expiry if available; no editing controls.  
`PERMANENTLY_BLOCKED`: show permanent reason; no override button.  
Feature disabled/not entitled: route/access contract should prevent normal entry and show established feature/access UI.

## 13. Apply success

Refresh authoritative context/history/financial summary, clear dirty state and show revision. Then:

- `NONE` => return/view order;
- `OUTSTANDING_*` => offer/require supported additional collection according to Finance policy;
- `OVERPAYMENT` => open focused Financial Resolution if the user chooses/needs to resolve now.

Failure in later Finance follow-up does not undo the successful Change.

## 14. Loading/empty/error states

- skeleton/loading uses existing Cmx patterns;
- order not found/foreign tenant uses generic not-found;
- configuration dependency failure is explicit retry/support error, not zero-price/tax fallback;
- Quick Drop may legitimately have zero detailed items and shows detailing affordance;
- no-change review is disabled or returns a clear “No changes to apply”.

## 15. Accessibility / i18n / RTL

- all new text uses existing EN/AR message framework and glossary;
- RTL-safe alignment/order/icons;
- keyboard operable dialogs, focus trap/return, labelled fields and errors;
- do not communicate removed/changed state by color alone;
- money formatting follows currency configuration; stored numeric precision is not UI decimal formatting.

## 16. Responsive/POS behavior

Desktop and tablet/POS layouts must keep the Review action reachable without duplicate Save buttons. The review sheet can become full-screen on narrow devices. Do not introduce horizontal overflow in item/piece tables/cards.
