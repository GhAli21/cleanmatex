# CleanMateX Edit Order V2 — Requirement Traceability Matrix

| ID | Requirement | Database | API | Backend | Frontend | Verification |
|---|---|---|---|---|---|---|
| R001 | Commitment boundary | org_orders_mst committed_at/by | change-context/Apply | order-change context/apply | Edit context | commitment migration+integration+E2E |
| R002 | Separate edit/workflow concurrency | edit_state_version + existing state_version | context/preview/apply | capability/apply | conflict dialog | DB concurrency + E2E |
| R003 | Stable item identity | item UUID + removal lineage | context/preview/apply | projection/mutation | item editor | identity integration/E2E |
| R004 | Stable piece identity | piece UUID + removal lineage | context/preview/apply | projection/mutation | piece editor/selection | piece integration/E2E |
| R005 | Stable preference identity | preference UUID + removal lineage | context/preview/apply | preference adapter | preference UI | all-level preference tests |
| R006 | Generic preference ops | change ops table | preview/apply | projection/preference | preference UI | ORDER/ITEM/PIECE matrix |
| R007 | Operation capability policy | workflow/profile config + order access | context/preview/apply | capability service | disabled/warn/override states | policy/gate tests |
| R008 | Preview no writes | none | POST changes/preview | preview service | Review Changes | purity/instrumentation tests |
| R009 | Atomic idempotent Apply | Change master/ops + idempotency/outbox | POST changes | apply service | Apply/retry | fault injection + concurrency |
| R010 | Immutable payment history | existing finance facts | Apply response only | financial result + snapshot | financial outcome | 20→15 financial tests |
| R011 | Separate financial follow-up | existing finance + optional lineage | additional payment / resolution | Finance-owned adapter | financial resolution dialog | source/cap/race tests |
| R012 | Tenant isolation | RLS + scoped FKs | all | all queries scoped | generic errors | cross-tenant RLS/API tests |
| R013 | Configuration ownership | settings/flags/workflow/domain configs | context | config resolver | effective behavior | config precedence tests |
| R014 | Legacy bypass closure | guards/no new table | legacy routes translate/deny | compat translators | existing screens | writer closure test |
| R015 | Audit/history | Change master/ops + legacy read | GET changes | history adapter | history timeline | audit exactness tests |
| R016 | Observability | outbox existing | all | logging/metrics/tracing | support surfaces | metrics/outbox tests |
| R017 | EN/AR/RTL/a11y | message catalogs | UI routes | frontend | all Edit UI | Playwright EN/AR/a11y |