# CleanMateX Edit Order V2 — Open Decisions & Release Gates

**Version:** 3.0

A production-ready specification must expose unknowns instead of hiding assumptions. These gates do not invalidate the architecture; they block only dependent work packages/modes.

| Gate | Recommended direction | Must be resolved before |
|---|---|---|
| Remote production schema/privileges | restore authenticated read-only verification; never infer production from local | production migration/backfill/cutover |
| Historical commitment source/timezone | source-by-source proof; unresolved legacy orders remain ineligible | historical V2 enablement |
| Commercial operation-policy binding storage | extend existing workflow/profile policy model; fail closed missing binding | capability completion / Apply enablement |
| New/changed line pricing context | preserve unchanged line facts; choose exact policy for new/changed lines after non-zero adjustment tests | calculation WP |
| Inclusive unit-price semantics | preserve current historical meaning; document net/gross fields explicitly | calculation WP |
| Preference extra-price accounting | preserve current single-count level semantics | calculation WP |
| Charge taxability | keep current non-taxable B18 behavior unless domain decision/config says otherwise | taxable charge support |
| Issued fiscal correction composition/precision | Finance/Fiscal-owned corrections; block unsupported states | paid/issued-doc Edit modes |
| B2B AR correction | use existing AR correction authority or deny unsupported issued state | B2B edited obligation |
| Finance resolution eligibility | finite source-qualified supported actions; no invented gateway automation | financial follow-up WP |
| Charge/discount correction operation vocabulary | define only operations required by actual committed writer closure | writer migration WP |
| Role mapping for new permissions | enumerate real current roles; explicit reviewed grants only | pilot |

No coding agent may silently decide one of these and ship it as a default. The implementation PR/work package must either reference the approved decision or keep the dependent mode disabled/fail closed.
