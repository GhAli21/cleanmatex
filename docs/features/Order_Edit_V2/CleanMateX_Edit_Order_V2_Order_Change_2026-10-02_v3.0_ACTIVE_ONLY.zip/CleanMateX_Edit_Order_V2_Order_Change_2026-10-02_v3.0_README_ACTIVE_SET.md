# CleanMateX Edit Order V2 — Active v3.0 Document Set

Only the v3.0 files listed here are active implementation authority.

## Primary
1. `CleanMateX_Edit_Order_V2_Order_Change_2026-10-02_v3.0_Full_Architecture.md`
2. `CleanMateX_Edit_Order_V2_Order_Change_2026-10-02_v3.0_Production_Implementation_Specification.md`
3. `Edit_Order_V2_Final_Implementation_Plan_Current_Codebase_v3.0.md`

## Specialized contracts
- Database Schema Blueprint
- API Contract Catalog
- Configuration Policy Matrix
- Operation Capability Catalog
- Frontend UI/UX Specification
- Service Module Map
- Permissions/Security/Tenant Isolation
- Events/Observability/Performance
- Requirement Traceability Matrix
- Migration/Cutover/Operations Runbook
- Open Decisions/Release Gates
- Frozen Invariants
- Completeness Audit
- Change Log

## Superseded
Delete from the active working project after verifying this v3.0 set:
- all Edit Order V2 v2.x files
- `Edit_Order_V2_Final_Implementation_Plan_Current_Codebase_Codex.md`
- duplicate earlier implementation-plan copies

Historical copies may be archived outside the active project if desired.

## Rule
Do not create another competing implementation plan. Update the v3.0 living plan after every approved work package.
