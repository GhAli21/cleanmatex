# CleanMateX Edit Order V2 / Order Change — v3.0 Full Production Pack

Date: 2026-10-02

## Authority order

1. `..._v3.0_Full_Architecture.*` + Frozen Invariants = business/target architecture.
2. `..._v3.0_Production_Implementation_Specification.*` = master execution specification.
3. Specialized companion contracts = normative detail for their domain.
4. Current repository + verified target DB = implementation evidence.
5. Open Decisions & Release Gates = explicit blockers; never guess around them.

## Start here

- Full Architecture
- Production Implementation Specification
- Open Decisions & Release Gates
- Configuration & Policy Matrix

## Why v3.0

v3.0 closes details that were implicit or insufficiently visible in v2.1: exact API/error behavior, database blueprint, operation payload/capability contract, backend service boundaries, frontend states/screens, RBAC/security, events/observability/SLOs, requirement traceability and operations runbook.
