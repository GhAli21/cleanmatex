# CleanMateX Edit Order V2 — Permissions, Security & Tenant Isolation

**Version:** 3.0

## 1. Permissions

New commercial capabilities:

- `orders:edit` — enter/use commercial Edit V2 where policy allows;
- `orders:edit_override` — satisfy authorized override decisions; never bypass hard invariants.

Reuse specialized permissions such as pricing override, discount, refund/process-refund, post-settlement legacy controls during migration, manual charge where implemented.

Do not trust client-supplied actor IDs, `overrideBy`, tenant IDs, permission claims or financial outcomes.

## 2. Role mapping

Permission seeding and role mapping are separate. Do not silently grant `orders:edit` or `orders:edit_override` to every role. The migration must first enumerate actual current system role codes; map only reviewed roles. Tenant custom-role administrators may assign through the normal permission framework where product policy permits.

## 3. Route security

Each new route must use current authentication, tenant context, permission and CSRF conventions. Browser-hidden controls are not authorization.

## 4. Target hierarchy

Every persisted ID is validated as belonging to the authenticated tenant and same order. Piece preference must prove order→item→piece. Return generic not-found/invalid-target without leaking cross-tenant existence.

## 5. RLS

RLS is defense in depth, not a replacement for explicit tenant predicates. New Change rows are readable by authorized tenant context but not directly writable by ordinary clients.

## 6. Immutable facts

Normal Edit V2 cannot rewrite:

- payment/voucher/receipt history;
- issued fiscal documents;
- commitment timestamp/source;
- applied Change/operation rows;
- customer identity/branch/currency in V1;
- permanent edit block through ordinary override.

## 7. Sensitive data

Before/after JSON and metadata must exclude payment secrets, PAN/CVV, credentials, tokens, unnecessary PII and large binary payloads. Store identifiers/safe display snapshots only when needed for audit.

## 8. Threat cases required in tests

- forged tenant/order/item/piece/preference UUID;
- guessed foreign-tenant ID;
- client actor/override spoofing;
- stale signed review/gate proof replay;
- same idempotency key different payload;
- direct Data API/RPC mutation bypass;
- CSRF on mutation routes;
- direct legacy committed full-replacement attempt after V2 enablement;
- authorization changes between Preview and Apply;
- permanent block bypass attempt.
