# CleanMateX Edit Order V2 — Migration, Cutover & Operations Runbook

**Version:** 3.0

## 1. Preflight

- record branch/HEAD/status;
- verified backup for environment being changed;
- re-list current migrations and target schema;
- verify remote auth/catalog before production decisions;
- run canonical Create protection and legacy Edit characterization;
- refresh committed writer inventory;
- verify current RLS/grants/RPC functions and settings/permission catalogs.

## 2. Additive deployment sequence

1. additive DB foundation, feature disabled;
2. compatible Prisma/types/readers;
3. commitment producers + active-row readers;
4. contracts/context;
5. capability/RBAC/config;
6. projection/calculation/Finance adapters;
7. Preview;
8. persistence + Apply;
9. frontend Review flow;
10. finance follow-up;
11. migrate/guard every committed writer;
12. historical backfill/preflight;
13. concurrency/security/UAT;
14. internal pilot;
15. selected cohort;
16. default cutover;
17. bounded legacy cleanup.

## 3. Feature/cohort rule

V2 may not be enabled for an order/cohort while an ordinary committed commercial writer remains able to bypass Change for the same scope. Partial authority breaks revision/proof correctness.

## 4. Pilot checklist

- normal, Quick Drop, paid/unpaid/partial/B2B scenarios;
- EN/AR/RTL;
- same product repeated lines;
- pieces/preferences;
- workflow conflict;
- two commercial editors;
- payment/refund race;
- retry after lost Apply response;
- financial follow-up failure;
- legacy route blocked;
- direct-client DML/RPC blocked;
- metrics/outbox visible.

## 5. Rollback

For V2-modified orders, rollback is read-only/disable further V2 editing, never fallback to full replacement. Preserve Change history and allow safe Finance follow-up. Legacy writer may remain only for orders never entering V2 and only inside documented compatibility cohort during rollback window.

## 6. Incident support

For any suspected bad Change:

1. identify order/change/revision/request/idempotency key;
2. freeze further Edit with temporary block if needed;
3. inspect operations and canonical facts;
4. inspect financial snapshot and immutable settlement facts;
5. do not manually rewrite payment/receipt/history;
6. use domain correction/repair authority with audited reason;
7. record incident and add regression test.

## 7. Data repair

Generic SQL repair is not normal Edit. Production repair requires explicit privileged runbook, dry-run/report, tenant/order scope, backup, reason/actor, post-reconciliation and audit. Once V2 is authoritative, commercial repairs should prefer a governed `REPAIR` source through Change where semantically expressible.
