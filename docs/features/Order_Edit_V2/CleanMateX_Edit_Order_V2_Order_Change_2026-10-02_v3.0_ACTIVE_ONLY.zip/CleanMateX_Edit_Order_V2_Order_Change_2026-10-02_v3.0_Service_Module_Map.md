# CleanMateX Edit Order V2 — Service & Module Map

**Version:** 3.0

## 1. Backend ownership

### Reuse unchanged/with narrow adapters

- canonical Create: `app/api/v1/orders/submit-order/route.ts`, `order-submit-orchestrator.service.ts`;
- calculation/pricing/discount/tax/rounding current services;
- `order-financial-aggregation.ts`, `order-financial-write.service.ts`, financial summary;
- workflow semantic policy/gates/facts/decision infrastructure;
- preference catalogs/resolvers;
- payments/vouchers/refunds/stored value/AR/cash drawer;
- idempotency and outbox infrastructure.

### New coherent module

```text
lib/constants/order-change.ts
lib/types/order-change.ts
lib/validations/order-change/order-change.schemas.ts
lib/services/order-change/
  order-change-context.service.ts
  order-change-capability.service.ts
  order-change-projection.ts
  order-change-calculation.service.ts
  order-change-financial-result.service.ts
  order-change-preview.service.ts
  order-change-mutation.service.ts
  order-change-apply.service.ts
```

Do not make one class/file per operation unless behavior is genuinely domain-complex; operations should primarily dispatch to shared typed adapters.

## 2. Service contracts

### Context service

Read-only; tenant-scoped; loads commitment, both versions, access, workflow binding, active stable identities, preferences, money summary, config and actor capabilities. No DML.

### Capability service

Pure/read-oriented decision service. It does not execute workflow transitions. Inputs are order context + actor + operation + target + policy facts. Returns decision, reason codes, warning/override/reason requirements and proof inputs.

### Projection

Deterministic in-memory transform. No DB writes and no network. Shared by Preview and Apply. Resolves client refs, stable identity, parent/child invariants and normalized operations.

### Calculation adapter

Composes current Pricing/Discount/Tax/Rounding algorithms through explicit inputs/transaction readers. It is not a second calculator. Unchanged committed lines preserve facts unless a frozen policy says otherwise.

### Financial result service

Uses current immutable settlement components plus projected/new commercial obligation to classify `NONE|OUTSTANDING_OPTIONAL|OUTSTANDING_REQUIRED|OVERPAYMENT`. It never creates payment/refund facts during Change.

### Preview service

Read-only orchestration of context → capabilities → projection → calculation → finance result → review proof. No persistent side effects.

### Mutation service

Transaction-only stable inserts/updates/logical removals and canonical detail-fact persistence. Requires a supplied transaction client. No nested transaction/global Prisma/network.

### Apply service

Single owner of committed commercial mutation. Handles replay, lock order, versions, revalidation, mutation, snapshot, Change/ops, audit/outbox/idempotency/version increment in one transaction.

## 3. Transaction rule

Any helper used inside Apply must either:

- accept the caller transaction client, or
- be pure and operate on already-resolved inputs.

A helper that opens its own Prisma transaction/global DB read or performs HTTP is not transaction-safe for Apply and must be adapted before use.

## 4. Legacy boundaries

`OrderService.updateOrder()` remains compatibility only until cutover and may never be the V2 core. `org_order_edit_history` is legacy/timeline input, not Change authority. Hard-coded `isOrderEditable()` becomes compatibility only after capability cutover.
