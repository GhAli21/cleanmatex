# Change Log — v3.0 (2026-10-02)

- Added production completeness contract to architecture.
- Added master Production Implementation Specification.
- Added exact API route/DTO/error/idempotency contract.
- Added DB schema blueprint with Change tables, order fields, removal lineage, RLS, backfill and rollback.
- Added V1 operation/capability catalog and normalization rules.
- Added detailed frontend/UI/UX state and screen behavior.
- Added service/module responsibilities and transaction-composition rules.
- Added explicit RBAC/security/tenant-isolation contract.
- Added outbox/event, logging, metrics, tracing, SLO and support requirements.
- Added requirement traceability matrix.
- Added migration/cutover/incident runbook.
- Added explicit Open Decisions & Release Gates so unresolved business facts cannot become hidden developer assumptions.
- Preserved v2.1 configuration ownership and added effective-source requirements and Edit-specific naming guidance.
