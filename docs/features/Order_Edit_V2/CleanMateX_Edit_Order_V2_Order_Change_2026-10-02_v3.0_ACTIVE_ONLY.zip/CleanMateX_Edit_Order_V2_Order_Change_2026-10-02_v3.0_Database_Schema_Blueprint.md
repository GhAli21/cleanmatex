# CleanMateX Edit Order V2 — Database Schema Blueprint

**Version:** 3.0  
**Status:** Normative blueprint; migration SQL must re-check the live target catalog immediately before authoring/applying.

## 1. `org_orders_mst` additions

| Column | Type | Null/default | Rule |
|---|---|---|---|
| `committed_at` | `TIMESTAMPTZ` | NULL | non-null = committed; irreversible in normal runtime |
| `committed_by` | `UUID` | NULL | server-derived actor; unknown legacy actor may remain NULL |
| `edit_state_version` | `INTEGER` | NOT NULL DEFAULT 0 | draft 0; initial commit 1; each successful Change +1 |
| `edit_access_status` | `TEXT` | NOT NULL DEFAULT `OPEN` | `OPEN`,`TEMPORARILY_BLOCKED`,`PERMANENTLY_BLOCKED` |
| `edit_block_reason_code` | `TEXT` | NULL | stable support/policy code |
| `edit_block_reason_text` | `TEXT` | NULL | operator-readable reason |
| `edit_blocked_at` | `TIMESTAMPTZ` | NULL | required when blocked |
| `edit_blocked_by` | `UUID` | NULL | server-derived actor |
| `edit_block_until` | `TIMESTAMPTZ` | NULL | temporary block only |
| `service_speed` | `TEXT` | NULL during compatibility | distinct from priority; initial supported tokens must be catalog/policy verified |

Retain physical `state_version` initially. V2 API exposes it as `wfStateVersion`. Do not create a second independently writable workflow counter.

## 2. New `org_order_changes_mst`

Recommended exact columns:

```sql
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
tenant_org_id UUID NOT NULL,
order_id UUID NOT NULL,
change_no INTEGER NOT NULL,
edit_state_version_before INTEGER NOT NULL,
edit_state_version_after INTEGER NOT NULL,
wf_state_version_expected INTEGER NOT NULL,
source_context TEXT NOT NULL,
actor_user_id UUID NOT NULL,
actor_name TEXT NULL,
change_reason TEXT NULL,
currency_code TEXT NOT NULL,
financial_before JSONB NOT NULL,
financial_after JSONB NOT NULL,
commercial_delta NUMERIC(19,4) NOT NULL,
financial_outcome TEXT NOT NULL,
idempotency_key TEXT NOT NULL,
request_hash TEXT NOT NULL,
apply_response JSONB NOT NULL,
applied_at TIMESTAMPTZ NOT NULL,
metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
created_by TEXT NOT NULL,
created_info TEXT NULL,
updated_at TIMESTAMPTZ NULL,
updated_by TEXT NULL,
updated_info TEXT NULL,
rec_status SMALLINT NOT NULL DEFAULT 1,
rec_order INTEGER NULL,
rec_notes TEXT NULL,
is_active BOOLEAN NOT NULL DEFAULT true
```

Required checks/uniques:

- after version = before + 1;
- before >= 1;
- financial outcome in approved tokens;
- unique `(tenant_org_id,order_id,change_no)`;
- unique `(tenant_org_id,order_id,edit_state_version_after)`;
- unique `(tenant_org_id,idempotency_key)`;
- composite FK `(order_id,tenant_org_id)` to order;
- actor FK only after verified identity authority/preflight.

Applied rows are append-only to ordinary runtime roles.

## 3. New `org_order_change_ops_dtl`

```sql
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
tenant_org_id UUID NOT NULL,
order_id UUID NOT NULL,
order_change_id UUID NOT NULL,
operation_seq INTEGER NOT NULL,
operation_code TEXT NOT NULL,
target_type TEXT NOT NULL,
order_item_id UUID NULL,
order_item_piece_id UUID NULL,
order_preference_id UUID NULL,
client_ref UUID NULL,
before_values JSONB NOT NULL DEFAULT '{}'::jsonb,
after_values JSONB NOT NULL DEFAULT '{}'::jsonb,
audit_summary TEXT NULL,
metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
created_by TEXT NOT NULL,
created_info TEXT NULL,
updated_at TIMESTAMPTZ NULL,
updated_by TEXT NULL,
updated_info TEXT NULL,
rec_status SMALLINT NOT NULL DEFAULT 1,
rec_order INTEGER NULL,
rec_notes TEXT NULL,
is_active BOOLEAN NOT NULL DEFAULT true
```

- positive sequence;
- unique `(tenant_org_id,order_change_id,operation_seq)`;
- scoped FK to master `(order_change_id,order_id,tenant_org_id)`;
- typed item/piece/preference target FKs enforce tenant/order hierarchy where possible;
- JSON is bounded audit data, not an alternative untyped command model.

## 4. Stable removal lineage

Reuse `rec_status=0` as inactive/removed; do not introduce a second `is_deleted` truth.

Add to committed item/piece/preference rows where absent:

```text
deleted_at TIMESTAMPTZ NULL
deleted_by UUID NULL
deleted_order_change_id UUID NULL
```

For new governed removals: `deleted_order_change_id != NULL` requires `rec_status=0`, `deleted_at`, and `deleted_by`.

Legacy inactive rows may retain NULL lineage rather than fabricated history.

## 5. Hierarchy hardening

Preflight first, then add/validate scoped keys/FKs needed to prove:

- item belongs to the same tenant/order;
- piece belongs to same tenant/order/item;
- preference ITEM target belongs to same order/item;
- preference PIECE target belongs to same order/item/piece.

Do not silently delete or rewrite legacy orphan/cross-hierarchy data during preflight.

## 6. RLS and privileges

- Enable RLS on new Change tables.
- Authenticated read is tenant-scoped according to existing CleanMateX tenant membership/context patterns.
- Ordinary client direct INSERT/UPDATE/DELETE to Change tables is denied; server command path owns writes.
- Service-role/backend queries still include explicit tenant predicates.
- Audit direct Data API/RPC grants before pilot so a normal authenticated client cannot mutate committed commercial structure/money outside owned commands.

## 7. Migration order

1. target catalog/preflight;
2. additive order columns;
3. Change tables + indexes/RLS;
4. removal lineage columns;
5. permission/feature/config seeds;
6. compatible application readers/writers;
7. historical commitment classification/backfill;
8. hierarchy FK validation after orphan report is clean/resolved;
9. V2 pilot enablement.

Never edit old migration files. Re-list the latest migration immediately before assigning the next filename.

## 8. Backfill rules

- `created_at` is not automatically commitment time.
- classify canonical submit, persisted draft/legacy, public/remote booking, Quick Drop and failed compensation independently;
- use only provable timestamp/actor lineage;
- unresolved historical rows remain V2-ineligible until resolved;
- baseline historical committed order starts commercial revision 1; first real V2 Change is 1→2 and `change_no=1`;
- do not synthesize typed operations from lossy legacy edit diffs.

## 9. Rollback

After an order has a V2 Change, rollback means **disable further V2 editing while preserving V2 data/history**, never route it back to full delete/recreate Edit. Additive schema remains. No destructive down migration, reset, CASCADE, uncommit, or payment-history rewrite.
