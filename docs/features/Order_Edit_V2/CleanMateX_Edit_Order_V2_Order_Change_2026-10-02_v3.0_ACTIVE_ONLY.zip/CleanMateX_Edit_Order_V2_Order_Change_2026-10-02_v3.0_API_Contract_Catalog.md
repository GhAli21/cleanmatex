# CleanMateX Edit Order V2 — API Contract Catalog

**Version:** 3.0  
**Date:** 2026-10-02  
**Status:** Normative implementation contract

## 1. API principles

- All routes are tenant-scoped by authenticated server context. Tenant/actor supplied by browser are ignored/rejected.
- Currency and authoritative monetary results come from server state/calculation.
- `wfStateVersion` is the API name for the current physical workflow `state_version` during the compatibility phase.
- `editStateVersion` is the commercial revision/OCC counter.
- Preview is read-only. Apply is atomic and idempotent.
- Apply never performs gateway/refund/notification HTTP calls inside the DB transaction.
- Client temporary IDs are UUIDs and are mapped to persisted UUIDs by Apply.
- Unknown fields are rejected by strict validation.

## 2. Common error envelope

```json
{
  "ok": false,
  "error": {
    "code": "EDIT_STATE_VERSION_CONFLICT",
    "message": "The order changed while you were editing.",
    "details": {},
    "requestId": "..."
  }
}
```

### HTTP mapping

| HTTP | Domain codes |
|---|---|
| 400 | `VALIDATION_ERROR`, malformed operation graph, invalid enum/value |
| 401 | `UNAUTHENTICATED` |
| 403 | `PERMISSION_DENIED`, `EDIT_ACCESS_BLOCKED`, hard `OPERATION_NOT_ALLOWED`, `OVERRIDE_FORBIDDEN` |
| 404 | `ORDER_NOT_FOUND`, `TARGET_NOT_FOUND` (tenant-safe; never disclose foreign-tenant existence) |
| 409 | `EDIT_STATE_VERSION_CONFLICT`, `WORKFLOW_VERSION_CONFLICT`, `IDEMPOTENCY_CONFLICT`, `REVIEW_STALE`, conflicting operations |
| 422 | structural/business invariant violations, unsupported finance/fiscal mode, invalid target hierarchy |
| 423 | optional only if repository convention adopts it for temporary global edit block; otherwise use 403 consistently |
| 500 | unexpected internal failure; no sensitive details |
| 503 | required pricing/tax/configuration dependency unavailable where fail-closed is required |

Do not expose stack traces, SQL, secrets, raw gateway payloads, PAN/CVV, or cross-tenant identifiers.

## 3. GET `/api/v1/orders/[id]/change-context`

Purpose: authoritative Edit V2 load model.

### Response 200

```json
{
  "ok": true,
  "data": {
    "orderId": "uuid",
    "orderNo": "string",
    "committedAt": "ISO-8601",
    "editStateVersion": 3,
    "wfStateVersion": 12,
    "workflow": {
      "currentStatus": "preparing",
      "profileId": "uuid|null",
      "profileVersionId": "uuid|null"
    },
    "editAccess": {
      "status": "OPEN",
      "reasonCode": null,
      "reasonText": null,
      "blockedUntil": null
    },
    "permissions": {
      "canEdit": true,
      "canOverride": false,
      "canOverridePrice": false
    },
    "configuration": {
      "featureEnabled": true,
      "newItemPricePolicy": "...",
      "existingDiscountPolicy": "...",
      "reasonPolicy": "..."
    },
    "order": {
      "customer": {},
      "customerSnapshot": {},
      "branchId": "uuid",
      "currencyCode": "OMR",
      "priority": "normal",
      "serviceSpeed": "STANDARD|null",
      "readyBy": "ISO-8601|null",
      "notes": "",
      "customerNotes": ""
    },
    "items": [],
    "pieces": [],
    "preferences": [],
    "financial": {
      "totalAmount": "0.0000",
      "netCollectedAmount": "0.0000",
      "outstandingAmount": "0.0000",
      "overpaidAmount": "0.0000"
    },
    "capabilitySummary": {}
  }
}
```

### Load requirements

- Return persisted IDs for all committed item/piece/preference rows.
- Active arrays exclude `rec_status=0`; history endpoint/view may include inactive facts.
- Item and piece hierarchy must be tenant/order validated.
- Customer ID, branch ID and currency are read-only in Edit V1.
- Do not map a piece UUID to a synthetic `temp-*` value.

## 4. POST `/api/v1/orders/[id]/changes/preview`

### Request

```json
{
  "expectedEditStateVersion": 3,
  "expectedWfStateVersion": 12,
  "sourceContext": "STAFF_EDIT",
  "changeReason": "optional unless policy requires",
  "operations": [
    {
      "seq": 1,
      "code": "CHANGE_ITEM_QUANTITY",
      "target": {"kind":"PERSISTED_ITEM","id":"uuid"},
      "payload": {"quantity": 3}
    }
  ],
  "gateDecisions": []
}
```

### Response 200

Returns normalized operations, before/after summaries, authoritative money, capability decisions, warnings, required reason/override, financial outcome, source-qualified finance follow-up options, and a review proof/fingerprint.

```json
{
  "ok": true,
  "data": {
    "noChange": false,
    "normalizedOperations": [],
    "review": {
      "groups": [],
      "warnings": [],
      "requiresReason": false,
      "requiresOverride": false
    },
    "money": {
      "beforeTotal": "20.0000",
      "afterTotal": "15.0000",
      "commercialDelta": "-5.0000"
    },
    "financial": {
      "outcome": "OVERPAYMENT",
      "outstandingAmount": "0.0000",
      "overpaidAmount": "5.0000",
      "allowedFollowUp": []
    },
    "versions": {"editStateVersion":3,"wfStateVersion":12},
    "reviewProof": "opaque-signed-or-hashed-proof",
    "calculationFingerprint": "hash"
  }
}
```

Preview must perform zero DML against commercial facts, Change/audit/outbox/idempotency, promotion usage/reservations, stored value or snapshots.

## 5. POST `/api/v1/orders/[id]/changes`

Header: `Idempotency-Key: <opaque client UUID/string>` required.

### Request

Same normalized intent as Preview plus `reviewProof` and `calculationFingerprint` when that mechanism is enabled.

### Apply ordering

1. recognize successful idempotent replay before rejecting now-stale versions;
2. lock order and coordinated facts;
3. verify edit/workflow versions;
4. verify commitment/access/permission/capabilities/proofs;
5. recompute projection and money;
6. reject stale reviewed result rather than silently applying a new amount;
7. persist stable mutations and financial snapshot;
8. persist Change + ops;
9. increment edit version once;
10. audit/outbox/idempotency in same transaction;
11. commit;
12. return immutable apply response.

### Response 200/201

```json
{
  "ok": true,
  "data": {
    "orderChangeId": "uuid",
    "changeNo": 2,
    "revision": 4,
    "wfStateVersion": 12,
    "identityMap": {"client-uuid":"persisted-uuid"},
    "money": {},
    "financial": {
      "outcome": "OVERPAYMENT",
      "outstandingAmount": "0.0000",
      "overpaidAmount": "5.0000"
    }
  }
}
```

Same key + same canonical payload returns this exact frozen response. Same key + different canonical payload returns 409 `IDEMPOTENCY_CONFLICT`.

## 6. History

Recommended read route (may reuse existing order details endpoint if cleaner):

`GET /api/v1/orders/[id]/changes`

Returns V2 Change master/operation timeline plus separately labelled legacy Edit history. Do not merge lossy legacy snapshots into fake typed operations.

## 7. Finance follow-up APIs (WP16)

These are separate from Change and must be finalized against existing Finance contracts before implementation:

- additional receivable collection adapter;
- focused overpayment/financial resolution adapter.

A Change Apply response may link/route to them but never executes them implicitly.

## 8. Error codes required by V2

`ORDER_NOT_COMMITTED`, `EDIT_ACCESS_BLOCKED`, `EDIT_STATE_VERSION_CONFLICT`, `WORKFLOW_VERSION_CONFLICT`, `ORDER_CHANGE_OPERATION_CONFLICT`, `OPERATION_NOT_ALLOWED`, `OVERRIDE_REQUIRED`, `OVERRIDE_FORBIDDEN`, `PERMISSION_DENIED`, `INVALID_TARGET`, `INVALID_TARGET_HIERARCHY`, `STRUCTURAL_INVARIANT_VIOLATION`, `PRICING_FAILED`, `TAX_RESOLUTION_FAILED`, `FINANCIAL_SNAPSHOT_MISMATCH`, `FINANCIAL_MODE_UNSUPPORTED`, `REVIEW_STALE`, `IDEMPOTENCY_CONFLICT`, `ORDER_CHANGE_NOOP` (response condition, not necessarily error).
