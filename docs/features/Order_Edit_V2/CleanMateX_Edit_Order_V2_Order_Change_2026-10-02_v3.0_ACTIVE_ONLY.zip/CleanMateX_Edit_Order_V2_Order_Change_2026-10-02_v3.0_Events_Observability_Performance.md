# CleanMateX Edit Order V2 — Events, Observability, Performance & Support Signals

**Version:** 3.0

## 1. Outbox

Reuse the existing transactional outbox. Do not build another bus.

Before adding a new token, audit registration and consumers. If adopted, the canonical post-commit event should conceptually represent `ORDER_CHANGED` / `order.change_applied` with one stable existing naming convention, not multiple overlapping events.

Minimum safe payload:

```text
eventId
tenantOrgId
orderId
orderChangeId
changeNo
editStateVersionAfter
sourceContext
actorUserId (if policy permits downstream)
financialOutcome
occurredAt
correlation/request id
```

Do not include full sensitive before/after snapshots in broadcast payloads. Consumers re-read tenant-safe data as needed and are idempotent.

## 2. Structured logs

Every Preview/Apply log context should include request/correlation ID, tenant ID, order ID, operation count, edit/wf versions, outcome/error code and latency. Never log payment secrets or full PII.

## 3. Metrics

Recommended counters/histograms:

- `order_change_context_requests_total`;
- `order_change_preview_total{outcome}`;
- `order_change_apply_total{outcome}`;
- `order_change_operation_total{code}`;
- `order_change_conflict_total{type}`;
- `order_change_capability_denied_total{reason}`;
- `order_change_override_total{result}`;
- `order_change_financial_outcome_total{outcome}`;
- `order_change_financial_unresolved_total{type}`;
- `order_change_legacy_write_attempt_total{path}`;
- latency histograms for context/preview/apply;
- idempotent replay counter;
- rollback/failure-stage counter.

## 4. Tracing

Use existing OpenTelemetry conventions. Trace route → context/capability → calculation → finance aggregation → transaction stages. External follow-up is a separate trace/transaction linked by Change ID/correlation ID.

## 5. Performance/SLO target

Use existing platform SLOs as the default production target unless measured Edit complexity requires a reviewed exception:

- normal API p50 < 300 ms;
- p95 < 800 ms where feasible;
- Preview may have a separately measured budget if authoritative pricing/tax evaluation requires it, but must not silently skip rules to hit latency;
- availability target 99.9%;
- no external gateway/network calls in Apply transaction.

Establish real baseline/load tests before release; targets are release gates, not assumptions.

## 6. Alerts/support

Alert on sustained spikes in Apply failures, snapshot mismatch, tax/pricing dependency failures, idempotency conflicts beyond expected retry level, unresolved financial outcomes, legacy bypass attempts, or outbox handler failures.

Support lookup should allow searching Order ID / Change ID / revision / request ID and show source, actor, operations, versions, warnings/override proof summary and financial outcome without exposing secrets.
