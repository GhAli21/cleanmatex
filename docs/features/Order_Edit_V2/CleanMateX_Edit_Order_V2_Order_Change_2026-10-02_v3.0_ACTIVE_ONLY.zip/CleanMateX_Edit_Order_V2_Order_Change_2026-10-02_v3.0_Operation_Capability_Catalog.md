# CleanMateX Edit Order V2 — Operation & Capability Catalog

**Version:** 3.0  
**Status:** Normative V1 operation contract

## 1. Rules

- Operations express business intent, not generic PATCH paths.
- `CHANGE_ITEM_PRODUCT` does not exist: remove old + add new.
- Customer ID, branch ID and currency are not V1 operations.
- Operation-specific capability policy fails closed if required policy binding is missing.
- The backend validates every target against tenant/order hierarchy.

## 2. Catalog

| Code | Scope | Identity | Payload | Policy owners | Invariant |
|---|---|---|---|---|---|
| ADD_ITEM | ORDER | none/clientRef | productId, quantity, optional approved commercial input | Pricing/Discount/Tax + Workflow operation policy | creates stable item; preferences/pieces are separate ops |
| REMOVE_ITEM | ITEM | persisted item ID | optional reason metadata only | Workflow/structural/Finance/fiscal | logical removal; descendants handled atomically; no physical delete |
| CHANGE_ITEM_QUANTITY | ITEM | persisted item ID | quantity; selectedPieceIds when piece tracked | Workflow/structural/Pricing if policy relevant | never product replacement; stable item ID |
| ADD_PIECE | ITEM | persisted/new item ref | clientRef, piece attributes permitted by current domain | Workflow/structural | quantity +1 |
| REMOVE_PIECE | PIECE | persisted piece ID | reason metadata if policy requires | Workflow/structural | logical remove; parent quantity -1 |
| ADD_PREFERENCE | ORDER|ITEM|PIECE | target ref | clientRef, preference definition/code/content/extra inputs allowed by domain | Preference catalog + capability + Pricing | generic all kinds |
| CHANGE_PREFERENCE | PREFERENCE | persisted preference ID | allowed content/value fields; kind replacement not allowed | Preference catalog + capability + Pricing | preserve row identity |
| REMOVE_PREFERENCE | PREFERENCE | persisted preference ID | reason metadata if required | Preference capability/Pricing | logical removal; generic all kinds |
| CHANGE_PRIORITY | ORDER | order | priority code | Workflow/operational policy | priority is not service speed |
| CHANGE_SERVICE_SPEED | ORDER | order | serviceSpeed | Pricing + workflow/turnaround policy | may reprice by explicit policy |
| CHANGE_READY_BY | ORDER | order | readyBy timestamp | Workflow/SLA policy | customer commitment override only |
| CHANGE_ORDER_NOTES | ORDER | order | notes/customerNotes allowed fields | Capability/privacy | must define which note field is commercial/audited |
| CHANGE_CUSTOMER_SNAPSHOT | ORDER | order | approved snapshot/contact fields only | Customer snapshot policy | customer_id itself immutable V1 |

## 3. Normalization/conflict rules

Reject or normalize before Preview/Apply:

- duplicate remove of same persisted target;
- change after remove of same target;
- item remove plus unrelated child changes unless normalized into the parent removal batch;
- piece quantity decrease without explicit eligible piece selection for tracked pieces;
- client-ref cycles/unresolved refs;
- new local target added then removed before Apply => no operation;
- empty normalized operation batch => no Change/revision;
- product change => explicit remove+add;
- preference kind change => remove+add.

## 4. Capability result

Each normalized operation gets:

```text
ALLOW
ALLOW_WITH_WARNING
REQUIRE_OVERRIDE
DENY
```

Decision proof is bound to tenant, order, actor, expected edit version, expected workflow version, normalized operation digest, relevant workflow/profile policy version/facts, and expiry. Any materially changed review invalidates proof.

## 5. Policy ownership

- Global Edit feature/tenant setting enables capability evaluation; it never authorizes an operation by itself.
- Per-order `edit_access_status` can globally restrict the order.
- Workflow/profile operation policy decides stage/status sensitivity.
- Structural rules are hard invariants.
- Pricing/discount/tax/Finance/fiscal domains own their respective restrictions.
- Override permission cannot bypass permanent block, invalid hierarchy, tenant mismatch, immutable historical facts or unsupported fiscal mode.
